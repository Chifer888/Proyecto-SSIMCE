# 🚀 INSTRUCCIONES DE CONFIGURACIÓN - SSIMCE

## 📋 Pasos para conectar la App Android con el Servidor

### **Paso 1: Configurar XAMPP**

1. **Abrir XAMPP Control Panel**
2. **Iniciar Apache y MySQL**
3. **Verificar que ambos servicios estén en verde**

### **Paso 2: Crear carpeta en htdocs**

```bash
# Crear carpeta en XAMPP
D:\Programas Instalados\XAMPP\htdocs\ssimce\
```

### **Paso 3: Copiar archivos al servidor**

Copiar estos archivos a `D:\Programas Instalados\XAMPP\htdocs\ssimce\`:

- ✅ `datos_envios.php`
- ✅ `config.ini`
- ✅ `database_tables.sql`

### **Paso 4: Configurar base de datos**

1. **Abrir phpMyAdmin**: http://localhost/phpmyadmin
2. **Importar base de datos**: Seleccionar `database_tables.sql`
3. **Verificar que se crearon las tablas**

### **Paso 5: Configurar credenciales**

Editar `config.ini`:

```ini
[database]
host = localhost
username = root          # Tu usuario MySQL
password =               # Tu contraseña MySQL (dejar vacío si no tienes)
dbname = ssimce_db
api_key = mi_api_key_123 # Cambiar por una clave secreta
```

### **Paso 6: Configurar URL en Android**

Editar `app/src/main/java/com/example/ssimce/envios/MainActivityEnvios.kt`:

```kotlin
// Para desarrollo local:
private const val SERVER_URL = "http://localhost/ssimce/datos_envios.php"
private const val API_KEY = "mi_api_key_123"

// Para acceso desde otros dispositivos:
private const val SERVER_URL = "http://192.168.1.XXX/ssimce/datos_envios.php"
private const val API_KEY = "mi_api_key_123"
```

### **Paso 7: Encontrar tu IP local**

```bash
# En CMD de Windows:
ipconfig

# Buscar "IPv4 Address" en tu adaptador de red
# Ejemplo: 192.168.1.100
```

### **Paso 8: Probar conexión**

1. **Abrir navegador**
2. **Ir a**: http://localhost/ssimce/datos_envios.php
3. **Debería mostrar error de método** (normal, porque no envías datos POST)

### **Paso 9: Compilar y probar app**

```bash
# En Android Studio o terminal:
./gradlew assembleDebug
./gradlew installDebug
```

## 🔧 Configuraciones Específicas

### **Para desarrollo local (solo tu computadora):**
```kotlin
private const val SERVER_URL = "http://localhost/ssimce/datos_envios.php"
```

### **Para acceso desde otros dispositivos en la misma red:**
```kotlin
private const val SERVER_URL = "http://192.168.1.100/ssimce/datos_envios.php"
```

### **Para servidor web con dominio:**
```kotlin
private const val SERVER_URL = "https://tu-dominio.com/ssimce/datos_envios.php"
```

## 🚨 Solución de Problemas

### **Error: "Connection refused"**
- ✅ Verificar que XAMPP esté ejecutándose
- ✅ Verificar que Apache esté iniciado

### **Error: "404 Not Found"**
- ✅ Verificar que el archivo esté en la carpeta correcta
- ✅ Verificar que la URL sea correcta

### **Error: "500 Internal Server Error"**
- ✅ Verificar configuración en `config.ini`
- ✅ Verificar que MySQL esté ejecutándose
- ✅ Verificar credenciales de base de datos

### **Error: "CORS" en Android**
- ✅ Verificar headers en `datos_envios.php`
- ✅ Verificar que la URL sea accesible desde el dispositivo

### **Error: "API key inválida"**
- ✅ Verificar que `API_KEY` en Android coincida con `api_key` en `config.ini`

## 📱 Prueba de Funcionamiento

### **1. Probar desde navegador:**
```
http://localhost/ssimce/datos_envios.php
```

### **2. Probar desde Android:**
- Abrir app SSIMCE
- Ir a "Envíos"
- Llenar formulario MRB o CT
- Presionar "Guardar"

### **3. Verificar en base de datos:**
- Abrir phpMyAdmin
- Ir a tabla `mrb_registros` o `ct_registros`
- Verificar que se guardó el registro

## 📁 Estructura Final

```
D:\Programas Instalados\XAMPP\htdocs\ssimce\
├── datos_envios.php          # API PHP
├── config.ini               # Configuración BD
└── database_tables.sql      # Estructura BD

C:\Users\hp\Desktop\Funcional\tablas\SSIMCE\
├── app\src\main\java\com\example\ssimce\envios\
│   └── MainActivityEnvios.kt  # App Android
└── [otros archivos del proyecto]
```

## ✅ Checklist de Verificación

- [ ] XAMPP ejecutándose (Apache + MySQL)
- [ ] Archivos PHP en htdocs/ssimce/
- [ ] Base de datos creada en MySQL
- [ ] config.ini configurado
- [ ] URL configurada en MainActivityEnvios.kt
- [ ] API_KEY configurada en ambos lados
- [ ] App compilada e instalada
- [ ] Prueba de conexión exitosa

---

**¡Listo! Tu app Android ya puede comunicarse con el servidor PHP** 🎯 