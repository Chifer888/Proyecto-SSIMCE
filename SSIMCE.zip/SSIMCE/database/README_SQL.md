# 📊 Archivos SQL - SSIMCE

## 📁 Estructura de Archivos SQL

### ✅ **Archivos SQL Principales**

#### 🆕 **Archivos Actualizados (Diciembre 2024)**

1. **`ssimce_tablas_completas_actualizado.sql`**
   - **Descripción**: Script completo con todas las tablas actualizadas
   - **Contenido**: 8 tablas principales + 2 vistas + datos de prueba
   - **Estado**: ✅ Completamente funcional
   - **Uso**: Instalación completa de la base de datos

2. **`tablas_esenciales.sql`**
   - **Descripción**: Solo las tablas esenciales que se usan en la app
   - **Contenido**: 8 tablas principales + 1 vista
   - **Estado**: ✅ Completamente funcional
   - **Uso**: Instalación rápida y limpia

3. **`eliminar_campo_imagen.sql`**
   - **Descripción**: Script para eliminar campo imagen_url de catalogo_productos
   - **Contenido**: Comandos ALTER TABLE para limpiar estructura
   - **Estado**: ✅ Listo para usar
   - **Uso**: Migración de tablas existentes

#### 📚 **Archivos SQL Existentes**

4. **`crear_tabla_usuarios.sql`**
   - **Descripción**: Creación de tabla usuarios con roles
   - **Contenido**: Estructura de usuarios + usuario admin por defecto
   - **Estado**: ✅ Funcional
   - **Uso**: Gestión de usuarios y permisos

5. **`crear_tabla_catalogo_productos.sql`**
   - **Descripción**: Estructura de catálogo de productos
   - **Contenido**: Tabla sin campo de imagen
   - **Estado**: ✅ Actualizado
   - **Uso**: Gestión de productos

6. **`crear_tabla_entradas.sql`**
   - **Descripción**: Estructura para entradas de inventario
   - **Contenido**: Tabla con tipos de entrada
   - **Estado**: ✅ Funcional
   - **Uso**: Registro de entradas

7. **`crear_tabla_irregularidades.sql`**
   - **Descripción**: Gestión de irregularidades
   - **Contenido**: Tabla con evidencia multimedia
   - **Estado**: ✅ Funcional
   - **Uso**: Control de irregularidades

8. **`crear_tablas_entradas_salidas_corregido.sql`**
   - **Descripción**: Tablas de entradas y salidas corregidas
   - **Contenido**: Estructura corregida sin FULL OUTER JOIN
   - **Estado**: ✅ Corregido
   - **Uso**: Sistema de inventario

9. **`crear_vista_stock_disponible.sql`**
   - **Descripción**: Vista para cálculo de stock
   - **Contenido**: Vista con LEFT JOINs
   - **Estado**: ✅ Funcional
   - **Uso**: Cálculo automático de stock

10. **`crear_tabla_guia.sql`**
    - **Descripción**: Estructura de guías de transporte
    - **Contenido**: Tabla con campos específicos
    - **Estado**: ✅ Funcional
    - **Uso**: Gestión de guías

#### 🔧 **Archivos SQL de Soporte**

11. **`agregar_columnas_evidencia.sql`**
    - **Descripción**: Agregar columnas de evidencia a tablas
    - **Contenido**: ALTER TABLE para evidencia multimedia
    - **Estado**: ✅ Funcional
    - **Uso**: Migración de tablas existentes

12. **`actualizar_tablas_envios.sql`**
    - **Descripción**: Actualizar tablas de envíos
    - **Contenido**: Estructura para envíos MRB/CT
    - **Estado**: ✅ Funcional
    - **Uso**: Sistema de envíos

## 📋 **Tablas Principales del Sistema**

### 📚 **1. catalogo_productos**
```sql
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- sku (VARCHAR(50), UNIQUE, NOT NULL)
- descripcion (TEXT, NOT NULL)
- fecha_creacion (TIMESTAMP)
- fecha_actualizacion (TIMESTAMP)
```

### 👥 **2. usuarios**
```sql
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- nombre (VARCHAR(100), NOT NULL)
- apellido (VARCHAR(100), NOT NULL)
- usuario (VARCHAR(50), UNIQUE, NOT NULL)
- password (VARCHAR(255), NOT NULL)
- perfil (ENUM: admin, supervisor, rampero, operador)
- email (VARCHAR(100))
- telefono (VARCHAR(20))
- activo (BOOLEAN, DEFAULT TRUE)
- fecha_creacion (TIMESTAMP)
- fecha_modificacion (TIMESTAMP)
```

### 📦 **3. entradas**
```sql
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- sku (VARCHAR(50), NOT NULL)
- descripcion (TEXT, NOT NULL)
- cantidad (INT, NOT NULL)
- tipo_entrada (VARCHAR(50), NOT NULL)
- fecha (TIMESTAMP)
- usuario (VARCHAR(50))
- observaciones (TEXT)
```

### 📤 **4. salidas**
```sql
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- sku (VARCHAR(50), NOT NULL)
- descripcion (TEXT, NOT NULL)
- cantidad (INT, NOT NULL)
- fecha (TIMESTAMP)
- usuario (VARCHAR(50))
- observaciones (TEXT)
```

### ⚠️ **5. irregularidades**
```sql
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- tipo (VARCHAR(50), NOT NULL)
- descripcion (TEXT, NOT NULL)
- evidencia (LONGBLOB)
- fecha (TIMESTAMP)
- usuario (VARCHAR(50))
- sincronizado (BOOLEAN, DEFAULT FALSE)
```

### 📄 **6. guia**
```sql
- id (VARCHAR(50), PRIMARY KEY)
- Bitacora (VARCHAR(100))
- Fecha (DATE)
- Camion (VARCHAR(100))
- Empleado (VARCHAR(100))
- Chofer (VARCHAR(100))
- Origen (VARCHAR(100))
- Destino (VARCHAR(100))
- Caja1 (VARCHAR(100))
- Caja2 (VARCHAR(100))
- Sello (VARCHAR(100))
- SelloRepuesto (VARCHAR(100))
- fecha_creacion (TIMESTAMP)
```

### 📋 **7. envios_mrb**
```sql
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- folio (VARCHAR(50), NOT NULL)
- fecha (DATE, NOT NULL)
- tienda (VARCHAR(100))
- observaciones (TEXT)
- evidencia (LONGBLOB)
- tipo_evidencia (VARCHAR(20))
- usuario (VARCHAR(50))
- fecha_creacion (TIMESTAMP)
```

### 📋 **8. envios_ct**
```sql
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- folio (VARCHAR(50), NOT NULL)
- fecha (DATE, NOT NULL)
- tienda (VARCHAR(100))
- observaciones (TEXT)
- evidencia (LONGBLOB)
- tipo_evidencia (VARCHAR(20))
- usuario (VARCHAR(50))
- fecha_creacion (TIMESTAMP)
```

## 🔍 **Vistas del Sistema**

### 📊 **v_stock_disponible**
```sql
- sku (VARCHAR)
- descripcion (TEXT)
- total_entradas (INT)
- total_salidas (INT)
- stock_disponible (INT)
```

## 🚀 **Instrucciones de Uso**

### 📥 **Instalación Completa**
```bash
# 1. Crear base de datos
CREATE DATABASE ssimce_db;

# 2. Ejecutar script completo
mysql -u root -p ssimce_db < database/scripts/ssimce_tablas_completas_actualizado.sql
```

### 📥 **Instalación Rápida**
```bash
# 1. Crear base de datos
CREATE DATABASE ssimce_db;

# 2. Ejecutar script esencial
mysql -u root -p ssimce_db < database/scripts/tablas_esenciales.sql
```

### 🔄 **Migración de Tablas Existentes**
```bash
# 1. Eliminar campo imagen
mysql -u root -p ssimce_db < database/scripts/eliminar_campo_imagen.sql

# 2. Agregar columnas de evidencia (si es necesario)
mysql -u root -p ssimce_db < database/scripts/agregar_columnas_evidencia.sql
```

## ✅ **Verificación de Instalación**

### 🔍 **Verificar Tablas**
```sql
-- Mostrar todas las tablas
SHOW TABLES;

-- Verificar estructura de catalogo_productos
DESCRIBE catalogo_productos;

-- Verificar vista de stock
SELECT * FROM v_stock_disponible LIMIT 5;
```

### 🔍 **Verificar Usuario Admin**
```sql
-- Verificar usuario administrador
SELECT id, nombre, apellido, usuario, perfil, activo 
FROM usuarios 
WHERE usuario = 'admin';
```

## 📝 **Notas Importantes**

### ✅ **Cambios Realizados**
1. **Eliminado campo imagen_url** de catalogo_productos
2. **Actualizada estructura de usuarios** con roles específicos
3. **Simplificada estructura** de entradas y salidas
4. **Agregadas tablas** de envíos MRB/CT
5. **Creadas vistas** para cálculo de stock
6. **Corregidos errores** de FULL OUTER JOIN

### 🎯 **Beneficios**
- **Menor complejidad** - Sin dependencias de imágenes
- **Mejor rendimiento** - Estructura optimizada
- **Fácil mantenimiento** - Código más limpio
- **Funcionalidad completa** - Todos los módulos operativos

### 🔧 **Compatibilidad**
- **MySQL**: 5.7+
- **Charset**: utf8mb4
- **Collation**: utf8mb4_unicode_ci
- **Engine**: InnoDB

---

**Estado**: ✅ Completamente funcional  
**Versión**: 2.0.0  
**Fecha**: Diciembre 2024  
**Compatibilidad**: Android 6.0+ y MySQL 5.7+ 