-- =====================================================
-- SCRIPT SQL PARA CREAR TABLA DE GUÍAS
-- Base de datos: ssimce_db
-- Fecha: 2024-01-15
-- Basado en: insertar_datos_guia.php
-- =====================================================

-- Crear tabla de guías
CREATE TABLE IF NOT EXISTS guia (
    id VARCHAR(50) PRIMARY KEY,
    Bitacora VARCHAR(50) NOT NULL,
    Fecha DATE,
    Camion VARCHAR(50),
    Empleado VARCHAR(100),
    Chofer VARCHAR(100),
    Origen VARCHAR(200),
    Destino VARCHAR(200),
    Caja1 VARCHAR(50),
    Caja2 VARCHAR(50),
    Sello VARCHAR(50),
    SelloRepuesto VARCHAR(50),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Índices para optimizar consultas
    INDEX idx_bitacora (Bitacora),
    INDEX idx_fecha (Fecha),
    INDEX idx_camion (Camion),
    INDEX idx_empleado (Empleado),
    INDEX idx_origen (Origen),
    INDEX idx_destino (Destino),
    INDEX idx_fecha_creacion (fecha_creacion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Crear vista para consultas frecuentes
CREATE OR REPLACE VIEW v_guias_recientes AS
SELECT 
    id,
    Bitacora,
    Fecha,
    Camion,
    Empleado,
    Chofer,
    Origen,
    Destino,
    Caja1,
    Caja2,
    Sello,
    SelloRepuesto,
    fecha_creacion
FROM guia 
WHERE Fecha >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
ORDER BY Fecha DESC, fecha_creacion DESC;

-- Crear vista para estadísticas
CREATE OR REPLACE VIEW v_estadisticas_guias AS
SELECT 
    DATE(Fecha) as fecha_dia,
    COUNT(*) as total_guias,
    COUNT(DISTINCT Camion) as camiones_unicos,
    COUNT(DISTINCT Empleado) as empleados_unicos,
    COUNT(DISTINCT Origen) as origenes_unicos,
    COUNT(DISTINCT Destino) as destinos_unicos
FROM guia 
WHERE Fecha >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
GROUP BY DATE(Fecha)
ORDER BY fecha_dia DESC;

-- Crear procedimiento almacenado para insertar guía
DELIMITER //
CREATE PROCEDURE sp_insertar_guia(
    IN p_id VARCHAR(50),
    IN p_bitacora VARCHAR(50),
    IN p_fecha DATE,
    IN p_camion VARCHAR(50),
    IN p_empleado VARCHAR(100),
    IN p_chofer VARCHAR(100),
    IN p_origen VARCHAR(200),
    IN p_destino VARCHAR(200),
    IN p_caja1 VARCHAR(50),
    IN p_caja2 VARCHAR(50),
    IN p_sello VARCHAR(50),
    IN p_sello_repuesto VARCHAR(50)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    INSERT INTO guia (
        id, Bitacora, Fecha, Camion, Empleado, Chofer, 
        Origen, Destino, Caja1, Caja2, Sello, SelloRepuesto
    ) VALUES (
        p_id, p_bitacora, p_fecha, p_camion, p_empleado, p_chofer,
        p_origen, p_destino, p_caja1, p_caja2, p_sello, p_sello_repuesto
    );
    
    COMMIT;
    
    SELECT 
        'success' as status,
        'Guía registrada exitosamente' as message,
        p_id as id_insertado;
END //
DELIMITER ;

-- Crear procedimiento almacenado para obtener guías por fecha
DELIMITER //
CREATE PROCEDURE sp_obtener_guias_por_fecha(
    IN p_fecha_inicio DATE,
    IN p_fecha_fin DATE
)
BEGIN
    SELECT 
        id,
        Bitacora,
        Fecha,
        Camion,
        Empleado,
        Chofer,
        Origen,
        Destino,
        Caja1,
        Caja2,
        Sello,
        SelloRepuesto,
        fecha_creacion
    FROM guia 
    WHERE Fecha BETWEEN p_fecha_inicio AND p_fecha_fin
    ORDER BY Fecha DESC, fecha_creacion DESC;
END //
DELIMITER ;

-- Crear procedimiento almacenado para buscar por bitácora
DELIMITER //
CREATE PROCEDURE sp_buscar_por_bitacora(
    IN p_bitacora VARCHAR(50)
)
BEGIN
    SELECT 
        id,
        Bitacora,
        Fecha,
        Camion,
        Empleado,
        Chofer,
        Origen,
        Destino,
        Caja1,
        Caja2,
        Sello,
        SelloRepuesto,
        fecha_creacion
    FROM guia 
    WHERE Bitacora LIKE CONCAT('%', p_bitacora, '%')
    ORDER BY fecha_creacion DESC;
END //
DELIMITER ;

-- Insertar datos de ejemplo (opcional)
INSERT INTO guia (id, Bitacora, Fecha, Camion, Empleado, Chofer, Origen, Destino, Caja1, Caja2, Sello, SelloRepuesto) VALUES
('G001-2024-001', 'B001-2024-001', '2024-01-15', 'CAM001', 'Juan Pérez', 'Carlos López', 'Centro de Distribución Norte', 'Almacén Central', 'CAJ001', 'CAJ002', 'SEL001', 'SEL001-R'),
('G001-2024-002', 'B001-2024-002', '2024-01-15', 'CAM002', 'María García', 'Luis Rodríguez', 'Centro de Distribución Sur', 'Almacén Regional', 'CAJ003', 'CAJ004', 'SEL002', 'SEL002-R'),
('G001-2024-003', 'B001-2024-003', '2024-01-15', 'CAM003', 'Ana Martínez', 'Diego Morales', 'Centro de Distribución Este', 'Punto de Venta', 'CAJ005', 'CAJ006', 'SEL003', 'SEL003-R'),
('G001-2024-004', 'B001-2024-004', '2024-01-15', 'CAM004', 'Sofia Torres', 'Roberto Vargas', 'Centro de Distribución Oeste', 'Centro Logístico', 'CAJ007', 'CAJ008', 'SEL004', 'SEL004-R'),
('G001-2024-005', 'B001-2024-005', '2024-01-15', 'CAM005', 'Carmen Silva', 'Pedro Ruiz', 'Almacén Principal', 'Centro de Distribución', 'CAJ009', 'CAJ010', 'SEL005', 'SEL005-R');

-- Otorgar permisos al usuario de la aplicación
GRANT SELECT, INSERT, UPDATE, DELETE ON ssimce_db.guia TO 'ssimce_user'@'localhost';
GRANT SELECT ON ssimce_db.v_guias_recientes TO 'ssimce_user'@'localhost';
GRANT SELECT ON ssimce_db.v_estadisticas_guias TO 'ssimce_user'@'localhost';
GRANT EXECUTE ON PROCEDURE ssimce_db.sp_insertar_guia TO 'ssimce_user'@'localhost';
GRANT EXECUTE ON PROCEDURE ssimce_db.sp_obtener_guias_por_fecha TO 'ssimce_user'@'localhost';
GRANT EXECUTE ON PROCEDURE ssimce_db.sp_buscar_por_bitacora TO 'ssimce_user'@'localhost';

-- Aplicar cambios
FLUSH PRIVILEGES;

-- Mostrar información de la tabla creada
SELECT 
    TABLE_NAME,
    TABLE_ROWS,
    DATA_LENGTH,
    INDEX_LENGTH,
    (DATA_LENGTH + INDEX_LENGTH) as TOTAL_SIZE
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = 'ssimce_db' AND TABLE_NAME = 'guia';

-- Mostrar estructura de la tabla
DESCRIBE guia; 