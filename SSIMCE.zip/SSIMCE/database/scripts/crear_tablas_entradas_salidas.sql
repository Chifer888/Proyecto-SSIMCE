-- =====================================================
-- SCRIPT PARA CREAR TABLAS: entradas y salidas
-- Base de datos: ssimce_db
-- =====================================================
USE ssimce_db;

-- Tabla para registrar entradas de productos
CREATE TABLE IF NOT EXISTS entradas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(50) NOT NULL,
    descripcion VARCHAR(255) NOT NULL,
    cantidad DECIMAL(10,2) NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario VARCHAR(100),
    folio_entrada VARCHAR(50),
    tipo_entrada ENUM('ENTREGA_CLIENTE', 'SURTIDO_TIENDA', 'ROPA', 'LOTEO_JABAS', 'GUIA', 'BITACORA') NOT NULL,
    observaciones TEXT,
    INDEX idx_sku (sku),
    INDEX idx_fecha (fecha),
    INDEX idx_tipo_entrada (tipo_entrada),
    INDEX idx_folio_entrada (folio_entrada)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla para registrar salidas de productos
CREATE TABLE IF NOT EXISTS salidas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(50) NOT NULL,
    descripcion VARCHAR(255) NOT NULL,
    cantidad DECIMAL(10,2) NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario VARCHAR(100),
    folio_salida VARCHAR(50),
    tipo_salida ENUM('SALIDA_NORMAL', 'IRREGULARIDAD') NOT NULL,
    observaciones TEXT,
    INDEX idx_sku (sku),
    INDEX idx_fecha (fecha),
    INDEX idx_tipo_salida (tipo_salida),
    INDEX idx_folio_salida (folio_salida)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Vista para calcular stock disponible (compatible con MySQL)
CREATE OR REPLACE VIEW v_stock_disponible AS
SELECT 
    p.sku,
    p.descripcion,
    COALESCE(SUM(e.cantidad), 0) as total_entradas,
    COALESCE(SUM(s.cantidad), 0) as total_salidas,
    (COALESCE(SUM(e.cantidad), 0) - COALESCE(SUM(s.cantidad), 0)) as stock_disponible
FROM catalogo_productos p
LEFT JOIN entradas e ON p.sku = e.sku
LEFT JOIN salidas s ON p.sku = s.sku
GROUP BY p.sku, p.descripcion;

-- Vista alternativa para calcular stock disponible (sin depender de catalogo_productos)
CREATE OR REPLACE VIEW v_stock_disponible_alt AS
SELECT 
    sku,
    MAX(descripcion) as descripcion,
    COALESCE(SUM(CASE WHEN tipo = 'entrada' THEN cantidad ELSE 0 END), 0) as total_entradas,
    COALESCE(SUM(CASE WHEN tipo = 'salida' THEN cantidad ELSE 0 END), 0) as total_salidas,
    (COALESCE(SUM(CASE WHEN tipo = 'entrada' THEN cantidad ELSE 0 END), 0) - 
     COALESCE(SUM(CASE WHEN tipo = 'salida' THEN cantidad ELSE 0 END), 0)) as stock_disponible
FROM (
    SELECT sku, descripcion, cantidad, 'entrada' as tipo FROM entradas
    UNION ALL
    SELECT sku, descripcion, cantidad, 'salida' as tipo FROM salidas
) combined_data
GROUP BY sku;

-- Procedimiento almacenado para insertar entrada
DELIMITER //
CREATE PROCEDURE sp_insertar_entrada(
    IN p_sku VARCHAR(50),
    IN p_descripcion VARCHAR(255),
    IN p_cantidad DECIMAL(10,2),
    IN p_usuario VARCHAR(100),
    IN p_folio_entrada VARCHAR(50),
    IN p_tipo_entrada ENUM('ENTREGA_CLIENTE', 'SURTIDO_TIENDA', 'ROPA', 'LOTEO_JABAS', 'GUIA', 'BITACORA'),
    IN p_observaciones TEXT
)
BEGIN
    INSERT INTO entradas (sku, descripcion, cantidad, usuario, folio_entrada, tipo_entrada, observaciones)
    VALUES (p_sku, p_descripcion, p_cantidad, p_usuario, p_folio_entrada, p_tipo_entrada, p_observaciones);
END //
DELIMITER ;

-- Procedimiento almacenado para insertar salida
DELIMITER //
CREATE PROCEDURE sp_insertar_salida(
    IN p_sku VARCHAR(50),
    IN p_descripcion VARCHAR(255),
    IN p_cantidad DECIMAL(10,2),
    IN p_usuario VARCHAR(100),
    IN p_folio_salida VARCHAR(50),
    IN p_tipo_salida ENUM('SALIDA_NORMAL', 'IRREGULARIDAD'),
    IN p_observaciones TEXT
)
BEGIN
    INSERT INTO salidas (sku, descripcion, cantidad, usuario, folio_salida, tipo_salida, observaciones)
    VALUES (p_sku, p_descripcion, p_cantidad, p_usuario, p_folio_salida, p_tipo_salida, p_observaciones);
END //
DELIMITER ;

-- Procedimiento almacenado para obtener stock de un SKU
DELIMITER //
CREATE PROCEDURE sp_obtener_stock_sku(
    IN p_sku VARCHAR(50)
)
BEGIN
    SELECT 
        p.sku,
        p.descripcion,
        p.imagen_url,
        COALESCE(SUM(e.cantidad), 0) as total_entradas,
        COALESCE(SUM(s.cantidad), 0) as total_salidas,
        (COALESCE(SUM(e.cantidad), 0) - COALESCE(SUM(s.cantidad), 0)) as stock_disponible
    FROM catalogo_productos p
    LEFT JOIN entradas e ON p.sku = e.sku
    LEFT JOIN salidas s ON p.sku = s.sku
    WHERE p.sku = p_sku
    GROUP BY p.sku, p.descripcion, p.imagen_url;
END //
DELIMITER ;

-- Datos de prueba para entradas
INSERT INTO entradas (sku, descripcion, cantidad, usuario, folio_entrada, tipo_entrada, observaciones) VALUES
('SKU001', 'Producto de prueba 1 - Electrónicos', 10.0, 'admin', 'ENT-001', 'ENTREGA_CLIENTE', 'Entrada inicial'),
('SKU001', 'Producto de prueba 1 - Electrónicos', 5.0, 'admin', 'ENT-002', 'SURTIDO_TIENDA', 'Reposición'),
('SKU002', 'Producto de prueba 2 - Ropa', 20.0, 'admin', 'ENT-003', 'ROPA', 'Entrada de ropa'),
('SKU003', 'Producto de prueba 3 - Hogar', 15.0, 'admin', 'ENT-004', 'LOTEO_JABAS', 'Entrada de loteo'),
('SKU004', 'Producto de prueba 4 - Deportes', 8.0, 'admin', 'ENT-005', 'GUIA', 'Entrada por guía'),
('SKU005', 'Producto de prueba 5 - Electrónicos', 12.0, 'admin', 'ENT-006', 'BITACORA', 'Entrada por bitácora');

-- Datos de prueba para salidas
INSERT INTO salidas (sku, descripcion, cantidad, usuario, folio_salida, tipo_salida, observaciones) VALUES
('SKU001', 'Producto de prueba 1 - Electrónicos', 3.0, 'admin', 'SAL-001', 'SALIDA_NORMAL', 'Venta'),
('SKU001', 'Producto de prueba 1 - Electrónicos', 2.0, 'admin', 'SAL-002', 'SALIDA_NORMAL', 'Transferencia'),
('SKU002', 'Producto de prueba 2 - Ropa', 5.0, 'admin', 'SAL-003', 'SALIDA_NORMAL', 'Venta'),
('SKU003', 'Producto de prueba 3 - Hogar', 1.0, 'admin', 'SAL-004', 'IRREGULARIDAD', 'Producto dañado'),
('SKU004', 'Producto de prueba 4 - Deportes', 2.0, 'admin', 'SAL-005', 'SALIDA_NORMAL', 'Venta');

-- Trigger para actualizar automáticamente la fecha de modificación
DELIMITER //
CREATE TRIGGER tr_entradas_before_insert
BEFORE INSERT ON entradas
FOR EACH ROW
BEGIN
    SET NEW.fecha = CURRENT_TIMESTAMP;
END //
DELIMITER ;

DELIMITER //
CREATE TRIGGER tr_salidas_before_insert
BEFORE INSERT ON salidas
FOR EACH ROW
BEGIN
    SET NEW.fecha = CURRENT_TIMESTAMP;
END //
DELIMITER ; 