-- Crear tabla entradas si no existe
CREATE TABLE IF NOT EXISTS entradas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(50) NOT NULL,
    descripcion TEXT NOT NULL,
    cantidad INT NOT NULL,
    tipo_entrada VARCHAR(100) NOT NULL,
    observaciones TEXT,
    usuario VARCHAR(50) DEFAULT 'admin',
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_sku (sku),
    INDEX idx_fecha (fecha_registro),
    INDEX idx_tipo_entrada (tipo_entrada)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insertar datos de ejemplo (opcional)
INSERT INTO entradas (sku, descripcion, cantidad, tipo_entrada, observaciones, usuario) VALUES
('SKU001', 'Producto de prueba 1', 10, 'Entregas a Clientes', 'Entrada de prueba', 'admin'),
('SKU002', 'Producto de prueba 2', 5, 'Surtido Tiendas', 'Entrada de prueba', 'admin'),
('SKU003', 'Producto de prueba 3', 15, 'Loteo Jabas', 'Entrada de prueba', 'admin');

-- Crear vista para entradas recientes
CREATE OR REPLACE VIEW v_entradas_recientes AS
SELECT 
    id,
    sku,
    descripcion,
    cantidad,
    tipo_entrada,
    observaciones,
    usuario,
    fecha_registro
FROM entradas 
ORDER BY fecha_registro DESC 
LIMIT 100;

-- Crear procedimiento almacenado para insertar entrada
DELIMITER //
CREATE PROCEDURE sp_insertar_entrada(
    IN p_sku VARCHAR(50),
    IN p_descripcion TEXT,
    IN p_cantidad INT,
    IN p_tipo_entrada VARCHAR(100),
    IN p_observaciones TEXT,
    IN p_usuario VARCHAR(50)
)
BEGIN
    INSERT INTO entradas (sku, descripcion, cantidad, tipo_entrada, observaciones, usuario)
    VALUES (p_sku, p_descripcion, p_cantidad, p_tipo_entrada, p_observaciones, p_usuario);
    
    SELECT 'Entrada registrada exitosamente' AS mensaje;
END //
DELIMITER ; 