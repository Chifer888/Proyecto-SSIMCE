-- =====================================================
-- SCRIPT PARA ELIMINAR CAMPO DE IMAGEN DE CATÁLOGO
-- Base de datos: ssimce_db
-- Fecha: Diciembre 2024
-- =====================================================

USE ssimce_db;

-- =====================================================
-- ELIMINAR CAMPO imagen_url DE catalogo_productos
-- =====================================================

-- Verificar si existe el campo imagen_url
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE 
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'ssimce_db' 
AND TABLE_NAME = 'catalogo_productos' 
AND COLUMN_NAME = 'imagen_url';

-- Eliminar el campo imagen_url si existe
ALTER TABLE catalogo_productos 
DROP COLUMN IF EXISTS imagen_url;

-- Verificar la estructura actualizada
DESCRIBE catalogo_productos;

-- =====================================================
-- ACTUALIZAR ESTRUCTURA DE TABLA
-- =====================================================

-- Asegurar que la tabla tenga la estructura correcta
ALTER TABLE catalogo_productos 
MODIFY COLUMN descripcion TEXT NOT NULL,
MODIFY COLUMN fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
MODIFY COLUMN fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Verificar índices
SHOW INDEX FROM catalogo_productos;

-- =====================================================
-- VERIFICACIÓN FINAL
-- =====================================================

-- Mostrar estructura final
SELECT 
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE,
    COLUMN_DEFAULT,
    EXTRA
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = 'ssimce_db' 
AND TABLE_NAME = 'catalogo_productos'
ORDER BY ORDINAL_POSITION;

-- =====================================================
-- NOTAS
-- =====================================================

/*
CAMBIOS REALIZADOS:
1. Eliminado campo imagen_url de catalogo_productos
2. Mantenido campo descripcion como TEXT
3. Mantenidos índices en sku y descripcion
4. Mantenidos timestamps de creación y actualización

BENEFICIOS:
- Menor uso de almacenamiento
- Estructura más simple
- Sin dependencias de imágenes
- Mejor rendimiento en consultas
*/

-- =====================================================
-- FIN DEL SCRIPT
-- ===================================================== 