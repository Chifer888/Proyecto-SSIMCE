-- =====================================================
-- SCRIPT DE TABLAS ESENCIALES PARA SSIMCE
-- Base de datos: ssimce_db
-- Fecha: Diciembre 2024
-- Estado: Completamente funcional
-- =====================================================

USE ssimce_db;

-- =====================================================
-- 1. TABLA: catalogo_productos (Sin imágenes)
-- =====================================================
CREATE TABLE IF NOT EXISTS catalogo_productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(50) NOT NULL UNIQUE,
    descripcion TEXT NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_sku (sku),
    INDEX idx_descripcion (descripcion(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 2. TABLA: usuarios (Con roles)
-- =====================================================
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    perfil ENUM('admin', 'supervisor', 'rampero', 'operador') DEFAULT 'operador',
    email VARCHAR(100),
    telefono VARCHAR(20),
    activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_usuario (usuario),
    INDEX idx_perfil (perfil),
    INDEX idx_activo (activo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Usuario administrador por defecto
INSERT INTO usuarios (nombre, apellido, usuario, password, perfil, email, activo) 
VALUES ('Administrador', 'Sistema', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'admin@ssimce.com', TRUE)
ON DUPLICATE KEY UPDATE id = id;

-- =====================================================
-- 3. TABLA: entradas
-- =====================================================
CREATE TABLE IF NOT EXISTS entradas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(50) NOT NULL,
    descripcion TEXT NOT NULL,
    cantidad INT NOT NULL,
    tipo_entrada VARCHAR(50) NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario VARCHAR(50),
    observaciones TEXT,
    INDEX idx_sku (sku),
    INDEX idx_fecha (fecha),
    INDEX idx_tipo_entrada (tipo_entrada),
    INDEX idx_usuario (usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 4. TABLA: salidas
-- =====================================================
CREATE TABLE IF NOT EXISTS salidas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(50) NOT NULL,
    descripcion TEXT NOT NULL,
    cantidad INT NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario VARCHAR(50),
    observaciones TEXT,
    INDEX idx_sku (sku),
    INDEX idx_fecha (fecha),
    INDEX idx_usuario (usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 5. TABLA: irregularidades
-- =====================================================
CREATE TABLE IF NOT EXISTS irregularidades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(50) NOT NULL,
    descripcion TEXT NOT NULL,
    evidencia LONGBLOB,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario VARCHAR(50),
    sincronizado BOOLEAN DEFAULT FALSE,
    INDEX idx_tipo (tipo),
    INDEX idx_fecha (fecha),
    INDEX idx_usuario (usuario),
    INDEX idx_sincronizado (sincronizado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 6. TABLA: guia
-- =====================================================
CREATE TABLE IF NOT EXISTS guia (
    id VARCHAR(50) PRIMARY KEY,
    Bitacora VARCHAR(100),
    Fecha DATE,
    Camion VARCHAR(100),
    Empleado VARCHAR(100),
    Chofer VARCHAR(100),
    Origen VARCHAR(100),
    Destino VARCHAR(100),
    Caja1 VARCHAR(100),
    Caja2 VARCHAR(100),
    Sello VARCHAR(100),
    SelloRepuesto VARCHAR(100),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_fecha (Fecha),
    INDEX idx_bitacora (Bitacora),
    INDEX idx_camion (Camion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 7. TABLA: envios_mrb
-- =====================================================
CREATE TABLE IF NOT EXISTS envios_mrb (
    id INT AUTO_INCREMENT PRIMARY KEY,
    folio VARCHAR(50) NOT NULL,
    fecha DATE NOT NULL,
    tienda VARCHAR(100),
    observaciones TEXT,
    evidencia LONGBLOB,
    tipo_evidencia VARCHAR(20),
    usuario VARCHAR(50),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_folio (folio),
    INDEX idx_fecha (fecha),
    INDEX idx_tienda (tienda),
    INDEX idx_usuario (usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 8. TABLA: envios_ct
-- =====================================================
CREATE TABLE IF NOT EXISTS envios_ct (
    id INT AUTO_INCREMENT PRIMARY KEY,
    folio VARCHAR(50) NOT NULL,
    fecha DATE NOT NULL,
    tienda VARCHAR(100),
    observaciones TEXT,
    evidencia LONGBLOB,
    tipo_evidencia VARCHAR(20),
    usuario VARCHAR(50),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_folio (folio),
    INDEX idx_fecha (fecha),
    INDEX idx_tienda (tienda),
    INDEX idx_usuario (usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 9. VISTA: v_stock_disponible
-- =====================================================
CREATE OR REPLACE VIEW v_stock_disponible AS
SELECT 
    COALESCE(e.sku, s.sku) as sku,
    COALESCE(e.descripcion, s.descripcion) as descripcion,
    COALESCE(SUM(e.cantidad), 0) as total_entradas,
    COALESCE(SUM(s.cantidad), 0) as total_salidas,
    (COALESCE(SUM(e.cantidad), 0) - COALESCE(SUM(s.cantidad), 0)) as stock_disponible
FROM (
    SELECT sku, descripcion, cantidad FROM entradas
    UNION ALL
    SELECT sku, descripcion, 0 as cantidad FROM salidas
) e
LEFT JOIN (
    SELECT sku, descripcion, cantidad FROM salidas
    UNION ALL
    SELECT sku, descripcion, 0 as cantidad FROM entradas
) s ON e.sku = s.sku
GROUP BY COALESCE(e.sku, s.sku), COALESCE(e.descripcion, s.descripcion);

-- =====================================================
-- VERIFICACIÓN
-- =====================================================

-- Mostrar tablas creadas
SELECT TABLE_NAME, TABLE_ROWS, ENGINE 
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = 'ssimce_db' 
ORDER BY TABLE_NAME;

-- Mostrar vistas
SELECT TABLE_NAME, VIEW_DEFINITION 
FROM information_schema.VIEWS 
WHERE TABLE_SCHEMA = 'ssimce_db';

-- =====================================================
-- FIN DEL SCRIPT
-- ===================================================== 