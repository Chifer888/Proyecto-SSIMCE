-- =====================================================
-- SCRIPT PARA CREAR TABLAS DE BITÁCORA
-- Base de datos: ssimce_db
-- Fecha: 2024-01-15
-- =====================================================

USE ssimce_db;

-- =====================================================
-- TABLA PRINCIPAL: bitacora
-- =====================================================
CREATE TABLE IF NOT EXISTS bitacora (
    id VARCHAR(50) PRIMARY KEY,
    Bitacora VARCHAR(50) NOT NULL,
    Fecha DATE,
    Caja VARCHAR(50),
    Sello VARCHAR(50),
    Sello_De_Repuesto VARCHAR(50),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_id (id),
    INDEX idx_bitacora (Bitacora),
    INDEX idx_fecha (Fecha),
    INDEX idx_caja (Caja),
    INDEX idx_sello (Sello),
    INDEX idx_fecha_creacion (fecha_creacion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLA DE LÍNEAS: lineas_bitacora
-- =====================================================
CREATE TABLE IF NOT EXISTS lineas_bitacora (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_Bitacora VARCHAR(50) NOT NULL,
    Tipo VARCHAR(50),
    Folio VARCHAR(50),
    Destino VARCHAR(200),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_id_bitacora (id_Bitacora),
    INDEX idx_tipo (Tipo),
    INDEX idx_folio (Folio),
    INDEX idx_destino (Destino),
    INDEX idx_fecha_creacion (fecha_creacion),
    FOREIGN KEY (id_Bitacora) REFERENCES bitacora(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- VISTA PARA CONSULTAR BITÁCORA CON LÍNEAS
-- =====================================================
CREATE OR REPLACE VIEW vista_bitacora_completa AS
SELECT 
    b.id,
    b.Bitacora,
    b.Fecha,
    b.Caja,
    b.Sello,
    b.Sello_De_Repuesto,
    b.fecha_creacion,
    b.fecha_actualizacion,
    lb.Tipo,
    lb.Folio,
    lb.Destino
FROM bitacora b
LEFT JOIN lineas_bitacora lb ON b.id = lb.id_Bitacora
ORDER BY b.fecha_creacion DESC, lb.id ASC;

-- =====================================================
-- PROCEDIMIENTO PARA INSERTAR BITÁCORA CON LÍNEAS
-- =====================================================
DELIMITER //
CREATE PROCEDURE InsertarBitacoraCompleta(
    IN p_id VARCHAR(50),
    IN p_bitacora VARCHAR(50),
    IN p_fecha DATE,
    IN p_caja VARCHAR(50),
    IN p_sello VARCHAR(50),
    IN p_sello_repuesto VARCHAR(50),
    IN p_lineas_serializadas TEXT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- Insertar en tabla principal
    INSERT INTO bitacora (id, Bitacora, Fecha, Caja, Sello, Sello_De_Repuesto)
    VALUES (p_id, p_bitacora, p_fecha, p_caja, p_sello, p_sello_repuesto);
    
    -- Insertar líneas si existen
    IF p_lineas_serializadas IS NOT NULL AND p_lineas_serializadas != '' THEN
        SET @lineas = p_lineas_serializadas;
        SET @pos = 1;
        
        WHILE @pos > 0 DO
            SET @linea = SUBSTRING_INDEX(@lineas, '|', 1);
            SET @lineas = SUBSTRING(@lineas, LENGTH(@linea) + 2);
            
            IF @linea != '' THEN
                SET @tipo = SUBSTRING_INDEX(@linea, ':', 1);
                SET @resto = SUBSTRING(@linea, LENGTH(@tipo) + 2);
                SET @folio = SUBSTRING_INDEX(@resto, ':', 1);
                SET @destino = SUBSTRING(@resto, LENGTH(@folio) + 2);
                
                INSERT INTO lineas_bitacora (id_Bitacora, Tipo, Folio, Destino)
                VALUES (p_id, TRIM(@tipo), TRIM(@folio), TRIM(@destino));
            END IF;
            
            SET @pos = LOCATE('|', @lineas);
        END WHILE;
    END IF;
    
    COMMIT;
END //
DELIMITER ;

-- =====================================================
-- PROCEDIMIENTO PARA OBTENER BITÁCORA POR ID
-- =====================================================
DELIMITER //
CREATE PROCEDURE ObtenerBitacoraPorId(IN p_id VARCHAR(50))
BEGIN
    SELECT 
        b.id,
        b.Bitacora,
        b.Fecha,
        b.Caja,
        b.Sello,
        b.Sello_De_Repuesto,
        b.fecha_creacion,
        b.fecha_actualizacion,
        lb.Tipo,
        lb.Folio,
        lb.Destino
    FROM bitacora b
    LEFT JOIN lineas_bitacora lb ON b.id = lb.id_Bitacora
    WHERE b.id = p_id
    ORDER BY lb.id ASC;
END //
DELIMITER ;

-- =====================================================
-- PROCEDIMIENTO PARA OBTENER TODAS LAS BITÁCORAS
-- =====================================================
DELIMITER //
CREATE PROCEDURE ObtenerTodasBitacoras()
BEGIN
    SELECT 
        b.id,
        b.Bitacora,
        b.Fecha,
        b.Caja,
        b.Sello,
        b.Sello_De_Repuesto,
        b.fecha_creacion,
        b.fecha_actualizacion,
        COUNT(lb.id) as total_lineas
    FROM bitacora b
    LEFT JOIN lineas_bitacora lb ON b.id = lb.id_Bitacora
    GROUP BY b.id
    ORDER BY b.fecha_creacion DESC;
END //
DELIMITER ;

-- =====================================================
-- DATOS DE PRUEBA (OPCIONAL)
-- =====================================================
-- INSERT INTO bitacora (id, Bitacora, Fecha, Caja, Sello, Sello_De_Repuesto) 
-- VALUES ('BIT001', 'BIT-2024-001', '2024-01-15', 'CAJA001', 'SELLO001', 'REP001');

-- INSERT INTO lineas_bitacora (id_Bitacora, Tipo, Folio, Destino) 
-- VALUES ('BIT001', 'Guía', 'GUI001', 'Destino A');

-- =====================================================
-- VERIFICACIÓN DE TABLAS CREADAS
-- =====================================================
SELECT 'Tabla bitacora creada correctamente' as mensaje;
SHOW TABLES LIKE 'bitacora';

SELECT 'Tabla lineas_bitacora creada correctamente' as mensaje;
SHOW TABLES LIKE 'lineas_bitacora';

SELECT 'Vista vista_bitacora_completa creada correctamente' as mensaje;
SHOW TABLES LIKE 'vista_bitacora_completa';

SELECT 'Procedimientos almacenados creados correctamente' as mensaje;
SHOW PROCEDURE STATUS WHERE Db = 'ssimce_db' AND Name LIKE '%Bitacora%'; 