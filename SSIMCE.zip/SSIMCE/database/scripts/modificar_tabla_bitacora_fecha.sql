-- =====================================================
-- SCRIPT PARA MODIFICAR TABLA BITÁCORA - FECHA FLEXIBLE
-- Base de datos: ssimce_db
-- Fecha: 2024-01-15
-- =====================================================

USE ssimce_db;

-- =====================================================
-- OPCIÓN 1: CAMBIAR TIPO DE DATO A VARCHAR (MÁS FLEXIBLE)
-- =====================================================

-- Modificar la columna Fecha para aceptar cualquier formato
ALTER TABLE bitacora MODIFY COLUMN Fecha VARCHAR(20) COMMENT 'Fecha en formato flexible (dd/mes/yyyy o yyyy-mm-dd)';

-- =====================================================
-- OPCIÓN 2: AGREGAR COLUMNA ADICIONAL PARA FECHA ORIGINAL
-- =====================================================

-- Agregar columna para fecha original (opcional)
ALTER TABLE bitacora ADD COLUMN Fecha_Original VARCHAR(50) COMMENT 'Fecha original tal como se ingresó' AFTER Fecha;

-- =====================================================
-- OPCIÓN 3: CREAR TABLA TEMPORAL CON FECHA FLEXIBLE
-- =====================================================

-- Crear tabla temporal con fecha flexible
CREATE TABLE IF NOT EXISTS bitacora_temp (
    id VARCHAR(50) PRIMARY KEY,
    Bitacora VARCHAR(50) NOT NULL,
    Fecha VARCHAR(20) COMMENT 'Fecha en formato flexible',
    Fecha_Original VARCHAR(50) COMMENT 'Fecha original tal como se ingresó',
    Caja VARCHAR(50),
    Sello VARCHAR(50),
    Sello_De_Repuesto VARCHAR(50),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_id (id),
    INDEX idx_bitacora (Bitacora),
    INDEX idx_fecha (Fecha),
    INDEX idx_caja (Caja),
    INDEX idx_sello (Sello),
    INDEX idx_fecha_creacion (fecha_creacion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- PROCEDIMIENTO PARA INSERTAR CON FECHA FLEXIBLE
-- =====================================================
DELIMITER //
CREATE PROCEDURE InsertarBitacoraFechaFlexible(
    IN p_id VARCHAR(50),
    IN p_bitacora VARCHAR(50),
    IN p_fecha VARCHAR(20),
    IN p_fecha_original VARCHAR(50),
    IN p_caja VARCHAR(50),
    IN p_sello VARCHAR(50),
    IN p_sello_repuesto VARCHAR(50),
    IN p_lineas_serializadas TEXT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- Insertar en tabla principal con fecha flexible
    INSERT INTO bitacora (id, Bitacora, Fecha, Fecha_Original, Caja, Sello, Sello_De_Repuesto)
    VALUES (p_id, p_bitacora, p_fecha, p_fecha_original, p_caja, p_sello, p_sello_repuesto);
    
    -- Insertar líneas si existen
    IF p_lineas_serializadas IS NOT NULL AND p_lineas_serializadas != '' THEN
        SET @lineas = p_lineas_serializadas;
        SET @pos = 1;
        
        WHILE @pos > 0 DO
            SET @linea = SUBSTRING_INDEX(@lineas, '|', 1);
            SET @lineas = SUBSTRING(@lineas, LENGTH(@linea) + 2);
            
            IF @linea != '' THEN
                SET @tipo = SUBSTRING_INDEX(@linea, ':', 1);
                SET @resto = SUBSTRING(@linea, LENGTH(@tipo) + 2);
                SET @folio = SUBSTRING_INDEX(@resto, ':', 1);
                SET @destino = SUBSTRING(@resto, LENGTH(@folio) + 2);
                
                INSERT INTO lineas_bitacora (id_Bitacora, Tipo, Folio, Destino)
                VALUES (p_id, TRIM(@tipo), TRIM(@folio), TRIM(@destino));
            END IF;
            
            SET @pos = LOCATE('|', @lineas);
        END WHILE;
    END IF;
    
    COMMIT;
END //
DELIMITER ;

-- =====================================================
-- FUNCIÓN PARA CONVERTIR FECHA FLEXIBLE
-- =====================================================
DELIMITER //
CREATE FUNCTION ConvertirFechaFlexible(fecha_texto VARCHAR(50)) 
RETURNS VARCHAR(20)
READS SQL DATA
DETERMINISTIC
BEGIN
    DECLARE fecha_convertida VARCHAR(20);
    DECLARE dia VARCHAR(2);
    DECLARE mes VARCHAR(2);
    DECLARE año VARCHAR(4);
    DECLARE mes_texto VARCHAR(20);
    
    -- Mapeo de meses
    SET @meses = JSON_OBJECT(
        'Enero', '01', 'Febrero', '02', 'Marzo', '03', 'Abril', '04',
        'Mayo', '05', 'Junio', '06', 'Julio', '07', 'Agosto', '08',
        'Septiembre', '09', 'Octubre', '10', 'Noviembre', '11', 'Diciembre', '12',
        'Ene', '01', 'Feb', '02', 'Mar', '03', 'Abr', '04',
        'May', '05', 'Jun', '06', 'Jul', '07', 'Ago', '08',
        'Sep', '09', 'Oct', '10', 'Nov', '11', 'Dic', '12'
    );
    
    -- Intentar formato dd/mes/yyyy
    IF fecha_texto REGEXP '^[0-9]{1,2}/[A-Za-z]+/[0-9]{4}$' THEN
        SET dia = SUBSTRING_INDEX(fecha_texto, '/', 1);
        SET mes_texto = SUBSTRING_INDEX(SUBSTRING_INDEX(fecha_texto, '/', 2), '/', -1);
        SET año = SUBSTRING_INDEX(fecha_texto, '/', -1);
        
        SET mes = JSON_UNQUOTE(JSON_EXTRACT(@meses, CONCAT('$.', mes_texto)));
        
        IF mes IS NOT NULL THEN
            SET fecha_convertida = CONCAT(año, '-', mes, '-', LPAD(dia, 2, '0'));
            RETURN fecha_convertida;
        END IF;
    END IF;
    
    -- Si no se pudo convertir, devolver la fecha original
    RETURN fecha_texto;
END //
DELIMITER ;

-- =====================================================
-- VERIFICACIÓN DE CAMBIOS
-- =====================================================
SELECT 'Tabla bitacora modificada correctamente' as mensaje;
DESCRIBE bitacora;

SELECT 'Procedimiento InsertarBitacoraFechaFlexible creado' as mensaje;
SHOW PROCEDURE STATUS WHERE Db = 'ssimce_db' AND Name = 'InsertarBitacoraFechaFlexible';

SELECT 'Función ConvertirFechaFlexible creada' as mensaje;
SHOW FUNCTION STATUS WHERE Db = 'ssimce_db' AND Name = 'ConvertirFechaFlexible';

-- =====================================================
-- PRUEBAS DE CONVERSIÓN
-- =====================================================
SELECT 
    '28/Julio/2025' as fecha_original,
    ConvertirFechaFlexible('28/Julio/2025') as fecha_convertida;

SELECT 
    '15/Agosto/2024' as fecha_original,
    ConvertirFechaFlexible('15/Agosto/2024') as fecha_convertida;

SELECT 
    '03/Enero/2025' as fecha_original,
    ConvertirFechaFlexible('03/Enero/2025') as fecha_convertida; 