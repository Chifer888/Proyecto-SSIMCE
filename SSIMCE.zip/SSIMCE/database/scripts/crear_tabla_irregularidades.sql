-- Crear tabla irregularidades
CREATE TABLE IF NOT EXISTS irregularidades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    folio VARCHAR(20) NOT NULL UNIQUE,
    sku VARCHAR(50) NOT NULL,
    descripcion TEXT NOT NULL,
    cantidad VARCHAR(20) NOT NULL,
    observaciones TEXT,
    imagen_webp LONGBLOB,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario VARCHAR(50) DEFAULT 'admin',
    sincronizado BOOLEAN DEFAULT FALSE,
    INDEX idx_folio (folio),
    INDEX idx_sku (sku),
    INDEX idx_fecha (fecha_registro)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insertar datos de ejemplo (opcional)
INSERT INTO irregularidades (folio, sku, descripcion, cantidad, observaciones, usuario) VALUES
('IRR-000001', 'SKU001', 'Producto con daño en empaque', '5', 'Producto llegó con empaque roto', 'admin'),
('IRR-000002', 'SKU002', 'Producto faltante en entrega', '2', 'Faltan 2 unidades del pedido', 'admin'),
('IRR-000003', 'SKU003', 'Producto con fecha vencida', '10', 'Producto próximo a vencer', 'admin');

-- Crear vista para irregularidades más recientes
CREATE OR REPLACE VIEW v_irregularidades_recientes AS
SELECT 
    folio,
    sku,
    descripcion,
    cantidad,
    observaciones,
    fecha_registro,
    usuario
FROM irregularidades 
ORDER BY fecha_registro DESC 
LIMIT 100;

-- Crear procedimiento almacenado para insertar irregularidad
DELIMITER //
CREATE PROCEDURE sp_insertar_irregularidad(
    IN p_folio VARCHAR(20),
    IN p_sku VARCHAR(50),
    IN p_descripcion TEXT,
    IN p_cantidad VARCHAR(20),
    IN p_observaciones TEXT,
    IN p_usuario VARCHAR(50)
)
BEGIN
    INSERT INTO irregularidades (folio, sku, descripcion, cantidad, observaciones, usuario)
    VALUES (p_folio, p_sku, p_descripcion, p_cantidad, p_observaciones, p_usuario);
    
    SELECT 'Irregularidad registrada exitosamente' AS mensaje;
END //
DELIMITER ;

-- Crear trigger para actualizar sincronizado cuando se inserta
DELIMITER //
CREATE TRIGGER tr_irregularidades_after_insert
AFTER INSERT ON irregularidades
FOR EACH ROW
BEGIN
    -- Aquí se pueden agregar acciones adicionales si es necesario
    -- Por ejemplo, enviar notificaciones, actualizar contadores, etc.
END //
DELIMITER ; 