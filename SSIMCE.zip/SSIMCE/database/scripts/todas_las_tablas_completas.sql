-- =====================================================
-- SCRIPT COMPLETO DE TODAS LAS TABLAS PARA SSIMCE
-- Base de datos: ssimce_db
-- Fecha: 2024
-- =====================================================

USE ssimce_db;

-- =====================================================
-- 1. TABLA: catalogo_productos (Productos del catálogo)
-- =====================================================
CREATE TABLE IF NOT EXISTS catalogo_productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(50) NOT NULL UNIQUE,
    descripcion VARCHAR(255) NOT NULL,
    imagen_url VARCHAR(500),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_sku (sku),
    INDEX idx_descripcion (descripcion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 2. TABLA: usuarios (Administración de usuarios)
-- =====================================================
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE,
    telefono VARCHAR(20),
    numero_empleado VARCHAR(20) UNIQUE NOT NULL,
    permisos ENUM('ADMIN', 'SUPERVISOR', 'OPERADOR') DEFAULT 'OPERADOR',
    estado ENUM('ACTIVO', 'INACTIVO') DEFAULT 'ACTIVO',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_numero_empleado (numero_empleado),
    INDEX idx_permisos (permisos),
    INDEX idx_estado (estado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 3. TABLA: entradas (Registro de entradas de productos)
-- =====================================================
CREATE TABLE IF NOT EXISTS entradas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(50) NOT NULL,
    descripcion VARCHAR(255) NOT NULL,
    cantidad DECIMAL(10,2) NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario VARCHAR(100),
    folio_entrada VARCHAR(50),
    tipo_entrada ENUM('ENTREGA_CLIENTE', 'SURTIDO_TIENDA', 'ROPA', 'LOTEO_JABAS', 'GUIA', 'BITACORA') NOT NULL,
    observaciones TEXT,
    INDEX idx_sku (sku),
    INDEX idx_fecha (fecha),
    INDEX idx_tipo_entrada (tipo_entrada),
    INDEX idx_folio_entrada (folio_entrada),
    INDEX idx_usuario (usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 4. TABLA: salidas (Registro de salidas de productos)
-- =====================================================
CREATE TABLE IF NOT EXISTS salidas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(50) NOT NULL,
    descripcion VARCHAR(255) NOT NULL,
    cantidad DECIMAL(10,2) NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario VARCHAR(100),
    folio_salida VARCHAR(50),
    tipo_salida ENUM('SALIDA_NORMAL', 'IRREGULARIDAD') NOT NULL,
    observaciones TEXT,
    INDEX idx_sku (sku),
    INDEX idx_fecha (fecha),
    INDEX idx_tipo_salida (tipo_salida),
    INDEX idx_folio_salida (folio_salida),
    INDEX idx_usuario (usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 5. TABLA: datos_ocr (Datos extraídos por OCR)
-- =====================================================
CREATE TABLE IF NOT EXISTS datos_ocr (
    id INT AUTO_INCREMENT PRIMARY KEY,
    texto_extraido TEXT NOT NULL,
    tipo_documento VARCHAR(50) DEFAULT 'OCR',
    usuario VARCHAR(100),
    fecha_procesamiento TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_tipo_documento (tipo_documento),
    INDEX idx_fecha (fecha_procesamiento),
    INDEX idx_usuario (usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 6. TABLA: bitacora (Registro de bitácoras)
-- =====================================================
CREATE TABLE IF NOT EXISTS bitacora (
    id INT AUTO_INCREMENT PRIMARY KEY,
    folio VARCHAR(50) UNIQUE NOT NULL,
    fecha VARCHAR(20) NOT NULL,
    tipo_documento VARCHAR(100),
    observaciones TEXT,
    usuario VARCHAR(100),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_folio (folio),
    INDEX idx_fecha (fecha),
    INDEX idx_usuario (usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 7. TABLA: lineas_bitacora (Líneas de bitácora)
-- =====================================================
CREATE TABLE IF NOT EXISTS lineas_bitacora (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bitacora_id INT NOT NULL,
    sku VARCHAR(50),
    descripcion VARCHAR(255),
    cantidad DECIMAL(10,2),
    tipo VARCHAR(50),
    observaciones TEXT,
    FOREIGN KEY (bitacora_id) REFERENCES bitacora(id) ON DELETE CASCADE,
    INDEX idx_bitacora_id (bitacora_id),
    INDEX idx_sku (sku)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 8. TABLA: guia (Registro de guías)
-- =====================================================
CREATE TABLE IF NOT EXISTS guia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    folio VARCHAR(50) UNIQUE NOT NULL,
    fecha VARCHAR(20) NOT NULL,
    tipo_documento VARCHAR(100),
    observaciones TEXT,
    usuario VARCHAR(100),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_folio (folio),
    INDEX idx_fecha (fecha),
    INDEX idx_usuario (usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 9. TABLA: lineas_guia (Líneas de guía)
-- =====================================================
CREATE TABLE IF NOT EXISTS lineas_guia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    guia_id INT NOT NULL,
    sku VARCHAR(50),
    descripcion VARCHAR(255),
    cantidad DECIMAL(10,2),
    tipo VARCHAR(50),
    observaciones TEXT,
    FOREIGN KEY (guia_id) REFERENCES guia(id) ON DELETE CASCADE,
    INDEX idx_guia_id (guia_id),
    INDEX idx_sku (sku)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 10. TABLA: envios_mrb (Envíos MRB)
-- =====================================================
CREATE TABLE IF NOT EXISTS envios_mrb (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha VARCHAR(20) NOT NULL,
    sku VARCHAR(50) NOT NULL,
    descripcion VARCHAR(255) NOT NULL,
    cantidad DECIMAL(10,2) NOT NULL,
    factura_remision VARCHAR(50),
    causa ENUM('C-16 Acta', 'C-16 VP', 'C-15', 'C-15 VS', 'RR', 'RE', 'DV'),
    observaciones TEXT,
    usuario VARCHAR(100),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_fecha (fecha),
    INDEX idx_sku (sku),
    INDEX idx_causa (causa),
    INDEX idx_usuario (usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 11. TABLA: envios_ct (Envíos CT)
-- =====================================================
CREATE TABLE IF NOT EXISTS envios_ct (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha VARCHAR(20) NOT NULL,
    sku VARCHAR(50) NOT NULL,
    descripcion VARCHAR(255) NOT NULL,
    cantidad DECIMAL(10,2) NOT NULL,
    ct VARCHAR(50),
    tienda VARCHAR(10),
    folio_ts VARCHAR(20),
    motivo ENUM('Incompleto', 'Dañado en exhibición', 'Sobrestock', 'No funciono al desempacar', 'Convenio', 'Enviar a Bodega', 'Orden de cambio'),
    observaciones TEXT,
    usuario VARCHAR(100),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_fecha (fecha),
    INDEX idx_sku (sku),
    INDEX idx_motivo (motivo),
    INDEX idx_usuario (usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- VISTAS PARA CONSULTAS
-- =====================================================

-- Vista para calcular stock disponible
CREATE OR REPLACE VIEW v_stock_disponible AS
SELECT 
    p.sku,
    p.descripcion,
    p.imagen_url,
    COALESCE(SUM(e.cantidad), 0) as total_entradas,
    COALESCE(SUM(s.cantidad), 0) as total_salidas,
    (COALESCE(SUM(e.cantidad), 0) - COALESCE(SUM(s.cantidad), 0)) as stock_disponible
FROM catalogo_productos p
LEFT JOIN entradas e ON p.sku = e.sku
LEFT JOIN salidas s ON p.sku = s.sku
GROUP BY p.sku, p.descripcion, p.imagen_url;

-- Vista alternativa para stock (sin depender de catalogo_productos)
CREATE OR REPLACE VIEW v_stock_disponible_alt AS
SELECT 
    sku,
    MAX(descripcion) as descripcion,
    COALESCE(SUM(CASE WHEN tipo = 'entrada' THEN cantidad ELSE 0 END), 0) as total_entradas,
    COALESCE(SUM(CASE WHEN tipo = 'salida' THEN cantidad ELSE 0 END), 0) as total_salidas,
    (COALESCE(SUM(CASE WHEN tipo = 'entrada' THEN cantidad ELSE 0 END), 0) - 
     COALESCE(SUM(CASE WHEN tipo = 'salida' THEN cantidad ELSE 0 END), 0)) as stock_disponible
FROM (
    SELECT sku, descripcion, cantidad, 'entrada' as tipo FROM entradas
    UNION ALL
    SELECT sku, descripcion, cantidad, 'salida' as tipo FROM salidas
) combined_data
GROUP BY sku;

-- =====================================================
-- PROCEDIMIENTOS ALMACENADOS
-- =====================================================

-- Procedimiento para insertar entrada
DELIMITER //
CREATE PROCEDURE sp_insertar_entrada(
    IN p_sku VARCHAR(50),
    IN p_descripcion VARCHAR(255),
    IN p_cantidad DECIMAL(10,2),
    IN p_usuario VARCHAR(100),
    IN p_folio_entrada VARCHAR(50),
    IN p_tipo_entrada ENUM('ENTREGA_CLIENTE', 'SURTIDO_TIENDA', 'ROPA', 'LOTEO_JABAS', 'GUIA', 'BITACORA'),
    IN p_observaciones TEXT
)
BEGIN
    INSERT INTO entradas (sku, descripcion, cantidad, usuario, folio_entrada, tipo_entrada, observaciones)
    VALUES (p_sku, p_descripcion, p_cantidad, p_usuario, p_folio_entrada, p_tipo_entrada, p_observaciones);
END //
DELIMITER ;

-- Procedimiento para insertar salida
DELIMITER //
CREATE PROCEDURE sp_insertar_salida(
    IN p_sku VARCHAR(50),
    IN p_descripcion VARCHAR(255),
    IN p_cantidad DECIMAL(10,2),
    IN p_usuario VARCHAR(100),
    IN p_folio_salida VARCHAR(50),
    IN p_tipo_salida ENUM('SALIDA_NORMAL', 'IRREGULARIDAD'),
    IN p_observaciones TEXT
)
BEGIN
    INSERT INTO salidas (sku, descripcion, cantidad, usuario, folio_salida, tipo_salida, observaciones)
    VALUES (p_sku, p_descripcion, p_cantidad, p_usuario, p_folio_salida, p_tipo_salida, p_observaciones);
END //
DELIMITER ;

-- Procedimiento para obtener stock de un SKU
DELIMITER //
CREATE PROCEDURE sp_obtener_stock_sku(
    IN p_sku VARCHAR(50)
)
BEGIN
    SELECT 
        p.sku,
        p.descripcion,
        p.imagen_url,
        COALESCE(SUM(e.cantidad), 0) as total_entradas,
        COALESCE(SUM(s.cantidad), 0) as total_salidas,
        (COALESCE(SUM(e.cantidad), 0) - COALESCE(SUM(s.cantidad), 0)) as stock_disponible
    FROM catalogo_productos p
    LEFT JOIN entradas e ON p.sku = e.sku
    LEFT JOIN salidas s ON p.sku = s.sku
    WHERE p.sku = p_sku
    GROUP BY p.sku, p.descripcion, p.imagen_url;
END //
DELIMITER ;

-- =====================================================
-- TRIGGERS
-- =====================================================

-- Trigger para actualizar fecha de modificación en entradas
DELIMITER //
CREATE TRIGGER tr_entradas_before_insert
BEFORE INSERT ON entradas
FOR EACH ROW
BEGIN
    SET NEW.fecha = CURRENT_TIMESTAMP;
END //
DELIMITER ;

-- Trigger para actualizar fecha de modificación en salidas
DELIMITER //
CREATE TRIGGER tr_salidas_before_insert
BEFORE INSERT ON salidas
FOR EACH ROW
BEGIN
    SET NEW.fecha = CURRENT_TIMESTAMP;
END //
DELIMITER ;

-- =====================================================
-- DATOS DE PRUEBA
-- =====================================================

-- Insertar productos de prueba
INSERT INTO catalogo_productos (sku, descripcion, imagen_url) VALUES
('SKU001', 'Producto de prueba 1 - Electrónicos', 'http://192.168.1.65/ssimce/imagenes/producto1.jpg'),
('SKU002', 'Producto de prueba 2 - Ropa', 'http://192.168.1.65/ssimce/imagenes/producto2.jpg'),
('SKU003', 'Producto de prueba 3 - Hogar', 'http://192.168.1.65/ssimce/imagenes/producto3.jpg'),
('SKU004', 'Producto de prueba 4 - Deportes', 'http://192.168.1.65/ssimce/imagenes/producto4.jpg'),
('SKU005', 'Producto de prueba 5 - Electrónicos', 'http://192.168.1.65/ssimce/imagenes/producto5.jpg');

-- Insertar usuarios de prueba
INSERT INTO usuarios (nombre, apellido, email, telefono, numero_empleado, permisos) VALUES
('Admin', 'Sistema', 'admin@ssimce.com', '1234567890', '123456', 'ADMIN'),
('Juan', 'Pérez', 'juan@ssimce.com', '0987654321', '654321', 'SUPERVISOR'),
('María', 'García', 'maria@ssimce.com', '1122334455', '789012', 'OPERADOR');

-- Insertar entradas de prueba
INSERT INTO entradas (sku, descripcion, cantidad, usuario, folio_entrada, tipo_entrada, observaciones) VALUES
('SKU001', 'Producto de prueba 1 - Electrónicos', 10.0, 'admin', 'ENT-001', 'ENTREGA_CLIENTE', 'Entrada inicial'),
('SKU001', 'Producto de prueba 1 - Electrónicos', 5.0, 'admin', 'ENT-002', 'SURTIDO_TIENDA', 'Reposición'),
('SKU002', 'Producto de prueba 2 - Ropa', 20.0, 'admin', 'ENT-003', 'ROPA', 'Entrada de ropa'),
('SKU003', 'Producto de prueba 3 - Hogar', 15.0, 'admin', 'ENT-004', 'LOTEO_JABAS', 'Entrada de loteo'),
('SKU004', 'Producto de prueba 4 - Deportes', 8.0, 'admin', 'ENT-005', 'GUIA', 'Entrada por guía'),
('SKU005', 'Producto de prueba 5 - Electrónicos', 12.0, 'admin', 'ENT-006', 'BITACORA', 'Entrada por bitácora');

-- Insertar salidas de prueba
INSERT INTO salidas (sku, descripcion, cantidad, usuario, folio_salida, tipo_salida, observaciones) VALUES
('SKU001', 'Producto de prueba 1 - Electrónicos', 3.0, 'admin', 'SAL-001', 'SALIDA_NORMAL', 'Venta'),
('SKU001', 'Producto de prueba 1 - Electrónicos', 2.0, 'admin', 'SAL-002', 'SALIDA_NORMAL', 'Transferencia'),
('SKU002', 'Producto de prueba 2 - Ropa', 5.0, 'admin', 'SAL-003', 'SALIDA_NORMAL', 'Venta'),
('SKU003', 'Producto de prueba 3 - Hogar', 1.0, 'admin', 'SAL-004', 'IRREGULARIDAD', 'Producto dañado'),
('SKU004', 'Producto de prueba 4 - Deportes', 2.0, 'admin', 'SAL-005', 'SALIDA_NORMAL', 'Venta');

-- Insertar datos OCR de prueba
INSERT INTO datos_ocr (texto_extraido, tipo_documento, usuario) VALUES
('Documento de prueba OCR 1', 'OCR', 'admin'),
('Documento de prueba OCR 2', 'OCR', 'admin');

-- Insertar bitácora de prueba
INSERT INTO bitacora (folio, fecha, tipo_documento, observaciones, usuario) VALUES
('BIT-001', '15/enero/2024', 'Bitácora de prueba', 'Observaciones de prueba', 'admin');

-- Insertar líneas de bitácora de prueba
INSERT INTO lineas_bitacora (bitacora_id, sku, descripcion, cantidad, tipo, observaciones) VALUES
(1, 'SKU001', 'Producto de prueba 1 - Electrónicos', 5.0, 'ENTRADA', 'Línea de prueba');

-- Insertar guía de prueba
INSERT INTO guia (folio, fecha, tipo_documento, observaciones, usuario) VALUES
('GUI-001', '15/enero/2024', 'Guía de prueba', 'Observaciones de prueba', 'admin');

-- Insertar líneas de guía de prueba
INSERT INTO lineas_guia (guia_id, sku, descripcion, cantidad, tipo, observaciones) VALUES
(1, 'SKU002', 'Producto de prueba 2 - Ropa', 10.0, 'ENTRADA', 'Línea de prueba');

-- Insertar envíos MRB de prueba
INSERT INTO envios_mrb (fecha, sku, descripcion, cantidad, factura_remision, causa, observaciones, usuario) VALUES
('15/enero/2024', 'SKU001', 'Producto de prueba 1 - Electrónicos', 2.0, 'FAC-001', 'C-16 Acta', 'Envío MRB de prueba', 'admin');

-- Insertar envíos CT de prueba
INSERT INTO envios_ct (fecha, sku, descripcion, cantidad, ct, tienda, folio_ts, motivo, observaciones, usuario) VALUES
('15/enero/2024', 'SKU002', 'Producto de prueba 2 - Ropa', 3.0, 'CT-001', '001', 'TS-001', 'Sobrestock', 'Envío CT de prueba', 'admin');

-- =====================================================
-- CONSULTAS DE VERIFICACIÓN
-- =====================================================

-- Verificar tablas creadas
SELECT TABLE_NAME, TABLE_ROWS, ENGINE, TABLE_COLLATION 
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = 'ssimce_db' 
ORDER BY TABLE_NAME;

-- Verificar stock disponible
SELECT * FROM v_stock_disponible WHERE sku IN ('SKU001', 'SKU002', 'SKU003');

-- Verificar irregularidades
SELECT * FROM salidas WHERE tipo_salida = 'IRREGULARIDAD';

-- Verificar datos OCR
SELECT * FROM datos_ocr ORDER BY fecha_procesamiento DESC LIMIT 5; 