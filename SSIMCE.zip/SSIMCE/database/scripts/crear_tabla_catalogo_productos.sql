-- =====================================================
-- SCRIPT PARA CREAR TABLA CATÁLOGO DE PRODUCTOS
-- Base de datos: ssimce_db
-- Fecha: 2024-01-15
-- =====================================================

USE ssimce_db;

-- =====================================================
-- TABLA: catalogo_productos
-- =====================================================
-- Crear tabla catalogo_productos si no existe
CREATE TABLE IF NOT EXISTS `catalogo_productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sku` varchar(50) NOT NULL,
  `descripcion` text NOT NULL,
  `imagen` longtext,
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_modificacion` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku` (`sku`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insertar algunos productos de ejemplo
INSERT IGNORE INTO `catalogo_productos` (`sku`, `descripcion`) VALUES
('123456', 'Producto de ejemplo 1'),
('789012', 'Producto de ejemplo 2'),
('345678', 'Producto de ejemplo 3');

-- =====================================================
-- PROCEDIMIENTO PARA BUSCAR PRODUCTO POR SKU
-- =====================================================
DELIMITER //
CREATE PROCEDURE BuscarProductoPorSKU(IN p_sku VARCHAR(50))
BEGIN
    SELECT 
        id,
        sku,
        descripcion,
        imagen_url,
        precio,
        stock,
        categoria,
        fecha_creacion,
        fecha_actualizacion
    FROM catalogo_productos 
    WHERE sku = p_sku;
END //
DELIMITER ;

-- =====================================================
-- PROCEDIMIENTO PARA OBTENER TODOS LOS PRODUCTOS
-- =====================================================
DELIMITER //
CREATE PROCEDURE ObtenerTodosProductos()
BEGIN
    SELECT 
        id,
        sku,
        descripcion,
        imagen_url,
        precio,
        stock,
        categoria,
        fecha_creacion,
        fecha_actualizacion
    FROM catalogo_productos 
    ORDER BY fecha_creacion DESC;
END //
DELIMITER ;

-- =====================================================
-- PROCEDIMIENTO PARA INSERTAR PRODUCTO
-- =====================================================
DELIMITER //
CREATE PROCEDURE InsertarProducto(
    IN p_sku VARCHAR(50),
    IN p_descripcion TEXT,
    IN p_imagen_url VARCHAR(255),
    IN p_precio DECIMAL(10,2),
    IN p_stock INT,
    IN p_categoria VARCHAR(100)
)
BEGIN
    INSERT INTO catalogo_productos (sku, descripcion, imagen_url, precio, stock, categoria)
    VALUES (p_sku, p_descripcion, p_imagen_url, p_precio, p_stock, p_categoria);
    
    SELECT LAST_INSERT_ID() as id;
END //
DELIMITER ;

-- =====================================================
-- PROCEDIMIENTO PARA ACTUALIZAR PRODUCTO
-- =====================================================
DELIMITER //
CREATE PROCEDURE ActualizarProducto(
    IN p_id INT,
    IN p_sku VARCHAR(50),
    IN p_descripcion TEXT,
    IN p_imagen_url VARCHAR(255),
    IN p_precio DECIMAL(10,2),
    IN p_stock INT,
    IN p_categoria VARCHAR(100)
)
BEGIN
    UPDATE catalogo_productos 
    SET sku = p_sku,
        descripcion = p_descripcion,
        imagen_url = p_imagen_url,
        precio = p_precio,
        stock = p_stock,
        categoria = p_categoria,
        fecha_actualizacion = CURRENT_TIMESTAMP
    WHERE id = p_id;
END //
DELIMITER ;

-- =====================================================
-- PROCEDIMIENTO PARA ELIMINAR PRODUCTO
-- =====================================================
DELIMITER //
CREATE PROCEDURE EliminarProducto(IN p_id INT)
BEGIN
    DELETE FROM catalogo_productos WHERE id = p_id;
END //
DELIMITER ;

-- =====================================================
-- VISTA PARA PRODUCTOS CON INFORMACIÓN COMPLETA
-- =====================================================
CREATE OR REPLACE VIEW vista_productos_completa AS
SELECT 
    id,
    sku,
    descripcion,
    imagen_url,
    precio,
    stock,
    categoria,
    fecha_creacion,
    fecha_actualizacion,
    CASE 
        WHEN stock > 0 THEN 'Disponible'
        WHEN stock = 0 THEN 'Agotado'
        ELSE 'Sin stock'
    END as estado_stock
FROM catalogo_productos
ORDER BY fecha_creacion DESC;

-- =====================================================
-- VERIFICACIÓN DE TABLA CREADA
-- =====================================================
SELECT 'Tabla catalogo_productos creada correctamente' as mensaje;
SHOW TABLES LIKE 'catalogo_productos';

SELECT 'Datos de prueba insertados' as mensaje;
SELECT COUNT(*) as total_productos FROM catalogo_productos;

SELECT 'Procedimientos almacenados creados' as mensaje;
SHOW PROCEDURE STATUS WHERE Db = 'ssimce_db' AND Name LIKE '%Producto%';

-- =====================================================
-- PRUEBA DE BÚSQUEDA
-- =====================================================
SELECT 'Prueba de búsqueda por SKU001:' as mensaje;
CALL BuscarProductoPorSKU('SKU001');

SELECT 'Vista de productos completa:' as mensaje;
SELECT * FROM vista_productos_completa LIMIT 3; 