# 🗄️ README - Instalación de Base de Datos

## 🎯 Descripción General
Guía completa para la instalación y configuración de la base de datos MySQL para la aplicación SSIMCE, incluyendo todas las tablas necesarias y configuraciones de seguridad.

## 📋 Requisitos Previos

### 🖥️ Servidor
- **XAMPP** - Servidor local (recomendado)
- **MySQL 8.0+** - Base de datos
- **PHP 8.0+** - Backend
- **Apache** - Servidor web

### 🔧 Configuración Mínima
- **RAM:** 4GB mínimo
- **Espacio:** 10GB libre
- **Sistema:** Windows 10/11, Linux, macOS

## 🚀 Instalación Paso a Paso

### 1️⃣ Instalación de XAMPP
```bash
# Descargar XAMPP desde https://www.apachefriends.org/
# Instalar en D:\Programas Instalados\XAMMP\
# Iniciar Apache y MySQL
```

### 2️⃣ Creación de Base de Datos
```sql
-- Conectar a MySQL
mysql -u root -p

-- Crear base de datos
CREATE DATABASE ssimce_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Usar la base de datos
USE ssimce_db;
```

### 3️⃣ Creación de Tablas

#### 📦 Tabla de Productos
```sql
CREATE TABLE productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(20) UNIQUE NOT NULL,
    descripcion TEXT NOT NULL,
    imagen LONGTEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_sku (sku),
    INDEX idx_fecha_creacion (fecha_creacion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

#### 📝 Tabla de Usuarios
```sql
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero_empleado VARCHAR(10) UNIQUE NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    puesto VARCHAR(50) NOT NULL,
    permisos ENUM('admin', 'operador', 'supervisor') DEFAULT 'operador',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_numero_empleado (numero_empleado),
    INDEX idx_permisos (permisos)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

#### 📊 Tabla de Registros MRB
```sql
CREATE TABLE mrb_registros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mrb VARCHAR(10) NOT NULL,
    jaula VARCHAR(3) NOT NULL,
    causa VARCHAR(20) NOT NULL,
    sku VARCHAR(20) NOT NULL,
    descripcion TEXT,
    factura VARCHAR(10) NOT NULL,
    cantidad VARCHAR(10) NOT NULL,
    observaciones TEXT,
    evidencia_uri TEXT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_mrb (mrb),
    INDEX idx_fecha (fecha),
    INDEX idx_sku (sku)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

#### 📋 Tabla de Registros CT
```sql
CREATE TABLE ct_registros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ct VARCHAR(10) NOT NULL,
    tienda VARCHAR(4) NOT NULL,
    folio_ts VARCHAR(6) NOT NULL,
    sku VARCHAR(20) NOT NULL,
    descripcion TEXT,
    motivo VARCHAR(50) NOT NULL,
    cantidad VARCHAR(10) NOT NULL,
    observaciones TEXT,
    evidencia_uri TEXT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ct (ct),
    INDEX idx_fecha (fecha),
    INDEX idx_sku (sku)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

#### ⚠️ Tabla de Irregularidades
```sql
CREATE TABLE irregularidades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(20) NOT NULL,
    descripcion TEXT NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_tipo (tipo),
    INDEX idx_fecha (fecha)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

### 4️⃣ Datos de Ejemplo

#### 📦 Productos de Ejemplo
```sql
INSERT INTO productos (sku, descripcion) VALUES
('123456', 'Producto de ejemplo 1'),
('234567', 'Producto de ejemplo 2'),
('345678', 'Producto de ejemplo 3'),
('456789', 'Producto de ejemplo 4'),
('567890', 'Producto de ejemplo 5');
```

#### 👥 Usuarios de Ejemplo
```sql
INSERT INTO usuarios (numero_empleado, nombre, apellido, puesto, permisos) VALUES
('123456', 'Admin', 'Sistema', 'Administrador', 'admin'),
('234567', 'Juan', 'Pérez', 'Operador', 'operador'),
('345678', 'María', 'García', 'Supervisor', 'supervisor');
```

### 5️⃣ Configuración de Seguridad

#### 🔐 Archivo config.ini
```ini
[database]
host = localhost
username = tu_usuario_mysql
password = tu_password_mysql
dbname = ssimce_db
api_key = MI_API_KEY_SECRETA
```

**Ubicación:** `D:\Programas Instalados\XAMMP\htdocs\private\config.ini`

#### 🛡️ Permisos de Usuario MySQL
```sql
-- Crear usuario específico
CREATE USER 'ssimce_user'@'localhost' IDENTIFIED BY 'tu_password_seguro';

-- Otorgar permisos
GRANT SELECT, INSERT, UPDATE, DELETE ON ssimce_db.* TO 'ssimce_user'@'localhost';

-- Aplicar cambios
FLUSH PRIVILEGES;
```

## 📁 Estructura de Directorios

### 🗂️ Servidor Web
```
D:\Programas Instalados\XAMMP\htdocs\
├── ssimce\
│   ├── datos_envios\
│   │   ├── datos_envios.php
│   │   ├── guardar_producto.php
│   │   ├── modificar_producto.php
│   │   ├── eliminar_producto.php
│   │   └── obtener_productos.php
│   ├── datos_guia\
│   │   └── datos_guia.php
│   ├── datos_bitacora\
│   │   └── datos_bitacora.php
│   └── imagenes\
│       └── imagenes_productos.php
└── private\
    └── config.ini
```

### 🔧 Archivos PHP Principales

#### 📡 datos_envios.php
```php
<?php
// Cargar configuración desde directorio privado
$config = parse_ini_file('D:\Programas Instalados\XAMMP\htdocs\private\config.ini');

// Validar API key
$headers = getallheaders();
$api_key = $headers['api_key'] ?? '';

if ($api_key !== $config['api_key']) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'API key inválida']);
    exit;
}

// Conexión a base de datos
$conn = new mysqli($config['host'], $config['username'], $config['password'], $config['dbname']);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Error de conexión']));
}

// Procesar datos según tipo
$tipo = $_POST['tipo'] ?? '';
$datos = json_decode($_POST['datos'], true);

if ($tipo === 'MRB') {
    $stmt = $conn->prepare("INSERT INTO mrb_registros (mrb, jaula, causa, sku, descripcion, factura, cantidad, observaciones, evidencia_uri) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssss", $datos['mrb'], $datos['jaula'], $datos['causa'], $datos['sku'], $datos['descripcion'], $datos['factura'], $datos['cantidad'], $datos['observaciones'], $datos['evidencia_uri']);
} elseif ($tipo === 'CT') {
    $stmt = $conn->prepare("INSERT INTO ct_registros (ct, tienda, folio_ts, sku, descripcion, motivo, cantidad, observaciones, evidencia_uri) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssss", $datos['ct'], $datos['tienda'], $datos['folio_ts'], $datos['sku'], $datos['descripcion'], $datos['motivo'], $datos['cantidad'], $datos['observaciones'], $datos['evidencia_uri']);
}

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Registro guardado exitosamente']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error al guardar registro']);
}

$stmt->close();
$conn->close();
?>
```

## 🔧 Configuración de Android

### 📱 URLs del Servidor
```kotlin
// En todas las actividades Android
private const val SERVER_URL = "http://192.168.1.65/ssimce/"
private const val API_KEY = "MI_API_KEY_SECRETA"
```

### 🔄 Sincronización
- **Productos** - Sincronización automática
- **Usuarios** - Gestión de permisos
- **Registros** - Envío en tiempo real
- **Evidencia** - Almacenamiento seguro

## 🛡️ Seguridad

### 🔐 Medidas Implementadas
- **API Key** - Autenticación de servidor
- **Prepared Statements** - Prevención SQL Injection
- **Configuración externa** - Archivo config.ini seguro
- **Validación de datos** - Verificación de entrada
- **Logs de auditoría** - Registro de operaciones

### 📋 Checklist de Seguridad
- ✅ API Key configurada
- ✅ Prepared Statements implementados
- ✅ Config.ini en directorio privado
- ✅ Permisos de usuario limitados
- ✅ Validación de datos activa
- ✅ Logs de auditoría habilitados

## 🔄 Mantenimiento

### 📊 Backup Automático
```sql
-- Script de backup diario
mysqldump -u ssimce_user -p ssimce_db > backup_$(date +%Y%m%d).sql
```

### 🧹 Limpieza de Datos
```sql
-- Limpiar registros antiguos (opcional)
DELETE FROM mrb_registros WHERE fecha < DATE_SUB(NOW(), INTERVAL 1 YEAR);
DELETE FROM ct_registros WHERE fecha < DATE_SUB(NOW(), INTERVAL 1 YEAR);
```

## 📈 Monitoreo

### 📊 Consultas Útiles
```sql
-- Estadísticas de uso
SELECT COUNT(*) as total_registros FROM mrb_registros;
SELECT COUNT(*) as total_productos FROM productos;
SELECT COUNT(*) as total_usuarios FROM usuarios;

-- Registros recientes
SELECT * FROM mrb_registros ORDER BY fecha DESC LIMIT 10;
SELECT * FROM ct_registros ORDER BY fecha DESC LIMIT 10;
```

## 🚨 Solución de Problemas

### ❌ Error de Conexión
1. Verificar que MySQL esté ejecutándose
2. Confirmar credenciales en config.ini
3. Verificar permisos de usuario
4. Comprobar firewall

### ❌ Error de API Key
1. Verificar API_KEY en Android
2. Confirmar api_key en config.ini
3. Revisar headers de petición
4. Verificar logs de servidor

### ❌ Error de Permisos
1. Verificar permisos de directorio
2. Confirmar permisos de usuario MySQL
3. Revisar configuración de Apache
4. Verificar logs de error 