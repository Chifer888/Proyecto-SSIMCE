<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, api_key');

// Habilitar reporte de errores para debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log de información de debugging
error_log("=== GUARDAR_SALIDA.PHP EJECUTADO ===");

// Manejar preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Leer configuración de base de datos
$config_path = 'D:/Programas Instalados/XAMMP/htdocs/private/config.ini';

if (!file_exists($config_path)) {
    error_log("ERROR: Archivo de configuración no encontrado en: $config_path");
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Archivo de configuración no encontrado'
    ]);
    exit();
}

try {
    $config = parse_ini_file($config_path);
} catch (Exception $e) {
    error_log("ERROR leyendo configuración: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error leyendo configuración: ' . $e->getMessage()
    ]);
    exit();
}

$host = $config['host'] ?? 'localhost';
$dbname = $config['dbname'] ?? 'ssimce_db';
$username = $config['username'] ?? 'root';
$password = $config['password'] ?? '';
$api_key_config = $config['api_key'] ?? 'MI_API_KEY_SECRETA';

// Verificar API key
$headers = getallheaders();
$api_key = isset($headers['api_key']) ? $headers['api_key'] : '';

if ($api_key !== $api_key_config) {
    error_log("ERROR: API key inválida - Recibida: $api_key, Esperada: $api_key_config");
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'API key inválida'
    ]);
    exit();
}

// Intentar conexión a base de datos
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    error_log("Conexión a BD exitosa");
} catch (PDOException $e) {
    error_log("ERROR de conexión a BD: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error de conexión a la base de datos: ' . $e->getMessage()
    ]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Obtener datos del POST
        $input = file_get_contents('php://input');
        $data = json_decode($input, true);
        
        error_log("Datos recibidos: " . ($data ? json_encode(array_keys($data)) : "NULL"));
        
        if (!$data) {
            throw new Exception('Datos JSON inválidos');
        }
        
        // Validar campos requeridos
        $campos_requeridos = ['sku', 'descripcion', 'cantidad', 'usuario', 'tipo_salida'];
        foreach ($campos_requeridos as $campo) {
            if (!isset($data[$campo]) || empty($data[$campo])) {
                throw new Exception("Campo requerido faltante: $campo");
            }
        }
        
        // Generar folio único
        $folio_salida = 'SAL_' . date('YmdHis') . '_' . rand(1000, 9999);
        
        // Obtener stock anterior
        $stmt_stock = $pdo->prepare("
            SELECT 
                COALESCE(SUM(CASE WHEN tipo = 'entrada' THEN cantidad ELSE 0 END), 0) as total_entradas,
                COALESCE(SUM(CASE WHEN tipo = 'salida' THEN cantidad ELSE 0 END), 0) as total_salidas
            FROM (
                SELECT sku, cantidad, 'entrada' as tipo FROM entradas WHERE sku = ?
                UNION ALL
                SELECT sku, cantidad, 'salida' as tipo FROM salidas WHERE sku = ?
            ) combined_data
        ");
        $stmt_stock->execute([$data['sku'], $data['sku']]);
        $stock_data = $stmt_stock->fetch(PDO::FETCH_ASSOC);
        
        $stock_anterior = $stock_data['total_entradas'] - $stock_data['total_salidas'];
        $stock_nuevo = $stock_anterior - $data['cantidad'];
        
        // Insertar en tabla salidas
        $stmt = $pdo->prepare("
            INSERT INTO salidas 
            (folio_salida, sku, descripcion, cantidad, usuario, tipo_salida, observaciones, fecha) 
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $folio_salida,
            $data['sku'],
            $data['descripcion'],
            $data['cantidad'],
            $data['usuario'],
            $data['tipo_salida'],
            $data['observaciones'] ?? null
        ]);
        
        $id_insertado = $pdo->lastInsertId();
        error_log("Registro de salida insertado con ID: $id_insertado, Folio: $folio_salida");
        
        echo json_encode([
            'success' => true,
            'message' => 'Salida guardada correctamente',
            'folio_salida' => $folio_salida,
            'id' => $id_insertado,
            'stock_anterior' => $stock_anterior,
            'stock_nuevo' => $stock_nuevo
        ]);
        
    } catch (PDOException $e) {
        error_log("ERROR al guardar salida: " . $e->getMessage());
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Error al guardar salida: ' . $e->getMessage()
        ]);
    } catch (Exception $e) {
        error_log("ERROR de validación: " . $e->getMessage());
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Método no permitido'
    ]);
}
?> 