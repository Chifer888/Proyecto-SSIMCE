<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, api_key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$config = parse_ini_file("D:/Programas Instalados/XAMMP/htdocs/private/config.ini", true);

// Datos de conexión
$db_host = $config['database']['host'];
$db_user = $config['database']['username'];
$db_pass = $config['database']['password'];
$db_name = $config['database']['dbname'];
$api_key_config = $config['database']['api_key'];

// Leer JSON entrante
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode([
        "success" => false,
        "message" => "No se recibieron datos JSON válidos"
    ]);
    exit;
}

// Verificar API key enviada desde la app Android
$headers = getallheaders();
if (!isset($headers['api_key']) || $headers['api_key'] !== $api_key_config) {
    echo json_encode([
        "success" => false,
        "message" => "API key inválida o no proporcionada"
    ]);
    exit;
}

// Crear conexión a la base de datos
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    echo json_encode([
        "success" => false,
        "message" => "Error de conexión: " . $conn->connect_error
    ]);
    exit;
}

// Extraer datos del JSON recibido de la app Android
$folio = $input['folio'] ?? '';
$fecha = $input['fecha'] ?? '';
$tipo_documento = $input['tipo_documento'] ?? 'Guía de Transporte';
$observaciones = $input['observaciones'] ?? '';
$usuario = $input['usuario'] ?? 'admin';

// Generar ID único si no existe
$id = $input['id'] ?? uniqid('GUI_', true);

// Extraer datos de las observaciones para mapear a la tabla guia
$bitacora = '';
$camion = '';
$empleado = '';
$chofer = '';
$origen = '';
$destino = '';
$caja1 = '';
$caja2 = '';
$sello = '';
$selloRepuesto = '';

// Parsear observaciones para extraer datos específicos
if (!empty($observaciones)) {
    // Buscar patrones en las observaciones
    if (preg_match('/Bitácora:\s*([^.]+)/', $observaciones, $matches)) {
        $bitacora = trim($matches[1]);
    }
    if (preg_match('/Camión:\s*([^.]+)/', $observaciones, $matches)) {
        $camion = trim($matches[1]);
    }
    if (preg_match('/Chofer:\s*([^.]+)/', $observaciones, $matches)) {
        $chofer = trim($matches[1]);
    }
    if (preg_match('/Origen:\s*([^.]+)/', $observaciones, $matches)) {
        $origen = trim($matches[1]);
    }
    if (preg_match('/Destino:\s*([^.]+)/', $observaciones, $matches)) {
        $destino = trim($matches[1]);
    }
    if (preg_match('/Caja1:\s*([^.]+)/', $observaciones, $matches)) {
        $caja1 = trim($matches[1]);
    }
    if (preg_match('/Caja2:\s*([^.]+)/', $observaciones, $matches)) {
        $caja2 = trim($matches[1]);
    }
    if (preg_match('/Sello:\s*([^.]+)/', $observaciones, $matches)) {
        $sello = trim($matches[1]);
    }
    if (preg_match('/Sello Repuesto:\s*([^.]+)/', $observaciones, $matches)) {
        $selloRepuesto = trim($matches[1]);
    }
}

// Preparar SQL de inserción en la tabla guia
$stmt = $conn->prepare("INSERT INTO guia (
    id, Bitacora, Fecha, Camion, Empleado, Chofer, Origen, Destino, Caja1, Caja2, Sello, SelloRepuesto
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

if (!$stmt) {
    echo json_encode([
        "success" => false,
        "message" => "Error preparando la consulta: " . $conn->error
    ]);
    exit;
}

// Ejecutar consulta
$stmt->bind_param("ssssssssssss", $id, $bitacora, $fecha, $camion, $empleado, $chofer, $origen, $destino, $caja1, $caja2, $sello, $selloRepuesto);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Datos insertados correctamente en la tabla guia",
        "folio" => $folio,
        "id_insertado" => $id
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Error al insertar datos: " . $stmt->error
    ]);
}

// Cerrar
$stmt->close();
$conn->close();
?>