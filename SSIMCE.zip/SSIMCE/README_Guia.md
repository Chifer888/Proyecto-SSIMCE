# 📋 README - Módulo de Guía

## 🎯 Descripción General
Este módulo permite el escaneo y registro de guías de transporte, incluyendo captura de evidencia fotográfica y navegación mejorada.

## 🔍 Funcionalidades Principales

### ✅ Escaneo de Guías
- **Lectura de códigos de barras** - Escáner integrado
- **Validación de datos** - Verificación automática
- **Almacenamiento local** - Base de datos Room
- **Sincronización** - Envío al servidor

### 📸 Captura de Evidencia
- **Fotografía** - Captura de imágenes
- **Video** - Grabación de videos
- **Almacenamiento** - Guardado en dispositivo
- **Compresión** - Optimización de archivos

### 🎨 Interfaz de Usuario
- **Diseño intuitivo** - Navegación clara
- **Botones de acción** - Funciones principales
- **Indicadores visuales** - Estado de operaciones
- **Mensajes informativos** - Feedback al usuario

## 🆕 Nuevas Funcionalidades

### 🔗 Navegación Directa
- **Botón "Ir a Entradas"** - Navegación directa desde escaneo
- **Posicionamiento central** - Fácil acceso
- **Diseño consistente** - Estilo de la aplicación
- **Funcionalidad inmediata** - Sin confirmaciones adicionales

### 📱 Características del Botón
- **Ubicación:** Centro de la pantalla
- **Tamaño:** 200dp x 60dp
- **Color:** Azul corporativo (#0965AE)
- **Texto:** "Ir a Entradas"
- **Icono:** Integrado en el texto

## 📁 Archivos Principales

### 🎭 Activities
- `MainActivityEscaneoGuia.kt` - Escaneo principal con navegación
- `MainActivityFormularioGuia.kt` - Formulario de datos
- `MainActivityMostrarDatosGuia.kt` - Visualización de registros
- `CameraActivityGuia.kt` - Captura de evidencia

### 🎨 Layouts
- `activity_main_escaneo_guia.xml` - Interfaz de escaneo con botón
- `activity_main_formulario_guia.xml` - Formulario de datos
- `activity_main_mostrar_datos_guia.xml` - Lista de registros
- `activity_camera_guia.xml` - Captura de evidencia

### 🗄️ Base de Datos
- **Room Database** - Almacenamiento local
- **Entidades** - GuiaRegistro, Producto
- **DAOs** - Operaciones de base de datos
- **Sincronización** - Envío al servidor

## 🚀 Características Destacadas

### ✅ Funcionalidades Implementadas
- ✅ Escaneo de códigos de barras
- ✅ Captura de fotografía y video
- ✅ Almacenamiento local con Room
- ✅ Sincronización con servidor
- ✅ Navegación directa a Entradas
- ✅ Validación de datos
- ✅ Compresión de evidencia
- ✅ Interfaz responsiva

### 🔄 Flujo de Usuario
1. **Escaneo de guía** → Lectura de código
2. **Captura de evidencia** → Foto o video
3. **Guardado local** → Base de datos Room
4. **Sincronización** → Envío al servidor
5. **Navegación** → Botón directo a Entradas

## 🛠️ Tecnologías Utilizadas
- **Kotlin** - Lenguaje principal
- **Room Database** - Almacenamiento local
- **Camera API** - Captura de evidencia
- **Volley** - Comunicación con servidor
- **ZXing** - Escaneo de códigos
- **FileProvider** - Manejo de archivos

## 📱 Compatibilidad
- **Android 6.0+** (API 23+)
- **Permisos dinámicos** para cámara y almacenamiento
- **Autofocus** para mejor escaneo
- **Compresión WebP** para optimización

## 🔧 Configuración

### 📋 Permisos Requeridos
```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.INTERNET" />
```

### 🎯 Características del Botón de Navegación
```xml
<Button
    android:id="@+id/btnIrAEntradas"
    android:layout_width="200dp"
    android:layout_height="60dp"
    android:text="Ir a Entradas"
    android:backgroundTint="#0965AE"
    android:textColor="#FFFFFF"
    android:textSize="18dp"
    android:textStyle="bold" />
```

## 📊 Estadísticas de Uso
- **Escaneo rápido** - < 2 segundos por código
- **Compresión eficiente** - 85% de calidad WebP
- **Navegación fluida** - Transición inmediata
- **Almacenamiento optimizado** - Máximo 1024px

## 🔄 Actualizaciones Recientes
- ✅ **Botón de navegación** - Acceso directo a Entradas
- ✅ **Posicionamiento mejorado** - Centro de pantalla
- ✅ **Diseño consistente** - Estilo corporativo
- ✅ **Funcionalidad inmediata** - Sin confirmaciones 