# 📱 README - Módulo de Inicio

## 🎯 Descripción General
Este módulo maneja la autenticación de usuarios y la navegación principal de la aplicación SSIMCE.

## 🔐 Funcionalidades de Login

### ✅ Autenticación Biométrica
- **Huella dactilar** - Verificación de identidad
- **Credenciales** - Usuario y contraseña encriptados con SHA-256
- **Validación en tiempo real** - Verificación automática de campos

### 🔑 Credenciales de Acceso
- **Usuario:** `123456` (hash: `8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92`)
- **Contraseña:** `123456` (hash: `2270e73a86e507f7a99d98e739a62f96ec812c1a19b37a0db27785e620518566`)

### 📞 Recuperación de Contraseña
- **RadioButton "Olvide mi contraseña"**
- **SMS automático** al administrador
- **Desactivación inteligente** - Se desactiva cuando las credenciales son correctas
- **Mensaje personalizado** - "Falla de acceso, usuario XXXXXXXX"
- **Envío directo** - Usa SmsManager nativo

### 🛡️ Seguridad
- **Encriptación SHA-256** para credenciales
- **Permisos dinámicos** para SMS
- **Validación de permisos** en tiempo de ejecución

## 🏠 Menú Principal

### 👤 Saludo Personalizado
- **"¡Hola [Nombre]!"** - Basado en número de empleado
- **Mapeo de usuarios:**
  - `123456` → "Admin"
  - `234567` → "Juan Pérez"
  - `345678` → "María García"
  - `456789` → "Carlos López"
  - `567890` → "Ana Martínez"
  - `678901` → "Luis Rodríguez"
  - `789012` → "Sofia Torres"
  - `890123` → "Diego Morales"
  - `901234` → "Carmen Silva"
  - `012345` → "Roberto Vargas"

### 🔧 Menú de Opciones
- **Botón con icono de llave** - Posicionado sobre imagen existente
- **Popup menu** con opciones administrativas:
  - 📦 **Catálogo de Productos** - Gestión de inventario
  - 👥 **Usuarios** - Administración de usuarios

### 🎨 Diseño
- **Fondo azul** con imagen de tractocamión
- **Botones estilizados** con colores corporativos
- **Navegación intuitiva** entre módulos

## 📁 Archivos Principales

### 🎭 Activities
- `MainActivityLogin.kt` - Autenticación y recuperación de contraseña
- `MainActivityMenuPrincipal.kt` - Navegación principal y saludo personalizado

### 🎨 Layouts
- `activity_main_login.xml` - Interfaz de login con RadioButton
- `activity_main_menu_principal.xml` - Menú principal con saludo

### 🔧 Configuración
- **SharedPreferences** - Almacenamiento de número de empleado
- **Permisos** - CAMERA, SEND_SMS, READ_PHONE_STATE
- **BiometricPrompt** - Autenticación biométrica

## 🚀 Características Destacadas

### ✅ Funcionalidades Implementadas
- ✅ Login con credenciales encriptadas
- ✅ Autenticación biométrica opcional
- ✅ Recuperación de contraseña por SMS
- ✅ Saludo personalizado por usuario
- ✅ Menú de opciones administrativas
- ✅ Navegación a módulos de administración
- ✅ Desactivación inteligente del RadioButton
- ✅ Manejo de permisos dinámicos

### 🔄 Flujo de Usuario
1. **Ingreso de credenciales** → Validación en tiempo real
2. **Autenticación biométrica** → Verificación de identidad
3. **Acceso al menú** → Saludo personalizado
4. **Navegación** → Módulos disponibles
5. **Recuperación** → SMS automático si es necesario

## 🛠️ Tecnologías Utilizadas
- **Kotlin** - Lenguaje principal
- **SHA-256** - Encriptación de credenciales
- **BiometricPrompt** - Autenticación biométrica
- **SmsManager** - Envío de SMS
- **SharedPreferences** - Almacenamiento local
- **Volley** - Comunicación con servidor

## 📱 Compatibilidad
- **Android 6.0+** (API 23+)
- **Permisos dinámicos** para Android 6.0+
- **Autenticación biométrica** para dispositivos compatibles
- **SMS nativo** para todos los dispositivos 