<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, api_key');

// Habilitar reporte de errores para debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log de información de debugging
error_log("=== GUARDAR_ENTRADA_SURTIDO.PHP EJECUTADO ===");

// Manejar preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Leer configuración de base de datos
$config_path = 'D:/Programas Instalados/XAMMP/htdocs/private/config.ini';

if (!file_exists($config_path)) {
    error_log("ERROR: Archivo de configuración no encontrado en: $config_path");
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Archivo de configuración no encontrado'
    ]);
    exit();
}

try {
    $config = parse_ini_file($config_path);
} catch (Exception $e) {
    error_log("ERROR leyendo configuración: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error leyendo configuración: ' . $e->getMessage()
    ]);
    exit();
}

$host = $config['host'] ?? 'localhost';
$dbname = $config['dbname'] ?? 'ssimce_db';
$username = $config['username'] ?? 'root';
$password = $config['password'] ?? '';
$api_key_config = $config['api_key'] ?? 'MI_API_KEY_SECRETA';

// Verificar API key
$headers = getallheaders();
$api_key = isset($headers['api_key']) ? $headers['api_key'] : '';

if ($api_key !== $api_key_config) {
    error_log("ERROR: API key inválida - Recibida: $api_key, Esperada: $api_key_config");
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'API key inválida'
    ]);
    exit();
}

// Intentar conexión a base de datos
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    error_log("Conexión a BD exitosa");
} catch (PDOException $e) {
    error_log("ERROR de conexión a BD: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error de conexión a la base de datos: ' . $e->getMessage()
    ]);
    exit();
}

// Verificar que la tabla entradas existe
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'entradas'");
    if ($stmt->rowCount() == 0) {
        error_log("ERROR: Tabla entradas no existe");
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Tabla entradas no existe. Ejecute el script de creación de tablas.'
        ]);
        exit();
    }
    error_log("Tabla entradas verificada correctamente");
} catch (PDOException $e) {
    error_log("ERROR verificando tabla entradas: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error verificando tabla entradas: ' . $e->getMessage()
    ]);
    exit();
}

// Obtener datos del POST
$input = json_decode(file_get_contents('php://input'), true);
error_log("Datos recibidos: " . print_r($input, true));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sku = isset($input['sku']) ? trim($input['sku']) : '';
    $descripcion = isset($input['descripcion']) ? trim($input['descripcion']) : '';
    $cantidad = isset($input['cantidad']) ? intval($input['cantidad']) : 0;
    $tipo_entrada = isset($input['tipo_entrada']) ? trim($input['tipo_entrada']) : 'Surtido Tiendas';
    $observaciones = isset($input['observaciones']) ? trim($input['observaciones']) : '';
    $usuario = isset($input['usuario']) ? trim($input['usuario']) : 'admin';

    error_log("Datos procesados - SKU: $sku, Descripción: $descripcion, Cantidad: $cantidad");

    // Validar datos requeridos
    if (empty($sku) || empty($descripcion) || $cantidad <= 0) {
        error_log("ERROR: Datos requeridos faltantes");
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'SKU, descripción y cantidad son requeridos',
            'debug_info' => [
                'sku' => $sku,
                'descripcion' => $descripcion,
                'cantidad' => $cantidad
            ]
        ]);
        exit();
    }

    try {
        $pdo->beginTransaction();

        // Insertar en la tabla entradas
        $stmt = $pdo->prepare("
            INSERT INTO entradas (sku, descripcion, cantidad, tipo_entrada, observaciones, usuario, fecha_registro)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([$sku, $descripcion, $cantidad, $tipo_entrada, $observaciones, $usuario]);
        $entrada_id = $pdo->lastInsertId();

        $pdo->commit();

        error_log("Entrada insertada exitosamente con ID: $entrada_id");

        echo json_encode([
            'success' => true,
            'message' => 'Entrada registrada exitosamente',
            'entrada_id' => $entrada_id,
            'sku' => $sku,
            'cantidad' => $cantidad,
            'tipo_entrada' => $tipo_entrada
        ]);

    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("ERROR al insertar entrada: " . $e->getMessage());
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Error al guardar la entrada: ' . $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Método no permitido'
    ]);
}
?> 