# 📁 Archivos PHP Utilizados en SSIMCE

## ✅ Archivos PHP Activos (Utilizados por la App)

### 📚 **Catálogo de Productos**
- `php_files/buscar_producto.php` - Buscar producto por SKU
- `php_files/obtener_productos.php` - Obtener lista de productos
- `php_files/guardar_producto.php` - Crear nuevo producto
- `php_files/modificar_producto.php` - Actualizar producto
- `php_files/eliminar_producto.php` - Eliminar producto

### 👥 **Gestión de Usuarios**
- `php_files/usuarios/obtener_usuarios.php` - Obtener lista de usuarios
- `php_files/usuarios/guardar_usuario.php` - Crear nuevo usuario
- `php_files/usuarios/modificar_usuario.php` - Actualizar usuario
- `php_files/usuarios/eliminar_usuario.php` - Eliminar usuario

### 📦 **Entradas**
- `guardar_entrada_ropa.php` - Entradas de ropa
- `guardar_entrada_loteo.php` - Entradas de loteo
- `guardar_entrada_surtido.php` - Entradas de surtido
- `guardar_entrada_entregas.php` - Entradas de entregas

### 📤 **Salidas**
- `guardar_salida.php` - Guardar salidas de inventario
- `calcular_stock.php` - Calcular stock disponible

### 📋 **Envíos**
- `datos_envios.php` - Datos generales de envíos
- `guardar_envio_mrb.php` - Guardar envíos MRB
- `guardar_envio_ct.php` - Guardar envíos CT

### ⚠️ **Irregularidades**
- `sincronizar_irregularidades.php` - Sincronizar irregularidades

### 📄 **Guía de Transporte**
- `insertar_datos_guia.php` - Insertar datos de guía

## 🗑️ Archivos PHP Eliminados (No Utilizados)

### ❌ **Archivos de Prueba Eliminados**
- `test_upload.php`
- `test_catalogo_productos.php`
- `test_guardar_salida.php`
- `test_mrb_simple.php`
- `test_entregas.php`
- `test_error.php`
- `test_guia.php`
- `test_formato_fecha.php`

### ❌ **Archivos de Verificación Eliminados**
- `verificar_skus_con_datos.php`
- `verificar_tabla_catalogo.php`
- `verificar_tabla_salidas.php`
- `verificar_vista_stock.php`
- `verificar_estructura_irregularidades.php`
- `verificar_estructura_tablas.php`
- `verificar_y_crear_vista_stock.php`
- `verificar_tablas_envios.php`
- `verificar_tabla.php`

### ❌ **Archivos de Imagen Eliminados**
- `upload_imagen_simple.php`
- `upload_imagen_mejorado.php`
- `upload_imagen.php`
- `test_upload_imagen.php`
- `actualizar_urls_imagenes.php`
- `verificar_imagenes_productos.php`
- `imagenes_productos.php`

### ❌ **Archivos Duplicados/Obsoletos Eliminados**
- `guardar_entrada_entregas_corregido.php`
- `insertar_datos_guia_actualizado.php`
- `guardar_datos_ocr.php`
- `insertar_datos_bitacora.php`
- `guardar_irregularidad.php`

## 📊 Resumen de Limpieza

### ✅ **Archivos Mantenidos**: 18 archivos PHP activos
### ❌ **Archivos Eliminados**: 25 archivos PHP innecesarios
### 📈 **Reducción**: 58% menos archivos PHP

## 🔧 Estructura Final de Archivos PHP

```
📁 php_files/
├── 📁 usuarios/
│   ├── obtener_usuarios.php
│   ├── guardar_usuario.php
│   ├── modificar_usuario.php
│   └── eliminar_usuario.php
├── buscar_producto.php
├── obtener_productos.php
├── guardar_producto.php
├── modificar_producto.php
└── eliminar_producto.php

📁 raíz/
├── guardar_entrada_ropa.php
├── guardar_entrada_loteo.php
├── guardar_entrada_surtido.php
├── guardar_entrada_entregas.php
├── guardar_salida.php
├── calcular_stock.php
├── datos_envios.php
├── guardar_envio_mrb.php
├── guardar_envio_ct.php
├── sincronizar_irregularidades.php
└── insertar_datos_guia.php
```

## 🎯 Beneficios de la Limpieza

### ⚡ **Rendimiento**
- **Menos archivos** - Código más organizado
- **Mejor mantenimiento** - Solo archivos necesarios
- **Menor confusión** - Sin archivos duplicados

### 🔧 **Mantenimiento**
- **Código más limpio** - Sin archivos de prueba
- **Mejor organización** - Estructura clara
- **Fácil debugging** - Solo archivos activos

### 📱 **Funcionalidad**
- **Todos los módulos** funcionan correctamente
- **Sin dependencias** de archivos eliminados
- **Código optimizado** y funcional

---

**Estado**: ✅ Limpieza completada  
**Archivos activos**: 18  
**Archivos eliminados**: 25  
**Fecha**: Diciembre 2024 