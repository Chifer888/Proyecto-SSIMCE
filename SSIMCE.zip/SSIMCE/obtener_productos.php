<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, api_key');

// Habilitar reporte de errores para debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log de información de debugging
error_log("=== OBTENER_PRODUCTOS.PHP EJECUTADO ===");

// Manejar preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Leer configuración de base de datos
$config_path = 'D:/Programas Instalados/XAMMP/htdocs/private/config.ini';

if (!file_exists($config_path)) {
    error_log("ERROR: Archivo de configuración no encontrado en: $config_path");
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Archivo de configuración no encontrado'
    ]);
    exit();
}

try {
    $config = parse_ini_file($config_path);
} catch (Exception $e) {
    error_log("ERROR leyendo configuración: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error leyendo configuración: ' . $e->getMessage()
    ]);
    exit();
}

$host = $config['host'] ?? 'localhost';
$dbname = $config['dbname'] ?? 'ssimce_db';
$username = $config['username'] ?? 'root';
$password = $config['password'] ?? '';
$api_key_config = $config['api_key'] ?? 'MI_API_KEY_SECRETA';

// Verificar API key
$headers = getallheaders();
$api_key = isset($headers['api_key']) ? $headers['api_key'] : '';

if ($api_key !== $api_key_config) {
    error_log("ERROR: API key inválida - Recibida: $api_key, Esperada: $api_key_config");
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'API key inválida'
    ]);
    exit();
}

// Intentar conexión a base de datos
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    error_log("Conexión a BD exitosa");
} catch (PDOException $e) {
    error_log("ERROR de conexión a BD: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error de conexión a la base de datos: ' . $e->getMessage()
    ]);
    exit();
}

// Verificar que la tabla catalogo_productos existe
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'catalogo_productos'");
    if ($stmt->rowCount() == 0) {
        error_log("ERROR: Tabla catalogo_productos no existe");
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Tabla catalogo_productos no existe. Ejecute el script de creación de tablas.'
        ]);
        exit();
    }
    error_log("Tabla catalogo_productos verificada correctamente");
} catch (PDOException $e) {
    error_log("ERROR verificando tabla catalogo_productos: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error verificando tabla catalogo_productos: ' . $e->getMessage()
    ]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // Obtener todos los productos de la tabla catalogo_productos
        $stmt = $pdo->prepare("SELECT sku, descripcion FROM catalogo_productos ORDER BY sku");
        $stmt->execute();
        $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        error_log("Productos obtenidos: " . count($productos));
        
        echo json_encode([
            'success' => true,
            'productos' => $productos,
            'total' => count($productos)
        ]);
        
    } catch (PDOException $e) {
        error_log("ERROR al obtener productos: " . $e->getMessage());
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Error al obtener productos: ' . $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Método no permitido'
    ]);
}
?> 