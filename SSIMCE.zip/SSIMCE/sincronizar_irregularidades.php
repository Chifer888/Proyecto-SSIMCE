<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, api_key');

// Habilitar reporte de errores para debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log de información de debugging
error_log("=== SINCRONIZAR_IRREGULARIDADES.PHP EJECUTADO ===");

// Manejar preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Leer configuración de base de datos
$config_path = 'D:/Programas Instalados/XAMMP/htdocs/private/config.ini';

if (!file_exists($config_path)) {
    error_log("ERROR: Archivo de configuración no encontrado en: $config_path");
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Archivo de configuración no encontrado'
    ]);
    exit();
}

try {
    $config = parse_ini_file($config_path);
} catch (Exception $e) {
    error_log("ERROR leyendo configuración: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error leyendo configuración: ' . $e->getMessage()
    ]);
    exit();
}

$host = $config['host'] ?? 'localhost';
$dbname = $config['dbname'] ?? 'ssimce_db';
$username = $config['username'] ?? 'root';
$password = $config['password'] ?? '';
$api_key_config = $config['api_key'] ?? 'MI_API_KEY_SECRETA';

// Verificar API key
$headers = getallheaders();
$api_key = isset($headers['api_key']) ? $headers['api_key'] : '';

if ($api_key !== $api_key_config) {
    error_log("ERROR: API key inválida - Recibida: $api_key, Esperada: $api_key_config");
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'API key inválida'
    ]);
    exit();
}

// Intentar conexión a base de datos
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    error_log("Conexión a BD exitosa");
} catch (PDOException $e) {
    error_log("ERROR de conexión a BD: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error de conexión a la base de datos: ' . $e->getMessage()
    ]);
    exit();
}

// Verificar que la tabla irregularidades existe
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'irregularidades'");
    if ($stmt->rowCount() == 0) {
        error_log("ERROR: Tabla irregularidades no existe");
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Tabla irregularidades no existe. Ejecute el script de creación de tablas.'
        ]);
        exit();
    }
    error_log("Tabla irregularidades verificada correctamente");
} catch (PDOException $e) {
    error_log("ERROR verificando tabla irregularidades: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error verificando tabla irregularidades: ' . $e->getMessage()
    ]);
    exit();
}

// Obtener datos del POST
$input = json_decode(file_get_contents('php://input'), true);
error_log("Datos recibidos: " . print_r($input, true));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $folio = isset($input['folio']) ? trim($input['folio']) : '';
    $sku = isset($input['sku']) ? trim($input['sku']) : '';
    $descripcion = isset($input['descripcion']) ? trim($input['descripcion']) : '';
    $cantidad = isset($input['cantidad']) ? trim($input['cantidad']) : '';
    $observaciones = isset($input['observaciones']) ? trim($input['observaciones']) : '';
    $imagen_webp = isset($input['imagen_webp']) ? $input['imagen_webp'] : '';
    $usuario = isset($input['usuario']) ? trim($input['usuario']) : 'admin';

    error_log("Datos procesados - Folio: $folio, SKU: $sku, Descripción: $descripcion");

    // Validar datos requeridos
    if (empty($folio) || empty($sku) || empty($descripcion)) {
        error_log("ERROR: Datos requeridos faltantes");
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'Folio, SKU y descripción son requeridos',
            'debug_info' => [
                'folio' => $folio,
                'sku' => $sku,
                'descripcion' => $descripcion
            ]
        ]);
        exit();
    }

    try {
        $pdo->beginTransaction();

        // Verificar si la irregularidad ya existe
        $stmt_check = $pdo->prepare("SELECT id FROM irregularidades WHERE folio = ?");
        $stmt_check->execute([$folio]);
        
        if ($stmt_check->rowCount() > 0) {
            // Actualizar irregularidad existente
            $stmt = $pdo->prepare("
                UPDATE irregularidades 
                SET sku = ?, descripcion = ?, cantidad = ?, observaciones = ?, imagen_webp = ?, usuario = ?, fecha_registro = NOW()
                WHERE folio = ?
            ");
            
            $imagen_blob = !empty($imagen_webp) ? base64_decode($imagen_webp) : null;
            $stmt->execute([$sku, $descripcion, $cantidad, $observaciones, $imagen_blob, $usuario, $folio]);
            
            error_log("Irregularidad actualizada: $folio");
        } else {
            // Insertar nueva irregularidad
            $stmt = $pdo->prepare("
                INSERT INTO irregularidades (folio, sku, descripcion, cantidad, observaciones, imagen_webp, usuario, fecha_registro)
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $imagen_blob = !empty($imagen_webp) ? base64_decode($imagen_webp) : null;
            $stmt->execute([$folio, $sku, $descripcion, $cantidad, $observaciones, $imagen_blob, $usuario]);
            
            error_log("Irregularidad insertada: $folio");
        }

        $pdo->commit();

        echo json_encode([
            'success' => true,
            'message' => 'Irregularidad sincronizada exitosamente',
            'folio' => $folio,
            'sku' => $sku
        ]);

    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("ERROR al sincronizar irregularidad: " . $e->getMessage());
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Error al sincronizar la irregularidad: ' . $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Método no permitido'
    ]);
}
?> 