package com.example.ssimce.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface MRBRegistroDao {
    @Insert
    suspend fun insertarMRBRegistro(mrbRegistro: MRBRegistro)
    
    @Query("SELECT * FROM mrb_registros ORDER BY fecha DESC")
    suspend fun obtenerTodosLosRegistros(): List<MRBRegistro>
} 