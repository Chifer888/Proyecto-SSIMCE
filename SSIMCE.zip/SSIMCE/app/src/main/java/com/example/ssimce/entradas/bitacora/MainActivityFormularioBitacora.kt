package com.example.ssimce.entradas.bitacora

import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.TableLayout
import android.widget.TableRow
import androidx.appcompat.app.AppCompatActivity
import com.example.ssimce.databinding.ActivityMainFormularioBitacoraBinding

class MainActivityFormularioBitacora : AppCompatActivity() {

    private lateinit var binding: ActivityMainFormularioBitacoraBinding
    private lateinit var adapter: LineaBitacoraAdapter
    private val lineasBitacora = mutableListOf<LineaBitacora>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainFormularioBitacoraBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Llenar campos recibidos del escaneo
        binding.Bitacora.setText(intent.getStringExtra("bitacora") ?: "")
        binding.Fecha.setText(intent.getStringExtra("fecha") ?: "")
        binding.Caja.setText(intent.getStringExtra("caja") ?: "")
        binding.Sello.setText(intent.getStringExtra("sello") ?: "")
        binding.repuestoDeSello.setText(intent.getStringExtra("repuesto_sello") ?: "")

        // Procesar las líneas de tipo y folio escaneadas
        procesarLineasEscaneadas()

        // Inicializar el adaptador
        adapter = LineaBitacoraAdapter(this, lineasBitacora)

        // Crear las filas de la tabla
        crearFilasTabla()

        // Botón aceptar
        binding.btnaceptar.setOnClickListener {
            enviarDatos()
        }
    }

    private fun procesarLineasEscaneadas() {
        val lineasTipoFolio = intent.getStringExtra("lineas_tipo_folio") ?: ""
        
        android.util.Log.d("BitacoraForm", "Líneas recibidas: $lineasTipoFolio")
        
        if (lineasTipoFolio.isNotEmpty()) {
            val lineas = lineasTipoFolio.split(",")
            for (linea in lineas) {
                val partes = linea.split(":")
                if (partes.size == 2) {
                    val tipo = partes[0].trim()
                    val folio = partes[1].trim()
                    lineasBitacora.add(LineaBitacora(tipo, folio))
                    android.util.Log.d("BitacoraForm", "Agregada línea: Tipo=$tipo, Folio=$folio")
                }
            }
        }
        
        // Si no se encontraron líneas, crear una línea por defecto
        if (lineasBitacora.isEmpty()) {
            lineasBitacora.add(LineaBitacora("", ""))
            android.util.Log.d("BitacoraForm", "No se encontraron líneas, agregada línea por defecto")
        }
        
        android.util.Log.d("BitacoraForm", "Total de líneas procesadas: ${lineasBitacora.size}")
    }

    private fun crearFilasTabla() {
        val tablaDatos = binding.tablaDatos
        
        // Limpiar tabla existente
        tablaDatos.removeAllViews()
        
        // Crear filas para cada línea de bitácora
        for (i in lineasBitacora.indices) {
            val linea = lineasBitacora[i]
            val rowView = adapter.createTableRow(tablaDatos)
            
            // Agregar la fila a la tabla
            tablaDatos.addView(rowView)
            
            // Actualizar los datos de la fila
            adapter.updateRowData(rowView, linea, i)
        }
    }

    private fun enviarDatos() {
        val bitacora = binding.Bitacora.text.toString()
        val fecha = binding.Fecha.text.toString()
        val caja = binding.Caja.text.toString()
        val sello = binding.Sello.text.toString()
        val repuestoSello = binding.repuestoDeSello.text.toString()
        
        // Obtener las líneas con sus destinos seleccionados
        val lineasConDestino = adapter.getLineas()
        
        val intent = Intent(this, MainActivityMostrarDatosBitacora::class.java).apply {
            putExtra("bitacora", bitacora)
            putExtra("fecha", fecha)
            putExtra("caja", caja)
            putExtra("sello", sello)
            putExtra("repuesto_sello", repuestoSello)
            
            // Pasar las líneas como una lista serializada
            val lineasSerializadas = lineasConDestino.joinToString("|") { "${it.tipo}:${it.folio}:${it.destino}" }
            putExtra("lineas_serializadas", lineasSerializadas)
        }

        startActivity(intent)
    }
}