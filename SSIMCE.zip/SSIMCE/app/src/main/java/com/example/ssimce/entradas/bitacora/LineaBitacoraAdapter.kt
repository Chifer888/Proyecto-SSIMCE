package com.example.ssimce.entradas.bitacora

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.example.ssimce.R

class LineaBitacoraAdapter(
    private val context: Context,
    private val lineas: MutableList<LineaBitacora>
) {
    
    private val destinos = listOf(
        "Selec. destino", "T-438", "T-493", "T-898", "T-7693", "T-1142",
        "T-1131", "T-1011", "T-6553", "T-7812", "T-895", "T-698", "T-1350",
        "T-387", "T-922", "T-677", "T-7739", "T-7849",
        "J-91", "J-91B", "J-86", "J-108", "J-98", "J-98A", "J-95", "J-95B",
        "J-92", "J-92B", "J-96", "J-90", "J-90X", "J-97", "J-85A"
    )

    fun createTableRow(parent: ViewGroup): View {
        val inflater = LayoutInflater.from(context)
        val rowView = inflater.inflate(R.layout.table_row_linea_bitacora, parent, false)
        
        val textTipo = rowView.findViewById<TextView>(R.id.textTipo)
        val editFolio = rowView.findViewById<EditText>(R.id.editFolio)
        val spinnerDestino = rowView.findViewById<Spinner>(R.id.spinnerDestino)
        
        // Configurar spinner de destino
        val adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, destinos)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerDestino.adapter = adapter
        
        return rowView
    }
    
    fun updateRowData(rowView: View, linea: LineaBitacora, position: Int) {
        val textTipo = rowView.findViewById<TextView>(R.id.textTipo)
        val editFolio = rowView.findViewById<EditText>(R.id.editFolio)
        val spinnerDestino = rowView.findViewById<Spinner>(R.id.spinnerDestino)
        
        textTipo.text = linea.tipo
        editFolio.setText(linea.folio)
        
        // Configurar el destino seleccionado
        val selectedIndex = destinos.indexOf(linea.destino)
        if (selectedIndex >= 0) {
            spinnerDestino.setSelection(selectedIndex)
        }
        
        // Listener para actualizar el folio cuando cambie
        editFolio.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                linea.folio = s?.toString() ?: ""
                android.util.Log.d("BitacoraAdapter", "Folio actualizado para posición $position: ${linea.folio}")
            }
        })
        
        // Listener para actualizar el destino cuando cambie
        spinnerDestino.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position > 0) { // No es "Selec. destino"
                    linea.destino = destinos[position]
                    android.util.Log.d("BitacoraAdapter", "Destino actualizado para línea ${linea.tipo}: ${linea.destino}")
                }
            }
            
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        })
    }
    
    fun getLineas(): List<LineaBitacora> {
        return lineas.toList()
    }
} 