package com.example.ssimce.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "irregularidades")
data class Irregularidad(
    @PrimaryKey val folio: String,
    val sku: String,
    val descripcion: String,
    val cantidad: String,
    val observaciones: String,
    val imagenWebP: ByteArray,
    val fechaCreacion: Long = System.currentTimeMillis()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Irregularidad

        if (folio != other.folio) return false
        if (sku != other.sku) return false
        if (descripcion != other.descripcion) return false
        if (cantidad != other.cantidad) return false
        if (observaciones != other.observaciones) return false
        if (!imagenWebP.contentEquals(other.imagenWebP)) return false
        if (fechaCreacion != other.fechaCreacion) return false

        return true
    }

    override fun hashCode(): Int {
        var result = folio.hashCode()
        result = 31 * result + sku.hashCode()
        result = 31 * result + descripcion.hashCode()
        result = 31 * result + cantidad.hashCode()
        result = 31 * result + observaciones.hashCode()
        result = 31 * result + imagenWebP.contentHashCode()
        result = 31 * result + fechaCreacion.hashCode()
        return result
    }
} 