package com.example.ssimce.admin

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.ssimce.R
import org.json.JSONObject

class CatalogoProductosActivity : AppCompatActivity() {
    
    private lateinit var edtSku: EditText
    private lateinit var edtDescripcion: EditText
    private lateinit var btnGuardar: Button
    private lateinit var btnModificar: Button
    private lateinit var btnEliminar: Button
    private lateinit var listViewProductos: ListView
    private lateinit var btnRegresar: Button
    
    private var productosList = mutableListOf<JSONObject>()
    
    companion object {
        private const val SERVER_URL = "http://192.168.1.65/ssimce/"
        private const val API_KEY = "MI_API_KEY_SECRETA"
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_catalogo_productos)
        
        // Inicializar vistas
        edtSku = findViewById(R.id.edtSku)
        edtDescripcion = findViewById(R.id.edtDescripcion)
        btnGuardar = findViewById(R.id.btnGuardar)
        btnModificar = findViewById(R.id.btnModificar)
        btnEliminar = findViewById(R.id.btnEliminar)
        listViewProductos = findViewById(R.id.listViewProductos)
        btnRegresar = findViewById(R.id.btnRegresar)
        
        btnGuardar.setOnClickListener {
            guardarProducto()
        }
        
        btnModificar.setOnClickListener {
            modificarProducto()
        }
        
        btnEliminar.setOnClickListener {
            eliminarProducto()
        }
        
        btnRegresar.setOnClickListener {
            finish()
        }
        
        // Configurar búsqueda automática al presionar Enter en SKU
        edtSku.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                buscarProductoPorSku()
                return@setOnEditorActionListener true
            }
            false
        }
        
        // Configurar selección de productos de la lista
        listViewProductos.setOnItemClickListener { _, _, position, _ ->
            if (position < productosList.size) {
                seleccionarProductoDeLista(productosList[position])
            }
        }
        
        // Cargar lista de productos
        cargarProductos()
    }
    
    private fun buscarProductoPorSku() {
        val sku = edtSku.text.toString().trim()
        if (sku.isEmpty()) {
            Toast.makeText(this, "Por favor ingrese un SKU", Toast.LENGTH_SHORT).show()
            return
        }
        
        val request = object : JsonObjectRequest(
            Request.Method.GET,
            "${SERVER_URL}buscar_producto.php?sku=$sku",
            null,
            { response ->
                if (response.optBoolean("success", false)) {
                    val producto = response.optJSONObject("producto")
                    if (producto != null) {
                        edtDescripcion.setText(producto.optString("descripcion", ""))
                        Toast.makeText(this, "Producto encontrado", Toast.LENGTH_SHORT).show()
                    } else {
                        edtDescripcion.setText("")
                        Toast.makeText(this, "Producto no encontrado", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    edtDescripcion.setText("")
                    Toast.makeText(this, "Producto no encontrado", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                edtDescripcion.setText("")
                Toast.makeText(this, "Error de conexión: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = API_KEY
                return headers
            }
        }
        
        Volley.newRequestQueue(this).add(request)
    }
    
    private fun seleccionarProductoDeLista(producto: JSONObject) {
        val sku = producto.optString("sku", "")
        val descripcion = producto.optString("descripcion", "")
        
        edtSku.setText(sku)
        edtDescripcion.setText(descripcion)
        
        Toast.makeText(this, "Producto seleccionado: $sku", Toast.LENGTH_SHORT).show()
    }
    
    private fun guardarProducto() {
        val sku = edtSku.text.toString().trim()
        val descripcion = edtDescripcion.text.toString().trim()
        
        if (sku.isEmpty() || descripcion.isEmpty()) {
            Toast.makeText(this, "Por favor complete todos los campos", Toast.LENGTH_SHORT).show()
            return
        }
        
        val jsonObject = JSONObject().apply {
            put("sku", sku)
            put("descripcion", descripcion)
        }
        
        val request = object : JsonObjectRequest(
            Request.Method.POST,
            "${SERVER_URL}guardar_producto.php",
            jsonObject,
            { response ->
                if (response.optBoolean("success", false)) {
                    Toast.makeText(this, "Producto guardado exitosamente", Toast.LENGTH_SHORT).show()
                    limpiarFormulario()
                    cargarProductos()
                } else {
                    Toast.makeText(this, "Error: ${response.optString("message", "Error desconocido")}", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Toast.makeText(this, "Error de conexión: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = API_KEY
                return headers
            }
        }
        
        Volley.newRequestQueue(this).add(request)
    }
    
    private fun modificarProducto() {
        val sku = edtSku.text.toString().trim()
        val descripcion = edtDescripcion.text.toString().trim()
        
        if (sku.isEmpty() || descripcion.isEmpty()) {
            Toast.makeText(this, "Por favor complete todos los campos", Toast.LENGTH_SHORT).show()
            return
        }
        
        val jsonObject = JSONObject().apply {
            put("sku", sku)
            put("descripcion", descripcion)
        }
        
        val request = object : JsonObjectRequest(
            Request.Method.POST,
            "${SERVER_URL}modificar_producto.php",
            jsonObject,
            { response ->
                if (response.optBoolean("success", false)) {
                    Toast.makeText(this, "Producto modificado exitosamente", Toast.LENGTH_SHORT).show()
                    limpiarFormulario()
                    cargarProductos()
                } else {
                    Toast.makeText(this, "Error: ${response.optString("message", "Error desconocido")}", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Toast.makeText(this, "Error de conexión: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = API_KEY
                return headers
            }
        }
        
        Volley.newRequestQueue(this).add(request)
    }
    
    private fun eliminarProducto() {
        val sku = edtSku.text.toString().trim()
        if (sku.isEmpty()) {
            Toast.makeText(this, "Por favor ingrese el SKU del producto a eliminar", Toast.LENGTH_SHORT).show()
            return
        }
        
        AlertDialog.Builder(this)
            .setTitle("Confirmar eliminación")
            .setMessage("¿Está seguro de que desea eliminar el producto con SKU: $sku?")
            .setPositiveButton("Eliminar") { _, _ ->
                ejecutarEliminacion(sku)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
    
    private fun ejecutarEliminacion(sku: String) {
        val jsonObject = JSONObject().apply {
            put("sku", sku)
        }
        
        val request = object : JsonObjectRequest(
            Request.Method.POST,
            "${SERVER_URL}eliminar_producto.php",
            jsonObject,
            { response ->
                if (response.optBoolean("success", false)) {
                    Toast.makeText(this, "Producto eliminado exitosamente", Toast.LENGTH_SHORT).show()
                    limpiarFormulario()
                    cargarProductos()
                } else {
                    Toast.makeText(this, "Error: ${response.optString("message", "Error desconocido")}", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Toast.makeText(this, "Error de conexión: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = API_KEY
                return headers
            }
        }
        
        Volley.newRequestQueue(this).add(request)
    }
    
    private fun cargarProductos() {
        val request = object : JsonObjectRequest(
            Request.Method.GET,
            "${SERVER_URL}obtener_productos.php",
            null,
            { response ->
                if (response.optBoolean("success", false)) {
                    val productosArray = response.optJSONArray("productos")
                    productosList.clear()
                    
                    if (productosArray != null) {
                        for (i in 0 until productosArray.length()) {
                            val producto = productosArray.getJSONObject(i)
                            productosList.add(producto)
                        }
                    }
                    
                    actualizarListaProductos()
                } else {
                    Toast.makeText(this, "Error al cargar productos: ${response.optString("message", "")}", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Toast.makeText(this, "Error de conexión: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = API_KEY
                return headers
            }
        }
        
        Volley.newRequestQueue(this).add(request)
    }
    
    private fun actualizarListaProductos() {
        val productosArray = productosList.map { producto ->
            val sku = producto.optString("sku", "")
            val descripcion = producto.optString("descripcion", "")
            "$sku - $descripcion"
        }.toTypedArray()
        
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, productosArray) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                val textView = view.findViewById<TextView>(android.R.id.text1)
                textView.setTextColor(ContextCompat.getColor(context, android.R.color.holo_blue_dark))
                return view
            }
        }
        
        listViewProductos.adapter = adapter
    }
    
    private fun limpiarFormulario() {
        edtSku.text.clear()
        edtDescripcion.text.clear()
    }
} 