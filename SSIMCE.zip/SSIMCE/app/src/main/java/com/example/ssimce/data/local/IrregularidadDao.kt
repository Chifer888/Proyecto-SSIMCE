package com.example.ssimce.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface IrregularidadDao {
    @Insert
    suspend fun insertarIrregularidad(irregularidad: Irregularidad)

    @Query("SELECT * FROM irregularidades ORDER BY fechaCreacion DESC")
    suspend fun obtenerTodasLasIrregularidades(): List<Irregularidad>

    @Query("SELECT * FROM irregularidades WHERE folio = :folio")
    suspend fun obtenerIrregularidadPorFolio(folio: String): Irregularidad?

    @Query("SELECT COUNT(*) FROM irregularidades")
    suspend fun obtenerTotalIrregularidades(): Int
} 