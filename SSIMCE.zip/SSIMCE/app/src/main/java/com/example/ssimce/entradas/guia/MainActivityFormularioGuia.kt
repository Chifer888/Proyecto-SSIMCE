package com.example.ssimce.entradas.guia

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.ssimce.databinding.ActivityMainFormularioGuiaBinding

class MainActivityFormularioGuia : AppCompatActivity() {

    private lateinit var binding: ActivityMainFormularioGuiaBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainFormularioGuiaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Recibir datos del Intent y mostrarlos en los EditTexts
        binding.Bitacora.setText(intent.getStringExtra("Bitácora") ?: "")
        binding.fecha.setText(intent.getStringExtra("Fecha") ?: "")
        binding.origen.setText(intent.getStringExtra("Origen") ?: "")
        binding.destino.setText(intent.getStringExtra("Destino") ?: "")
        binding.empleado.setText(intent.getStringExtra("Empleado") ?: "")
        binding.chofer.setText(intent.getStringExtra("Chófer") ?: "")
        binding.camion.setText(intent.getStringExtra("Camión") ?: "")
        binding.caja1.setText(intent.getStringExtra("Caja1") ?: "")
        binding.caja2.setText(intent.getStringExtra("Caja2") ?: "")
        binding.sello.setText(intent.getStringExtra("Sello") ?: "")
        binding.selloRepuesto.setText(intent.getStringExtra("SelloRepuesto") ?: "")

        binding.btnaceptar.setOnClickListener {
            val bitacora = binding.Bitacora.text.toString()
            val fecha = binding.fecha.text.toString()
            val origen = binding.origen.text.toString()
            val destino = binding.destino.text.toString()
            val empleado = binding.empleado.text.toString()
            val chofer = binding.chofer.text.toString()
            val camion = binding.camion.text.toString()
            val caja1 = binding.caja1.text.toString()
            val caja2 = binding.caja2.text.toString()
            val sello = binding.sello.text.toString()
            val selloRepuesto = binding.selloRepuesto.text.toString()

            val intent = Intent(this, MainActivityMostrarDatosGuia::class.java).apply {
                putExtra("bitacora", bitacora)
                putExtra("fecha", fecha)
                putExtra("origen", origen)
                putExtra("destino", destino)
                putExtra("empleado", empleado)
                putExtra("chofer", chofer)
                putExtra("camion", camion)
                putExtra("caja1", caja1)
                putExtra("caja2", caja2)
                putExtra("sello", sello)
                putExtra("selloRepuesto", selloRepuesto)
            }

            startActivity(intent)
        }
    }
}