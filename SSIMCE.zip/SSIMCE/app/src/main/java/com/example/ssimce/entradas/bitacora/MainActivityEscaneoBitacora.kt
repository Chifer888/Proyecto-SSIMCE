package com.example.ssimce.entradas.bitacora

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import com.example.ssimce.inicio.MainActivityMenuPrincipal
import com.example.ssimce.R

class MainActivityEscaneoBitacora : AppCompatActivity() {

    private lateinit var btnEscaner: Button
    private lateinit var btnHome: Button
    private lateinit var imageViewFoto: ImageView

    private var imageUri: Uri? = null

    // Lanzador para escaneo desde cámara
    private val scannerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            val imageUriStr = data?.getStringExtra("image_uri")

            if (!imageUriStr.isNullOrEmpty()) {
                imageUri = imageUriStr.toUri()
                imageViewFoto.setImageURI(imageUri)
                Toast.makeText(this, "Imagen escaneada correctamente", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "No se recibió la imagen", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_escaneo_bitacora)

        // Inicializa los elementos
        btnEscaner = findViewById(R.id.btnEscaner)
        btnHome = findViewById(R.id.btnHome)
        imageViewFoto = findViewById(R.id.imageViewFoto)

        // Escaneo con cámara (abre CameraActivity)
        btnEscaner.setOnClickListener {
            val intent = Intent(this, CameraActivityBitacora::class.java)
            scannerLauncher.launch(intent)
        }

        // Regresar a menú principal
        btnHome.setOnClickListener {
            val intent = Intent(this, MainActivityMenuPrincipal::class.java)
            startActivity(intent)
            finishAffinity()
        }
    }
}
