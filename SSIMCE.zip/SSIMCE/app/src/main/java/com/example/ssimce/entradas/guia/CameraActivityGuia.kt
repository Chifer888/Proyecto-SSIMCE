package com.example.ssimce.entradas.guia

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.example.ssimce.R
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.IOException
import kotlin.collections.iterator

class CameraActivityGuia : AppCompatActivity() {

    @RequiresApi(Build.VERSION_CODES.Q)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camera_guia)

        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(false)
            .setPageLimit(10)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()

        val scanner = GmsDocumentScanning.getClient(options)

        scanner.getStartScanIntent(this)
            .addOnSuccessListener { intentSender ->
                val intentRequest = IntentSenderRequest.Builder(intentSender).build()
                scannerLauncher.launch(intentRequest)
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error al iniciar escáner", Toast.LENGTH_SHORT).show()
                finish()
            }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private val scannerLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val scanResult = GmsDocumentScanningResult.fromActivityResultIntent(result.data)
                val imageUri = scanResult?.pages?.firstOrNull()?.imageUri

                if (imageUri != null) {
                    // COMENTADO: Guardar imagen en dispositivo (por si ya no se usa)
                    // val savedImageUri = saveImageToGallery(imageUri)
                    // if (savedImageUri != null) {
                    //     extractTextFromImage(savedImageUri) { extractedText ->
                    //         val datosFiltrados = extraerDatosDesdeTexto(extractedText).toMutableMap()
                    //         val intent = Intent(this, MainActivityFormularioGuia::class.java)
                    //         for ((clave, valor) in datosFiltrados) {
                    //             intent.putExtra(clave, valor)
                    //         }
                    //         startActivity(intent)
                    //         finish()
                    //     }
                    // } else {
                    //     Toast.makeText(this, "Error al guardar imagen", Toast.LENGTH_SHORT).show()
                    //     finish()
                    // }
                    
                    // NUEVO: Procesar imagen directamente sin guardar en dispositivo
                    extractTextFromImage(imageUri) { extractedText ->
                            val datosFiltrados = extraerDatosDesdeTexto(extractedText).toMutableMap()

                            val intent = Intent(this, MainActivityFormularioGuia::class.java)
                            for ((clave, valor) in datosFiltrados) {
                                intent.putExtra(clave, valor)
                            }
                            startActivity(intent)
                        finish()
                    }
                } else {
                    Toast.makeText(this, "No se encontró imagen", Toast.LENGTH_SHORT).show()
                    finish()
                }
            } else {
                Toast.makeText(this, "Escaneo cancelado", Toast.LENGTH_SHORT).show()
                finish()
            }
        }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun saveImageToGallery(uri: Uri): Uri? {
        val resolver = contentResolver
        val imageCollection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)

        val imageName = "ssimce_${System.currentTimeMillis()}.jpg"
        val contentValues = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, imageName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/Camera")
        }

        return try {
            val imageOutUri = resolver.insert(imageCollection, contentValues)
            if (imageOutUri != null) {
                val inputStream = resolver.openInputStream(uri)
                val outputStream = resolver.openOutputStream(imageOutUri)
                inputStream?.use { input ->
                    outputStream?.use { output ->
                        input.copyTo(output)
                    }
                }
            }
            imageOutUri
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }

    private fun extractTextFromImage(imageUri: Uri, callback: (String) -> Unit) {
        try {
            val image = InputImage.fromFilePath(this, imageUri)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.Builder().build())

            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    callback(visionText.text)
                }
                .addOnFailureListener {
                    it.printStackTrace()
                    callback("Error al reconocer texto")
                }
        } catch (e: Exception) {
            e.printStackTrace()
            callback("Error al cargar imagen para OCR")
        }
    }

    fun extraerDatosDesdeTexto(text: String): Map<String, String> {
        val datos = mutableMapOf<String, String>()

        val regexMap = mapOf(
            "Bitácora" to Regex("""Bitácora:\s*(\d+)"""),
            "Fecha" to Regex("""Fecha:\s*([0-9:\- ]+)"""),
            "Empleado" to Regex("""Empleado:\s*(\d+)"""),
            "Chófer" to Regex("""(?i)ch[oó]fer\s*[:\-]?\s*([A-Za-zÁÉÍÓÚÑáéíóúñ\s]+)"""),
            "Camión" to Regex("""(?i)cami[oó]n\s*[:\-]?\s*([\w\d]+)"""),
            "Caja1" to Regex("""(?i)caja\s*#?1\s*[:\-]?\s*([\w\d]+)"""),
            "Caja2" to Regex("""(?i)caja\s*#?2\s*[:\-]?\s*([\w\d]+)"""),
            "Sello" to Regex("""Sello:\s*(\d+)"""),
            "SelloRepuesto" to Regex("""SelloRepuesto:\s*(\d+)"""),
            "Origen" to Regex("""Origen:\s*([\w\s.#]+)"""),
            "Destino" to Regex("""Destino:\s*([\w\s.#]+)""")
        )

        for ((clave, regex) in regexMap) {
            val match = regex.find(text)
            if (match != null && match.groupValues.size > 1) {
                datos[clave] = match.groupValues[1].trim()
            }
        }
        return datos
    }
}