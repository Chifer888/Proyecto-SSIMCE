package com.example.ssimce.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ProductoDao {
    @Query("SELECT * FROM productos WHERE codigo = :codigo LIMIT 1")
    suspend fun buscarPorCodigo(codigo: String): Producto?
    
    @Query("SELECT * FROM productos ORDER BY codigo")
    suspend fun obtenerTodosLosProductos(): List<Producto>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarProducto(producto: Producto)

    @Query("DELETE FROM productos")
    suspend fun borrarTodos()
}
