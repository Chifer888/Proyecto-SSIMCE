package com.example.ssimce.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        Irregularidad::class,
        Producto::class,
        MRBRegistro::class,
        CTRegistro::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun irregularidadDao(): IrregularidadDao
    abstract fun productoDao(): ProductoDao
    abstract fun mrbRegistroDao(): MRBRegistroDao
    abstract fun ctRegistroDao(): CTRegistroDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ssimce_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        fun clearDatabase(context: Context) {
            INSTANCE?.close()
            INSTANCE = null
            }
        }
    }