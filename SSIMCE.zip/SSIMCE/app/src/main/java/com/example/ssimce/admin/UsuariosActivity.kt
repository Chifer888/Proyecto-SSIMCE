package com.example.ssimce.admin

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.ssimce.R
import org.json.JSONObject
import androidx.core.content.ContextCompat
import android.view.ViewGroup

class UsuariosActivity : AppCompatActivity() {
    
    private lateinit var edtNombre: EditText
    private lateinit var edtApellido: EditText
    private lateinit var edtUsuario: EditText
    private lateinit var edtPassword: EditText
    private lateinit var spnPerfil: Spinner
    private lateinit var edtEmail: EditText
    private lateinit var edtTelefono: EditText
    private lateinit var chkActivo: CheckBox
    private lateinit var btnGuardar: Button
    private lateinit var btnModificar: Button
    private lateinit var btnEliminar: Button
    private lateinit var btnLimpiar: Button
    private lateinit var listViewUsuarios: ListView
    private lateinit var progressBar: ProgressBar
    
    private var usuarioSeleccionado: JSONObject? = null
    private var modoEdicion = false
    
    companion object {
        private const val SERVER_URL = "http://192.168.1.65/ssimce/"
        private const val API_KEY = "MI_API_KEY_SECRETA"
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_usuarios)
        
        inicializarVistas()
        configurarSpinner()
        configurarEventos()
        cargarUsuarios()
    }
    
    private fun inicializarVistas() {
        edtNombre = findViewById(R.id.edtNombre)
        edtApellido = findViewById(R.id.edtApellido)
        edtUsuario = findViewById(R.id.edtUsuario)
        edtPassword = findViewById(R.id.edtPassword)
        spnPerfil = findViewById(R.id.spnPerfil)
        edtEmail = findViewById(R.id.edtEmail)
        edtTelefono = findViewById(R.id.edtTelefono)
        chkActivo = findViewById(R.id.chkActivo)
        btnGuardar = findViewById(R.id.btnGuardar)
        btnModificar = findViewById(R.id.btnModificar)
        btnEliminar = findViewById(R.id.btnEliminar)
        btnLimpiar = findViewById(R.id.btnLimpiar)
        listViewUsuarios = findViewById(R.id.listViewUsuarios)
        progressBar = findViewById(R.id.progressBar)
    }
    
    private fun configurarSpinner() {
        val perfiles = arrayOf("admin", "supervisor", "rampero", "operador")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, perfiles)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spnPerfil.adapter = adapter
    }
    
    private fun configurarEventos() {
        btnGuardar.setOnClickListener { guardarUsuario() }
        btnModificar.setOnClickListener { modificarUsuario() }
        btnEliminar.setOnClickListener { eliminarUsuario() }
        btnLimpiar.setOnClickListener { limpiarFormulario() }
        
        listViewUsuarios.setOnItemClickListener { _, _, position, _ ->
            seleccionarUsuario(position)
        }
    }
    
    private fun cargarUsuarios() {
        progressBar.visibility = View.VISIBLE
        
        val request = object : JsonObjectRequest(
            Request.Method.GET,
            "${SERVER_URL}usuarios/obtener_usuarios.php",
            null,
            { response ->
                progressBar.visibility = View.GONE
                if (response.optBoolean("success", false)) {
                    mostrarUsuarios(response.optJSONArray("usuarios"))
                } else {
                    Toast.makeText(this, "Error: ${response.optString("message", "")}", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                progressBar.visibility = View.GONE
                Toast.makeText(this, "Error de conexión: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = API_KEY
                return headers
            }
        }
        
        Volley.newRequestQueue(this).add(request)
    }
    
    private fun mostrarUsuarios(usuariosArray: org.json.JSONArray?) {
        if (usuariosArray == null) return
        
        val usuarios = mutableListOf<String>()
        for (i in 0 until usuariosArray.length()) {
            val usuario = usuariosArray.getJSONObject(i)
            val nombre = usuario.optString("nombre", "")
            val apellido = usuario.optString("apellido", "")
            val user = usuario.optString("usuario", "")
            val perfil = usuario.optString("perfil", "")
            val activo = if (usuario.optBoolean("activo", true)) "Activo" else "Inactivo"
            
            usuarios.add("$nombre $apellido ($user) - $perfil - $activo")
        }
        
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, usuarios) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                val textView = view.findViewById<TextView>(android.R.id.text1)
                textView.setTextColor(ContextCompat.getColor(context, android.R.color.holo_blue_dark))
                return view
            }
        }
        listViewUsuarios.adapter = adapter
    }
    
    private fun seleccionarUsuario(position: Int) {
        val request = object : JsonObjectRequest(
            Request.Method.GET,
            "${SERVER_URL}usuarios/obtener_usuarios.php",
            null,
            { response ->
                if (response.optBoolean("success", false)) {
                    val usuariosArray = response.optJSONArray("usuarios")
                    if (usuariosArray != null && position < usuariosArray.length()) {
                        usuarioSeleccionado = usuariosArray.getJSONObject(position)
                        llenarFormulario(usuarioSeleccionado!!)
                        modoEdicion = true
                        btnGuardar.visibility = View.GONE
                        btnModificar.visibility = View.VISIBLE
                        btnEliminar.visibility = View.VISIBLE
                    }
                }
            },
            { error ->
                Toast.makeText(this, "Error de conexión: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = API_KEY
                return headers
            }
        }
        
        Volley.newRequestQueue(this).add(request)
    }
    
    private fun llenarFormulario(usuario: JSONObject) {
        edtNombre.setText(usuario.optString("nombre", ""))
        edtApellido.setText(usuario.optString("apellido", ""))
        edtUsuario.setText(usuario.optString("usuario", ""))
        edtPassword.setText("") // No mostrar contraseña
        edtEmail.setText(usuario.optString("email", ""))
        edtTelefono.setText(usuario.optString("telefono", ""))
        chkActivo.isChecked = usuario.optBoolean("activo", true)
        
        val perfil = usuario.optString("perfil", "operador")
        val perfiles = arrayOf("admin", "supervisor", "rampero", "operador")
        val index = perfiles.indexOf(perfil)
        if (index >= 0) {
            spnPerfil.setSelection(index)
        }
    }
    
    private fun guardarUsuario() {
        if (!validarCampos()) return
        
        val jsonObject = JSONObject().apply {
            put("nombre", edtNombre.text.toString().trim())
            put("apellido", edtApellido.text.toString().trim())
            put("usuario", edtUsuario.text.toString().trim())
            put("password", edtPassword.text.toString())
            put("perfil", spnPerfil.selectedItem.toString())
            put("email", edtEmail.text.toString().trim())
            put("telefono", edtTelefono.text.toString().trim())
        }
        
        val request = object : JsonObjectRequest(
            Request.Method.POST,
            "${SERVER_URL}usuarios/guardar_usuario.php",
            jsonObject,
            { response ->
                if (response.optBoolean("success", false)) {
                    Toast.makeText(this, "✅ Usuario guardado exitosamente", Toast.LENGTH_SHORT).show()
                    limpiarFormulario()
                    cargarUsuarios()
                } else {
                    Toast.makeText(this, "Error: ${response.optString("message", "")}", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Toast.makeText(this, "Error de conexión: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = API_KEY
                return headers
            }
        }
        
        Volley.newRequestQueue(this).add(request)
    }
    
    private fun modificarUsuario() {
        if (usuarioSeleccionado == null) {
            Toast.makeText(this, "Seleccione un usuario para modificar", Toast.LENGTH_SHORT).show()
            return
        }
        
        if (!validarCampos()) return
        
        val jsonObject = JSONObject().apply {
            put("id", usuarioSeleccionado!!.optInt("id"))
            put("nombre", edtNombre.text.toString().trim())
            put("apellido", edtApellido.text.toString().trim())
            put("usuario", edtUsuario.text.toString().trim())
            put("password", edtPassword.text.toString())
            put("perfil", spnPerfil.selectedItem.toString())
            put("email", edtEmail.text.toString().trim())
            put("telefono", edtTelefono.text.toString().trim())
            put("activo", chkActivo.isChecked)
        }
        
        val request = object : JsonObjectRequest(
            Request.Method.POST,
            "${SERVER_URL}usuarios/modificar_usuario.php",
            jsonObject,
            { response ->
                if (response.optBoolean("success", false)) {
                    Toast.makeText(this, "✅ Usuario modificado exitosamente", Toast.LENGTH_SHORT).show()
                    limpiarFormulario()
                    cargarUsuarios()
                } else {
                    Toast.makeText(this, "Error: ${response.optString("message", "")}", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Toast.makeText(this, "Error de conexión: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = API_KEY
                return headers
            }
        }
        
        Volley.newRequestQueue(this).add(request)
    }
    
    private fun eliminarUsuario() {
        if (usuarioSeleccionado == null) {
            Toast.makeText(this, "Seleccione un usuario para eliminar", Toast.LENGTH_SHORT).show()
            return
        }
        
        AlertDialog.Builder(this)
            .setTitle("Confirmar eliminación")
            .setMessage("¿Está seguro de que desea eliminar este usuario?")
            .setPositiveButton("Sí") { _, _ ->
                ejecutarEliminacion()
            }
            .setNegativeButton("No", null)
            .show()
    }
    
    private fun ejecutarEliminacion() {
        val jsonObject = JSONObject().apply {
            put("id", usuarioSeleccionado!!.optInt("id"))
        }
        
        val request = object : JsonObjectRequest(
            Request.Method.POST,
            "${SERVER_URL}usuarios/eliminar_usuario.php",
            jsonObject,
            { response ->
                if (response.optBoolean("success", false)) {
                    Toast.makeText(this, "✅ Usuario eliminado exitosamente", Toast.LENGTH_SHORT).show()
                    limpiarFormulario()
                    cargarUsuarios()
                } else {
                    Toast.makeText(this, "Error: ${response.optString("message", "")}", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Toast.makeText(this, "Error de conexión: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = API_KEY
                return headers
            }
        }
        
        Volley.newRequestQueue(this).add(request)
    }
    
    private fun validarCampos(): Boolean {
        if (edtNombre.text.toString().trim().isEmpty()) {
            edtNombre.error = "Campo requerido"
            return false
        }
        if (edtApellido.text.toString().trim().isEmpty()) {
            edtApellido.error = "Campo requerido"
            return false
        }
        if (edtUsuario.text.toString().trim().isEmpty()) {
            edtUsuario.error = "Campo requerido"
            return false
        }
        if (!modoEdicion && edtPassword.text.toString().isEmpty()) {
            edtPassword.error = "Campo requerido"
            return false
        }
        return true
    }
    
    private fun limpiarFormulario() {
        edtNombre.text.clear()
        edtApellido.text.clear()
        edtUsuario.text.clear()
        edtPassword.text.clear()
        edtEmail.text.clear()
        edtTelefono.text.clear()
        chkActivo.isChecked = true
        spnPerfil.setSelection(3) // operador por defecto
        
        usuarioSeleccionado = null
        modoEdicion = false
        btnGuardar.visibility = View.VISIBLE
        btnModificar.visibility = View.GONE
        btnEliminar.visibility = View.GONE
    }
} 