package com.example.ssimce

import com.android.volley.NetworkResponse
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.HttpHeaderParser
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.IOException

open class VolleyMultipartRequest(
    method: Int,
    url: String,
    private val listener: Response.Listener<NetworkResponse>,
    errorListener: Response.ErrorListener
) : Request<NetworkResponse>(method, url, errorListener) {

    private var responseHeaders: MutableMap<String, String> = HashMap()

    override fun getHeaders(): MutableMap<String, String> {
        return super.getHeaders()
    }

    override fun getBodyContentType(): String {
        return "$boundaryPrefix$boundary; charset=UTF-8"
    }

    override fun getBody(): ByteArray {
        val bos = ByteArrayOutputStream()
        val dos = DataOutputStream(bos)

        try {
            // Text
            getParams()?.forEach { (key, value) ->
                buildTextPart(dos, key, value)
            }

            // Files
            getByteData().forEach { (key, dataPart) ->
                buildFilePart(dos, key, dataPart)
            }

            // End boundary
            dos.writeBytes("--$boundary--\r\n")
        } catch (e: IOException) {
            e.printStackTrace()
        }

        return bos.toByteArray()
    }

    override fun parseNetworkResponse(response: NetworkResponse): Response<NetworkResponse> {
        responseHeaders = response.headers?.toMutableMap() ?: mutableMapOf()
        return Response.success(response, HttpHeaderParser.parseCacheHeaders(response))
    }

    override fun deliverResponse(response: NetworkResponse) {
        listener.onResponse(response)
    }

    open fun getByteData(): MutableMap<String, DataPart> = HashMap()

    private fun buildTextPart(dos: DataOutputStream, parameterName: String, parameterValue: String) {
        dos.writeBytes("--$boundary\r\n")
        dos.writeBytes("Content-Disposition: form-data; name=\"$parameterName\"\r\n\r\n")
        dos.writeBytes(parameterValue + "\r\n")
    }

    private fun buildFilePart(dos: DataOutputStream, parameterName: String, dataFile: DataPart) {
        dos.writeBytes("--$boundary\r\n")
        dos.writeBytes("Content-Disposition: form-data; name=\"$parameterName\"; filename=\"${dataFile.fileName}\"\r\n")
        dos.writeBytes("Content-Type: ${dataFile.type}\r\n\r\n")
        dos.write(dataFile.content)
        dos.writeBytes("\r\n")
    }

    data class DataPart(
        val fileName: String,
        val content: ByteArray,
        val type: String
    )

    companion object {
        private val boundary = "apiclient-${System.currentTimeMillis()}"
        private const val boundaryPrefix = "multipart/form-data; boundary="
    }
}