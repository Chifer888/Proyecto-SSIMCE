package com.example.ssimce.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface CTRegistroDao {
    @Insert
    suspend fun insertarCTRegistro(ctRegistro: CTRegistro)
    
    @Query("SELECT * FROM ct_registros ORDER BY fecha DESC")
    suspend fun obtenerTodosLosRegistros(): List<CTRegistro>
} 