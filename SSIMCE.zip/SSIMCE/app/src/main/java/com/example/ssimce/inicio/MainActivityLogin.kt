package com.example.ssimce.inicio

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.ssimce.R
import java.security.MessageDigest

class MainActivityLogin : AppCompatActivity() {

    private val usuarioCorrectoHash = "8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92"

    private val passwordCorrectoHash = "2270e73a86e507f7a99d98e739a62f96ec812c1a19b37a0db27785e620518566"

    companion object {
        private const val SMS_PERMISSION_REQUEST = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_login)

        val editTextNumber = findViewById<EditText>(R.id.editTextNumber)
        val editTextPassword = findViewById<EditText>(R.id.editTextPassword)
        val btnLlave = findViewById<Button>(R.id.btnLlave)
        val radioButtonOlvideContrasena = findViewById<RadioButton>(R.id.radioButtonOlvideContrasena)

        val validar = {
            val usuarioInput = editTextNumber.text.toString()
            val passInput = editTextPassword.text.toString()

            val usuarioHash = hashString(usuarioInput)
            val passHash = hashString(passInput)

            if (usuarioHash == usuarioCorrectoHash && passHash == passwordCorrectoHash) {
                // Credenciales correctas: mostrar botón llave y desactivar RadioButton
                mostrarBiometria {
                    btnLlave.visibility = View.VISIBLE
                    // Desactivar RadioButton para evitar envío de SMS
                    radioButtonOlvideContrasena.isEnabled = false
                    radioButtonOlvideContrasena.isChecked = false
                }
            } else {
                // Credenciales incorrectas: ocultar botón llave y activar RadioButton
                btnLlave.visibility = View.GONE
                radioButtonOlvideContrasena.isEnabled = true
            }
        }

        editTextNumber.addTextChangedListener(textWatcher(validar))
        editTextPassword.addTextChangedListener(textWatcher(validar))

        btnLlave.setOnClickListener {
            // Guardar número de empleado en SharedPreferences
            val sharedPreferences = getSharedPreferences("login_prefs", MODE_PRIVATE)
            val editor = sharedPreferences.edit()
            editor.putString("numero_empleado", editTextNumber.text.toString())
            editor.apply()
            
            val intent = Intent(this, MainActivityMenuPrincipal::class.java)
            intent.putExtra("usuario", editTextNumber.text.toString())
            startActivity(intent)
            finish()
        }

        // Configurar RadioButton para "Olvide mi contraseña"
        radioButtonOlvideContrasena.setOnClickListener {
            // Solo permitir acceso si las credenciales son incorrectas
            if (radioButtonOlvideContrasena.isEnabled) {
                mostrarDialogoOlvideContrasena()
            }
        }
    }

    private fun hashString(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun textWatcher(onChange: () -> Unit): TextWatcher {
        return object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = onChange()
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }
    }

    private fun mostrarBiometria(onSuccess: () -> Unit) {
        val executor = ContextCompat.getMainExecutor(this)
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Autenticación biométrica")
            .setSubtitle("Verifica tu identidad para continuar")
            .setNegativeButtonText("Cancelar")
            .build()

        val biometricPrompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    Toast.makeText(applicationContext, "Autenticación exitosa", Toast.LENGTH_SHORT).show()
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    Toast.makeText(applicationContext, "Error: $errString", Toast.LENGTH_SHORT).show()
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    Toast.makeText(applicationContext, "Huella no reconocida", Toast.LENGTH_SHORT).show()
                }
            })

        biometricPrompt.authenticate(promptInfo)
    }

    private fun mostrarDialogoOlvideContrasena() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Recuperar Contraseña")
        builder.setMessage("Se enviará un mensaje SMS al administrador para solicitar la recuperación de su contraseña.")
        
        builder.setPositiveButton("Enviar SMS") { _, _ ->
            enviarSMSAdministrador()
        }
        
        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.dismiss()
        }
        
        builder.show()
    }

    private fun enviarSMSAdministrador() {
        // Verificar permisos de SMS
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.SEND_SMS), SMS_PERMISSION_REQUEST)
            return
        }
        
        try {
            // Número y plantilla de mensaje encriptados con SHA-256
            val numeroHash = "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918" // Hash de 522411164639
            val mensajeHash = "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3" // Hash del mensaje real
            
            // Desencriptar usando la función hashString (comparar hashes)
            val numeroAdministrador = obtenerValorDesdeHash(numeroHash)
            val plantillaMensaje = obtenerValorDesdeHash(mensajeHash)

            // Obtener número de empleado
            val numeroEmpleado = findViewById<EditText>(R.id.editTextNumber).text.toString().padStart(8, '0')
            val mensaje = plantillaMensaje.replace("XXXXXXXX", numeroEmpleado)
            
            // Enviar SMS directamente usando SmsManager
            try {
                val smsManager = android.telephony.SmsManager.getDefault()
                smsManager.sendTextMessage(numeroAdministrador, null, mensaje, null, null)
                Toast.makeText(this, "SMS enviado exitosamente", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                // Si falla el envío directo, mostrar el mensaje para copiar
                Toast.makeText(this, "Error al enviar SMS. Mensaje: $mensaje", Toast.LENGTH_LONG).show()
            }
            
        } catch (e: Exception) {
            Toast.makeText(this, "Error al procesar SMS: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun obtenerValorDesdeHash(hash: String): String {
        // Mapeo de hashes conocidos a valores originales
        val hashMap = mapOf(
            "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918" to "522411164639", // Tu número con código de país (sin espacios ni +)
            "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3" to "Falla de acceso, usuario XXXXXXXX." // Mensaje
        )
        return hashMap[hash] ?: "Valor no encontrado"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            SMS_PERMISSION_REQUEST -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permiso concedido, enviar SMS
                    enviarSMSAdministrador()
                } else {
                    Toast.makeText(this, "Permiso de SMS denegado", Toast.LENGTH_SHORT).show()
                }
            }
    }
}
}