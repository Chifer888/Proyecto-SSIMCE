package com.example.ssimce.inicio

//Se importan las clases que se van a utilizar
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import com.example.ssimce.R

//Intent: para cambiar de pantalla.
//Handler: para ejecutar código en el hilo principal.
//Looper: para determinar el hilo principal.
//View: para controlar la visibilidad de las imágenes.
//ImageView: para mostrar las imágenes.
//AppCompatActivity: para la actividad principal.
//Bundle: para pasar datos entre actividades.
class MainActivity : AppCompatActivity() {

    private lateinit var imageViews: List<ImageView>
    private var currentIndex = 0
    private val displayTime: Long = 1000 // tiempo en milisegundos entre cada imagen al inicio de la app
    private val handler = Handler(Looper.getMainLooper()) // Para ejecutarse en el hilo principal

    //
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //
        imageViews = listOf( //lista de imagenes utilizadas
            findViewById(R.id.imageView1),
            findViewById(R.id.imageView2),
            findViewById(R.id.imageView3),
            findViewById(R.id.imageView4)
        )

        // Oculta todas las imágenes menos la primera
        imageViews.forEachIndexed { index, imageView ->
            imageView.visibility = if (index == 0) View.VISIBLE else View.GONE
        }

        // En esta parte se define y se usa el Runnable
        val runnable = object : Runnable {
            override fun run() {
                // Oculta la imagen actual
                imageViews[currentIndex].visibility = View.GONE

                // Avanza al siguiente índice si no es el último
                if (currentIndex < imageViews.size - 1) {
                    currentIndex++
                    imageViews[currentIndex].visibility = View.VISIBLE
                    handler.postDelayed(this, displayTime) // ← Este es el paso automático
                } else {
                    // Última imagen mostrada → lanza MainActivityLogin
                    val intent = Intent(this@MainActivity, MainActivityLogin::class.java)
                    startActivity(intent)
                    finish() // Opcional: cierra MainActivity para que no se pueda regresar con "back"
                }
            }
        }

        // Ejecuta la primera vez después del tiempo inicial
        handler.postDelayed(runnable, displayTime)
    }
}