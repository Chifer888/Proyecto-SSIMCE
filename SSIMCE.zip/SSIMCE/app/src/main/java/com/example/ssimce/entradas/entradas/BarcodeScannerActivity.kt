package com.example.ssimce.entradas.entradas

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.ssimce.R
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class BarcodeScannerActivity : AppCompatActivity() {

    private lateinit var cameraExecutor: ExecutorService
    private lateinit var previewView: PreviewView
    private lateinit var btnBack: Button
    private lateinit var tvStatus: TextView
    private lateinit var mediaPlayer: MediaPlayer
    
    private var tipoTabla: String = "ENTREGAS_CLIENTES"
    private var scannedCodes = mutableListOf<String>()

    companion object {
        private const val REQUEST_CODE_PERMISSIONS = 10
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_barcode_scanner)

        // Obtener tipo de tabla del intent
        tipoTabla = intent.getStringExtra("TIPO_TABLA") ?: "ENTREGAS_CLIENTES"

        // Inicializar vistas
        previewView = findViewById(R.id.previewView)
        btnBack = findViewById(R.id.btnBack)
        tvStatus = findViewById(R.id.tvStatus)

        // Inicializar MediaPlayer para sonido
        try {
            mediaPlayer = MediaPlayer.create(this, android.provider.Settings.System.DEFAULT_NOTIFICATION_URI)
            if (mediaPlayer == null) {
                // Fallback: crear un MediaPlayer básico
                mediaPlayer = MediaPlayer()
            }
        } catch (e: Exception) {
            // Si falla, crear un MediaPlayer básico
            mediaPlayer = MediaPlayer()
        }

        // Configurar botón de regreso
        btnBack.setOnClickListener {
            finish()
        }

        // Solicitar permisos de cámara
        if (allPermissionsGranted()) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(
                this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS
            )
        }

        cameraExecutor = Executors.newSingleThreadExecutor()
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder()
                .build()
                .also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

            val imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor, BarcodeAnalyzer { barcode ->
                        onBarcodeDetected(barcode)
                    })
                }

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    imageAnalyzer
                )
            } catch (exc: Exception) {
                Toast.makeText(this, "Error al iniciar la cámara", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onBarcodeDetected(barcode: String) {
        println("DEBUG: Código detectado: $barcode")
        
        // Procesar el código de barras para extraer información
        val (sku, description, quantity) = procesarCodigoBarras(barcode)
        
        runOnUiThread {
            // Reproducir sonido (más rápido)
            playBeepSound()
            
            // Vibrar para confirmar escaneo (más corto)
            try {
                val vibrator = getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    vibrator.vibrate(android.os.VibrationEffect.createOneShot(50, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(50)
                }
            } catch (e: Exception) {
                println("DEBUG: Error en vibración: ${e.message}")
            }
            
            // Mostrar mensaje de confirmación
            tvStatus.text = "Código escaneado: $barcode\nRegresando..."
            
            // Regresar inmediatamente con los datos
            val intent = Intent()
            intent.putExtra("SCANNED_SKU", sku)
            intent.putExtra("SCANNED_DESCRIPTION", description)
            intent.putExtra("SCANNED_QUANTITY", quantity)
            setResult(RESULT_OK, intent)
            finish()
        }
    }

    private fun procesarCodigoBarras(codigo: String): Triple<String, String, String> {
        return when (tipoTabla) {
            "LOTEO_JABAS" -> procesarCodigoLoteoJabas(codigo)
            "ROPA" -> procesarCodigoRopa(codigo)
            else -> procesarCodigoGenerico(codigo)
        }
    }

    private fun procesarCodigoLoteoJabas(codigo: String): Triple<String, String, String> {
        val sku = codigo // Mostrar el código completo en SKU
        
        val descripcion = when {
            codigo.startsWith("M", ignoreCase = true) -> "Loteo Muebles"
            codigo.startsWith("C", ignoreCase = true) -> "Loteo Celulares"
            else -> "Producto Loteo: $codigo"
        }
        
        val quantity = "1"
        return Triple(sku, descripcion, quantity)
    }

    private fun procesarCodigoRopa(codigo: String): Triple<String, String, String> {
        val sku = codigo // Mostrar el código completo en SKU
        
        val descripcion = when {
            codigo.contains("J-GD", ignoreCase = true) -> "Jaba Grande"
            codigo.contains("J-CH", ignoreCase = true) -> "Jaba Chica"
            codigo.contains("CART", ignoreCase = true) -> "Carton"
            else -> "Producto Ropa: $codigo"
        }
        
        val quantity = "1"
        return Triple(sku, descripcion, quantity)
    }

    private fun procesarCodigoGenerico(codigo: String): Triple<String, String, String> {
        return when {
            // Código EAN-13 (13 dígitos)
            codigo.length == 13 && codigo.all { it.isDigit() } -> {
                val sku = codigo.substring(0, 8) // Primeros 8 dígitos como SKU
                val description = "Producto EAN-13: ${codigo.substring(8)}" // Resto como descripción
                val quantity = "1"
                Triple(sku, description, quantity)
            }
            // Código UPC-A (12 dígitos)
            codigo.length == 12 && codigo.all { it.isDigit() } -> {
                val sku = codigo.substring(0, 6) // Primeros 6 dígitos como SKU
                val description = "Producto UPC-A: ${codigo.substring(6)}" // Resto como descripción
                val quantity = "1"
                Triple(sku, description, quantity)
            }
            // Código Code 128 (alfanumérico) - mostrar completo
            else -> {
                val sku = codigo // Mostrar el código completo
                val description = "Producto escaneado: $codigo"
                val quantity = "1"
                Triple(sku, description, quantity)
            }
        }
    }

    private fun playBeepSound() {
        try {
            // Usar ToneGenerator directamente para respuesta más rápida
            val toneGenerator = android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 100)
            toneGenerator.startTone(android.media.ToneGenerator.TONE_PROP_BEEP, 100)
            toneGenerator.release()
            println("DEBUG: Sonido reproducido exitosamente")
        } catch (e: Exception) {
            println("DEBUG: Error reproduciendo sonido: ${e.message}")
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                startCamera()
            } else {
                Toast.makeText(this, "Permisos no concedidos", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        mediaPlayer.release()
    }

    // Analizador de códigos de barras
    private class BarcodeAnalyzer(private val onBarcodeDetected: (String) -> Unit) : ImageAnalysis.Analyzer {
        private val scanner = BarcodeScanning.getClient()

        @androidx.camera.core.ExperimentalGetImage
        override fun analyze(imageProxy: ImageProxy) {
            val mediaImage = imageProxy.image
            if (mediaImage != null) {
                val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                
                scanner.process(image)
                    .addOnSuccessListener { barcodes ->
                        println("DEBUG: Analizando imagen, códigos encontrados: ${barcodes.size}")
                        for (barcode in barcodes) {
                            barcode.rawValue?.let { value ->
                                println("DEBUG: Código de barras encontrado: $value")
                                onBarcodeDetected(value)
                            }
                        }
                    }
                    .addOnFailureListener { exception ->
                        println("DEBUG: Error procesando imagen: ${exception.message}")
                        imageProxy.close()
                    }
                    .addOnCompleteListener {
                        imageProxy.close()
                    }
            } else {
                println("DEBUG: MediaImage es null")
                imageProxy.close()
            }
        }
    }
} 