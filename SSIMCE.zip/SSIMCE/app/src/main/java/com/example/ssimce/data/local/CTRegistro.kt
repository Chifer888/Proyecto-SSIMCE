package com.example.ssimce.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ct_registros")
data class CTRegistro(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val ct: String,
    val tienda: String,
    val folioTS: String,
    val sku: String,
    val descripcion: String,
    val motivo: String,
    val cantidad: String,
    val observaciones: String,
    val evidenciaUri: String,
    val fecha: String
) 