package com.example.ssimce

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

class MainActivitySalidas : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_salidas)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        
        // Configurar fecha actual
        configurarFechaActual()
        
        val btnHome = findViewById<Button>(R.id.btnHome)
        btnHome.setOnClickListener {
            val intent = Intent(this, com.example.ssimce.inicio.MainActivityMenuPrincipal::class.java)
            startActivity(intent)
            finishAffinity()
        }
        
        // Configurar EditText para abrir PDA Salidas al presionar Enter
        val editTextFolio = findViewById<EditText>(R.id.editTextText)
        editTextFolio.setOnEditorActionListener { v, actionId, event ->
            val folio = editTextFolio.text.toString().trim()
            if (folio.isNotEmpty()) {
                // Abrir actividad PDA Salidas
                val intent = Intent(this, com.example.ssimce.salidas.PdaSalidasActivity::class.java)
                startActivity(intent)
            }
            false // Permite que el evento siga su curso normal
        }
    }
    
    private fun configurarFechaActual() {
        val txtFecha = findViewById<TextView>(R.id.txtFechaCT)
        val fechaActual = Calendar.getInstance()
        val formatoFecha = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val fechaFormateada = formatoFecha.format(fechaActual.time)
        txtFecha.text = fechaFormateada
    }
}