package com.example.ssimce.entradas.bitacora

data class LineaBitacora(
    val tipo: String,
    var folio: String,
    var destino: String = ""
) 