package com.example.ssimce.inicio

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.view.animation.ScaleAnimation
import android.widget.ImageView
import android.view.MenuItem
import android.widget.ImageButton
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ssimce.envios.MainActivityEnvios
import com.example.ssimce.IrregularidadesActivity
import com.example.ssimce.MainActivitySalidas
import com.example.ssimce.R
import com.example.ssimce.entradas.guia.MainActivityEscaneoGuia
import com.example.ssimce.admin.CatalogoProductosActivity
import com.example.ssimce.admin.UsuariosActivity

class MainActivityMenuPrincipal : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_menu_principal)

        // Configurar saludo personalizado
        configurarSaludoUsuario()

        val btnMenuOpciones = findViewById<ImageButton>(R.id.btnMenuOpciones)
        btnMenuOpciones.setOnClickListener { v ->
            val popup = PopupMenu(this, v)
            popup.menuInflater.inflate(R.menu.menu_opciones, popup.menu)
            popup.setOnMenuItemClickListener { item: MenuItem ->
                when (item.itemId) {
                    R.id.menu_catalogo_productos -> {
                        startActivity(Intent(this, CatalogoProductosActivity::class.java))
                        true
                    }
                    R.id.menu_usuarios -> {
                        startActivity(Intent(this, UsuariosActivity::class.java))
                        true
                    }
                    else -> false
                }
            }
            popup.show()
        }

        val imagenes = listOf(
            findViewById(R.id.imageZoomEntradas),
            findViewById(R.id.imageZoomEnvios),
            findViewById(R.id.imageZoomSalidas),
            findViewById(R.id.imageZoomIrregularidades),
            findViewById<ImageView>(R.id.imageZoomSalir)
        )

        imagenes.forEach { image ->
            image.setOnTouchListener { v, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        ampliarImagen()
                        ejecutarFuncion(image.id)
                        true
                    }

                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        restaurarImagen(v)
                        true
                    }

                    else -> false
                }
            }
        }
    }

    private fun ampliarImagen() {
        // Animación opcional si deseas implementarla.
    }

    private fun restaurarImagen(v: View?) {
        v?.let {
            val scaleDown = ScaleAnimation(
                1.5f, 1f,
                1.5f, 1f,
                ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
                ScaleAnimation.RELATIVE_TO_SELF, 0.5f
            )
            scaleDown.duration = 200
            scaleDown.fillAfter = true
            it.startAnimation(scaleDown)
        }
    }

    private fun ejecutarFuncion(viewId: Int) {
        when (viewId) {
            R.id.imageZoomEntradas -> startActivity(
                Intent(
                    this,
                    MainActivityEscaneoGuia::class.java
                )
            )
            R.id.imageZoomEnvios -> startActivity(Intent(this, MainActivityEnvios::class.java))
            R.id.imageZoomSalidas -> startActivity(Intent(this, MainActivitySalidas::class.java))
            R.id.imageZoomIrregularidades -> startActivity(
                Intent(
                    this,
                    IrregularidadesActivity::class.java
                )
            )
            R.id.imageZoomSalir -> finish()
        }
    }

    private fun configurarSaludoUsuario() {
        try {
            val txtSaludoUsuario = findViewById<TextView>(R.id.txtSaludoUsuario)
            val sharedPreferences = getSharedPreferences("login_prefs", MODE_PRIVATE)
            val numeroEmpleado = sharedPreferences.getString("numero_empleado", "") ?: ""
            
            Log.d("MainActivityMenuPrincipal", "Número de empleado leído: '$numeroEmpleado'")
            
            val nombreColaborador = obtenerNombreColaborador(numeroEmpleado)
            Log.d("MainActivityMenuPrincipal", "Nombre colaborador: '$nombreColaborador'")
            
            txtSaludoUsuario.text = "¡Hola $nombreColaborador!"
            
            // Asegurar que el TextView esté visible y por encima de otros elementos
            txtSaludoUsuario.visibility = View.VISIBLE
            txtSaludoUsuario.bringToFront()
            
            Log.d("MainActivityMenuPrincipal", "Saludo configurado: ¡Hola $nombreColaborador!")
            
        } catch (e: Exception) {
            Log.e("MainActivityMenuPrincipal", "Error configurando saludo: ${e.message}")
        }
    }

    private fun obtenerNombreColaborador(numeroEmpleado: String): String {
        return when (numeroEmpleado) {
            "123456" -> "Admin"
            "1234567" -> "Juan Pérez"
            "1234568" -> "María García"
            "1234569" -> "Carlos López"
            "1234570" -> "Ana Martínez"
            else -> "Usuario"
        }
    }
}