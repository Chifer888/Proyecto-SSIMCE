package com.example.ssimce.entradas.entradas

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.ssimce.R
import com.bumptech.glide.Glide
import android.util.Log
import androidx.lifecycle.lifecycleScope
import com.example.ssimce.data.local.AppDatabase
import com.example.ssimce.data.local.Irregularidad
import kotlinx.coroutines.launch
import org.json.JSONObject

class PdaSurtidoTiendasActivity : AppCompatActivity() {
    private lateinit var editSKU: EditText
    private lateinit var editDescripcion: EditText
    private lateinit var editCantidad: EditText
    private lateinit var btnGuardar: Button
    private lateinit var btnLimpiar: Button
    private lateinit var btnRegresar: Button
    private lateinit var btnEscanear: Button
    private lateinit var imageViewProducto: ImageView
    private lateinit var progressBarBusqueda: ProgressBar

    private val SERVER_URL = "http://192.168.1.65/ssimce/"
    private val API_KEY = "MI_API_KEY_SECRETA"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pda_surtido_tiendas)
        editSKU = findViewById(R.id.editSKU)
        editDescripcion = findViewById(R.id.editDescripcion)
        editCantidad = findViewById(R.id.editCantidad)
        btnGuardar = findViewById(R.id.btnGuardar)
        btnLimpiar = findViewById(R.id.btnLimpiar)
        btnRegresar = findViewById(R.id.btnRegresar)
        btnEscanear = findViewById(R.id.btnEscanear)
        imageViewProducto = findViewById(R.id.imageViewProducto)
        progressBarBusqueda = findViewById(R.id.progressBarBusqueda)
        btnGuardar.setOnClickListener { guardarDatos() }
        btnLimpiar.setOnClickListener { limpiarFormulario() }
        btnRegresar.setOnClickListener { finish() }
        btnEscanear.setOnClickListener { abrirScanner() }
        configurarValidaciones()
        configurarBusquedaAutomatica()
        editSKU.setOnEditorActionListener { v, actionId, event ->
            val sku = editSKU.text.toString().trim()
            if (sku.isNotEmpty()) {
                buscarProducto(sku)
                if (editCantidad.text.toString().trim().isEmpty()) {
                    editCantidad.setText("1")
                }
            }
            false
        }
        imageViewProducto.setOnTouchListener { _, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    imageViewProducto.animate().scaleX(2.5f).scaleY(2.5f).setDuration(300).start()
                    true
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    imageViewProducto.animate().scaleX(1.0f).scaleY(1.0f).setDuration(300).start()
                    true
                }
                else -> false
            }
        }
    }

    private fun configurarValidaciones() {
        editCantidad.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                val texto = s.toString()
                if (texto.isNotEmpty() && !texto.all { it.isDigit() }) {
                    editCantidad.setText("")
                    editCantidad.setSelection(0)
                    Toast.makeText(this@PdaSurtidoTiendasActivity, "El campo cantidad solo acepta números", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun guardarDatos() {
        val sku = editSKU.text.toString().trim()
        val descripcion = editDescripcion.text.toString().trim()
        val cantidad = editCantidad.text.toString().trim()
        if (sku.isEmpty() || descripcion.isEmpty() || cantidad.isEmpty()) {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
            return
        }
        if (descripcion == "Producto no encontrado" || descripcion == "Error de conexión" || descripcion == "Sin descripción") {
            Toast.makeText(this, "No se puede guardar: Producto no encontrado en la base de datos", Toast.LENGTH_LONG).show()
            return
        }
        if (imageViewProducto.visibility == View.GONE) {
            Toast.makeText(this, "No se puede guardar: Producto no encontrado o sin imagen", Toast.LENGTH_LONG).show()
            return
        }

        // Mostrar diálogo de irregularidades
        mostrarDialogoIrregularidades(sku, descripcion, cantidad)
    }

    private fun mostrarDialogoIrregularidades(sku: String, descripcion: String, cantidad: String) {
        Log.d("SSIMCE", "Mostrando diálogo de irregularidades para SKU: $sku")
        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
        builder.setTitle("Verificación de Irregularidades")
        builder.setMessage("¿Hay alguna irregularidad con este producto?")
        builder.setPositiveButton("SÍ") { _, _ ->
            Log.d("SSIMCE", "Usuario seleccionó SÍ - Abriendo cámara para evidencia")
            abrirCamaraParaEvidencia(sku, descripcion, cantidad)
        }
        builder.setNegativeButton("NO") { _, _ ->
            Log.d("SSIMCE", "Usuario seleccionó NO - Guardando datos normales")
            guardarEntradaEnServidor(sku, descripcion, cantidad, "Surtido Tiendas")
        }
        builder.setNeutralButton("CANCELAR") { dialog, _ ->
            Log.d("SSIMCE", "Usuario canceló el diálogo")
            dialog.dismiss()
        }
        builder.show()
    }

    private fun guardarEntradaEnServidor(sku: String, descripcion: String, cantidad: String, tipoEntrada: String) {
        try {
            val datos = JSONObject().apply {
                put("sku", sku)
                put("descripcion", descripcion)
                put("cantidad", cantidad.toInt())
                put("tipo_entrada", tipoEntrada)
                put("observaciones", "Entrada registrada desde PDA Surtido Tiendas")
                put("usuario", "admin")
            }

            Log.d("SSIMCE", "Enviando datos al servidor: $datos")

            val url = "${SERVER_URL}guardar_entrada_surtido.php"
            val requestQueue = Volley.newRequestQueue(this)

            val jsonRequest = object : JsonObjectRequest(
                Request.Method.POST, url, datos,
                { response ->
                    try {
                        Log.d("SSIMCE", "Respuesta del servidor: $response")
                        val success = response.optBoolean("success", false)
                        if (success) {
                            val message = response.optString("message", "Entrada registrada exitosamente")
                            Log.d("SSIMCE", "Éxito: $message")
                            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                            limpiarFormulario()
                        } else {
                            val error = response.optString("error", "Error desconocido")
                            Log.e("SSIMCE", "Error del servidor: $error")
                            Toast.makeText(this, "Error: $error", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        Log.e("SSIMCE", "Error procesando respuesta: ${e.message}")
                        Toast.makeText(this, "Error procesando respuesta: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                },
                { error ->
                    Log.e("SSIMCE", "Error de red: ${error.toString()}")
                    Toast.makeText(this, "Error de red: ${error.toString()}", Toast.LENGTH_LONG).show()
                }
            ) {
                override fun getHeaders(): MutableMap<String, String> {
                    val headers = HashMap<String, String>()
                    headers["Content-Type"] = "application/json"
                    headers["api_key"] = API_KEY
                    return headers
                }
            }

            requestQueue.add(jsonRequest)

        } catch (e: Exception) {
            Log.e("SSIMCE", "Error preparando datos: ${e.message}")
            Toast.makeText(this, "Error preparando datos: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun limpiarFormulario() {
        editSKU.setText("")
        editDescripcion.setText("")
        editCantidad.setText("")
        imageViewProducto.setImageDrawable(null)
        imageViewProducto.visibility = View.GONE
        progressBarBusqueda.visibility = View.GONE
    }

    private fun configurarBusquedaAutomatica() {
        editSKU.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val sku = editSKU.text.toString().trim()
                if (sku.isNotEmpty()) {
                    buscarProducto(sku)
                }
            }
        }
    }

    private fun buscarProducto(sku: String) {
        progressBarBusqueda.visibility = View.VISIBLE
        imageViewProducto.visibility = View.GONE
        editDescripcion.setText("")

        val url = "http://192.168.1.65/ssimce/imagenes/imagenes_productos.php?sku=$sku"
        Log.d("SSIMCE", "Intentando conectar a: $url")
        val queue = Volley.newRequestQueue(this)

        val jsonObjectRequest = object : JsonObjectRequest(
            Request.Method.GET, url, null,
            { response ->
                Log.d("SSIMCE", "Respuesta completa del servidor: $response")
                progressBarBusqueda.visibility = View.GONE
                if (response.optBoolean("success", false)) {
                    val producto = response.getJSONObject("producto")
                    val descripcion = producto.optString("descripcion", "Sin descripción")
                    val imagenUrl = producto.optString("imagen_url", "")
                    Log.d("SSIMCE", "Descripción recibida: $descripcion")
                    Log.d("SSIMCE", "URL de imagen recibida: $imagenUrl")
                    editDescripcion.setText(descripcion)
                    if (imagenUrl.isNotEmpty()) {
                        Log.d("SSIMCE", "Intentando cargar imagen desde: $imagenUrl")
                        imageViewProducto.visibility = View.VISIBLE
                        Glide.with(this)
                            .load(imagenUrl)
                            .placeholder(R.drawable.ic_launcher_foreground)
                            .error(R.drawable.ic_launcher_foreground)
                            .listener(object : com.bumptech.glide.request.RequestListener<android.graphics.drawable.Drawable> {
                                override fun onLoadFailed(e: com.bumptech.glide.load.engine.GlideException?, model: Any?, target: com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable>, isFirstResource: Boolean): Boolean {
                                    Log.e("SSIMCE", "Error al cargar imagen: ${e?.message}")
                                    return false
                                }

                                override fun onResourceReady(resource: android.graphics.drawable.Drawable, model: Any, target: com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable>, dataSource: com.bumptech.glide.load.DataSource, isFirstResource: Boolean): Boolean {
                                    Log.d("SSIMCE", "Imagen cargada exitosamente")
                                    return false
                                }
                            })
                            .into(imageViewProducto)
                    } else {
                        Log.d("SSIMCE", "URL de imagen está vacía")
                        imageViewProducto.visibility = View.GONE
                    }
                } else {
                    editDescripcion.setText("Producto no encontrado")
                    imageViewProducto.visibility = View.GONE
                }
            },
            { error ->
                Log.e("SSIMCE", "Error en la petición: ${error.message}")
                progressBarBusqueda.visibility = View.GONE
                editDescripcion.setText("Error de conexión")
                imageViewProducto.visibility = View.GONE
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = "MI_API_KEY_SECRETA"
                return headers
            }
        }
        queue.add(jsonObjectRequest)
    }

    private fun abrirScanner() {
        val intent = Intent(this, BarcodeScannerActivity::class.java)
        intent.putExtra("TIPO_TABLA", "SURTIDO_TIENDAS")
        startActivityForResult(intent, REQUEST_CODE_SCANNER)
    }

    companion object {
        private const val REQUEST_CODE_SCANNER = 1001
        private const val REQUEST_CODE_CAMERA_EVIDENCIA = 1002
    }

    private var datosTemporales: Map<String, String> = emptyMap()

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.d("SSIMCE", "onActivityResult - requestCode: $requestCode, resultCode: $resultCode")
        
        if (requestCode == REQUEST_CODE_SCANNER && resultCode == RESULT_OK) {
            Log.d("SSIMCE", "Resultado del scanner recibido")
            data?.let { intent ->
                val scannedSku = intent.getStringExtra("SCANNED_SKU") ?: ""
                val scannedDescription = intent.getStringExtra("SCANNED_DESCRIPTION") ?: ""
                val scannedQuantity = intent.getStringExtra("SCANNED_QUANTITY") ?: "1"
                Log.d("SSIMCE", "Datos escaneados - SKU: $scannedSku, Descripción: $scannedDescription, Cantidad: $scannedQuantity")
                editSKU.setText(scannedSku)
                editDescripcion.setText(scannedDescription)
                if (scannedQuantity.isEmpty() || scannedQuantity == "0") {
                    editCantidad.setText("1")
                } else {
                    editCantidad.setText(scannedQuantity)
                }
                if (scannedSku.isNotEmpty()) {
                    buscarProducto(scannedSku)
                }
            }
        } else if (requestCode == REQUEST_CODE_CAMERA_EVIDENCIA && resultCode == RESULT_OK) {
            Log.d("SSIMCE", "Resultado de cámara para evidencia recibido")
            data?.let { intent ->
                val imagenEvidencia = intent.getParcelableExtra<android.graphics.Bitmap>("data")
                if (imagenEvidencia != null) {
                    Log.d("SSIMCE", "Imagen de evidencia capturada exitosamente: ${imagenEvidencia.width}x${imagenEvidencia.height}")
                    mostrarDialogoObservaciones(imagenEvidencia)
                } else {
                    Log.e("SSIMCE", "Error: imagenEvidencia es null")
                    Toast.makeText(this, "Error al capturar imagen", Toast.LENGTH_SHORT).show()
                }
            }
        } else if (requestCode == REQUEST_CODE_CAMERA_EVIDENCIA) {
            Log.d("SSIMCE", "Cámara cancelada o error - resultCode: $resultCode")
        }
    }

    private fun abrirCamaraParaEvidencia(sku: String, descripcion: String, cantidad: String) {
        Log.d("SSIMCE", "Abriendo cámara para evidencia - SKU: $sku, Descripción: $descripcion, Cantidad: $cantidad")
        val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, REQUEST_CODE_CAMERA_EVIDENCIA)
        datosTemporales = mapOf(
            "sku" to sku,
            "descripcion" to descripcion,
            "cantidad" to cantidad
        )
        Log.d("SSIMCE", "Datos temporales guardados: $datosTemporales")
    }

    private fun mostrarDialogoObservaciones(imagenEvidencia: android.graphics.Bitmap) {
        Log.d("SSIMCE", "Mostrando diálogo de observaciones - Imagen capturada: ${imagenEvidencia.width}x${imagenEvidencia.height}")
        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
        builder.setTitle("Observaciones de Irregularidad")
        builder.setMessage("Ingrese las observaciones sobre la irregularidad:")
        val input = EditText(this)
        input.hint = "Escriba las observaciones aquí..."
        input.setSingleLine(false)
        input.minLines = 3
        input.maxLines = 5
        builder.setView(input)
        builder.setPositiveButton("GUARDAR") { _, _ ->
            val observaciones = input.text.toString().trim()
            Log.d("SSIMCE", "Observaciones ingresadas: $observaciones")
            if (observaciones.isNotEmpty()) {
                val sku = datosTemporales["sku"] ?: ""
                val descripcion = datosTemporales["descripcion"] ?: ""
                val cantidad = datosTemporales["cantidad"] ?: ""
                Log.d("SSIMCE", "Datos para guardar irregularidad - SKU: $sku, Descripción: $descripcion, Cantidad: $cantidad")
                guardarIrregularidadLocal(sku, descripcion, cantidad, observaciones, imagenEvidencia)
            } else {
                Log.w("SSIMCE", "Usuario no ingresó observaciones")
                Toast.makeText(this, "Debe ingresar observaciones", Toast.LENGTH_SHORT).show()
            }
        }
        builder.setNegativeButton("CANCELAR") { dialog, _ ->
            Log.d("SSIMCE", "Usuario canceló el diálogo de observaciones")
            dialog.dismiss()
        }
        builder.show()
    }

    private fun guardarIrregularidadLocal(sku: String, descripcion: String, cantidad: String, observaciones: String, imagenEvidencia: android.graphics.Bitmap) {
        Log.d("SSIMCE", "Iniciando guardado de irregularidad: SKU=$sku, Descripción=$descripcion, Cantidad=$cantidad")
        
        // Convertir imagen a WebP
        val imagenWebP = convertirImagenAWebP(imagenEvidencia)
        if (imagenWebP == null) {
            Log.e("SSIMCE", "Error al convertir imagen a WebP")
            Toast.makeText(this, "Error al procesar la imagen", Toast.LENGTH_SHORT).show()
            return
        }
        
        Log.d("SSIMCE", "Imagen convertida exitosamente, tamaño: ${imagenWebP.size} bytes")
        
        lifecycleScope.launch {
            try {
                Log.d("SSIMCE", "Obteniendo instancia de base de datos...")
                val database = AppDatabase.getDatabase(this@PdaSurtidoTiendasActivity)
                
                Log.d("SSIMCE", "Obteniendo total de irregularidades...")
                val totalIrregularidades = database.irregularidadDao().obtenerTotalIrregularidades()
                Log.d("SSIMCE", "Total de irregularidades existentes: $totalIrregularidades")
                
                val siguienteConsecutivo = totalIrregularidades + 1
                val folioFormateado = String.format("IRR-%06d", siguienteConsecutivo)
                Log.d("SSIMCE", "Folio generado: $folioFormateado")
                
                val irregularidad = Irregularidad(
                    folio = folioFormateado,
                    sku = sku,
                    descripcion = descripcion,
                    cantidad = cantidad,
                    observaciones = observaciones,
                    imagenWebP = imagenWebP
                )
                
                Log.d("SSIMCE", "Objeto Irregularidad creado, insertando en base de datos...")
                database.irregularidadDao().insertarIrregularidad(irregularidad)
                
                Log.d("SSIMCE", "Irregularidad insertada exitosamente en la base de datos local")
                
                // Guardar también en la tabla entradas del servidor
                guardarEntradaEnServidor(sku, descripcion, cantidad, "Surtido Tiendas - Irregularidad")
                
                // Ahora enviar irregularidad al servidor
                enviarIrregularidadAlServidor(folioFormateado, sku, descripcion, cantidad, observaciones, imagenWebP)
                
            } catch (e: Exception) {
                Log.e("SSIMCE", "Error al guardar irregularidad en base de datos", e)
                
                // Si el error es de integridad de datos, limpiar la base de datos
                if (e.message?.contains("cannot verify the data integrity") == true) {
                    Log.d("SSIMCE", "Error de integridad detectado, limpiando base de datos...")
                    try {
                        AppDatabase.clearDatabase(this@PdaSurtidoTiendasActivity)
                        Log.d("SSIMCE", "Base de datos limpiada exitosamente")
                        
                        // Intentar guardar nuevamente
                        val database = AppDatabase.getDatabase(this@PdaSurtidoTiendasActivity)
                        val irregularidad = Irregularidad(
                            folio = "IRR-000001",
                            sku = sku,
                            descripcion = descripcion,
                            cantidad = cantidad,
                            observaciones = observaciones,
                            imagenWebP = imagenWebP
                        )
                        database.irregularidadDao().insertarIrregularidad(irregularidad)
                        
                        // Guardar también en la tabla entradas del servidor
                        guardarEntradaEnServidor(sku, descripcion, cantidad, "Surtido Tiendas - Irregularidad")
                        
                        // Enviar al servidor
                        enviarIrregularidadAlServidor("IRR-000001", sku, descripcion, cantidad, observaciones, imagenWebP)
                        
                    } catch (e2: Exception) {
                        Log.e("SSIMCE", "Error al intentar guardar después de limpiar BD", e2)
                        runOnUiThread {
                            Toast.makeText(this@PdaSurtidoTiendasActivity, "Error crítico: ${e2.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                } else {
                    runOnUiThread {
                        Toast.makeText(this@PdaSurtidoTiendasActivity, "Error al guardar irregularidad: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun enviarIrregularidadAlServidor(folio: String, sku: String, descripcion: String, cantidad: String, observaciones: String, imagenWebP: ByteArray) {
        try {
            // Convertir imagen a Base64 para enviar por JSON
            val imagenBase64 = android.util.Base64.encodeToString(imagenWebP, android.util.Base64.DEFAULT)
            
            val datos = JSONObject().apply {
                put("folio", folio)
                put("sku", sku)
                put("descripcion", descripcion)
                put("cantidad", cantidad)
                put("observaciones", observaciones)
                put("imagen_webp", imagenBase64)
                put("usuario", "admin")
            }

            Log.d("SSIMCE", "Enviando irregularidad al servidor: $folio")

            val url = "${SERVER_URL}sincronizar_irregularidades.php"
            val requestQueue = Volley.newRequestQueue(this)

            val jsonRequest = object : JsonObjectRequest(
                Request.Method.POST, url, datos,
                { response ->
                    try {
                        Log.d("SSIMCE", "Respuesta del servidor para irregularidad: $response")
                        val success = response.optBoolean("success", false)
                        if (success) {
                            val message = response.optString("message", "Irregularidad sincronizada exitosamente")
                            Log.d("SSIMCE", "Éxito: $message")
                            runOnUiThread {
                                // Irregularidad guardada localmente y en servidor: $folio
                                limpiarFormulario()
                            }
                        } else {
                            val error = response.optString("error", "Error desconocido")
                            Log.e("SSIMCE", "Error del servidor para irregularidad: $error")
                            runOnUiThread {
                                // Irregularidad guardada localmente, error en servidor: $error
                                limpiarFormulario()
                            }
                        }
                    } catch (e: Exception) {
                        Log.e("SSIMCE", "Error procesando respuesta de irregularidad: ${e.message}")
                        runOnUiThread {
                            // Irregularidad guardada localmente, error procesando respuesta
                            limpiarFormulario()
                        }
                    }
                },
                { error ->
                    Log.e("SSIMCE", "Error de red para irregularidad: ${error.toString()}")
                    runOnUiThread {
                        // Irregularidad guardada localmente, error de red
                        limpiarFormulario()
                    }
                }
            ) {
                override fun getHeaders(): MutableMap<String, String> {
                    val headers = HashMap<String, String>()
                    headers["Content-Type"] = "application/json"
                    headers["api_key"] = API_KEY
                    return headers
                }
            }

            requestQueue.add(jsonRequest)

        } catch (e: Exception) {
            Log.e("SSIMCE", "Error preparando datos de irregularidad: ${e.message}")
            runOnUiThread {
                // Irregularidad guardada localmente, error preparando datos
                limpiarFormulario()
            }
        }
    }

    private fun convertirImagenAWebP(bitmap: android.graphics.Bitmap): ByteArray? {
        return try {
            val outputStream = java.io.ByteArrayOutputStream()
            bitmap.compress(android.graphics.Bitmap.CompressFormat.WEBP, 85, outputStream)
            outputStream.toByteArray()
        } catch (e: Exception) {
            null
        }
    }
} 