package com.example.ssimce

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ssimce.data.local.AppDatabase
import com.example.ssimce.data.local.Irregularidad
import com.example.ssimce.R
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope
import java.text.SimpleDateFormat
import java.util.*
import android.util.Log
import android.widget.Toast

class IrregularidadesActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: IrregularidadesAdapter
    private var irregularidades = mutableListOf<Irregularidad>()
    private var irregularidadesOriginales = mutableListOf<Irregularidad>()
    private lateinit var editTextBuscarFolio: android.widget.EditText
    private lateinit var btnBuscar: android.widget.ImageView
    private lateinit var textViewNoIrregularidades: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_irregularidades)

        inicializarVistas()
        configurarRecyclerView()
        configurarBusqueda()
        configurarBotones()
        cargarIrregularidades()
    }

    private fun inicializarVistas() {
        recyclerView = findViewById(R.id.recyclerViewIrregularidades)
        editTextBuscarFolio = findViewById(R.id.editTextBuscarFolio)
        btnBuscar = findViewById(R.id.btnBuscar)
        textViewNoIrregularidades = findViewById(R.id.textViewNoIrregularidades)
    }

    private fun configurarRecyclerView() {
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = IrregularidadesAdapter(irregularidades) { irregularidad ->
            mostrarDetallesIrregularidad(irregularidad)
        }
        recyclerView.adapter = adapter
    }

    private fun configurarBusqueda() {
        // Configurar botón buscar
        btnBuscar.setOnClickListener {
            buscarPorFolio()
        }
        
        // Configurar búsqueda al presionar Enter
        editTextBuscarFolio.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) {
                buscarPorFolio()
                return@setOnEditorActionListener true
            }
            false
        }
        
        // Configurar búsqueda automática al escribir
        editTextBuscarFolio.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                val texto = s.toString()
                
                // Si el campo está vacío, mostrar todas las irregularidades
                if (texto.trim().isEmpty()) {
                    mostrarTodasLasIrregularidades()
                    return
                }
                
                // Asegurar que siempre empiece con "IRR-"
                if (!texto.startsWith("IRR-")) {
                    val nuevoTexto = "IRR-$texto"
                    editTextBuscarFolio.setText(nuevoTexto)
                    editTextBuscarFolio.setSelection(nuevoTexto.length)
                }
            }
        })
    }

    private fun configurarBotones() {
        // Configurar botón regresar
        val btnRegresar = findViewById<android.widget.Button>(R.id.btnRegresar)
        btnRegresar.setOnClickListener {
            val intent = Intent(this, com.example.ssimce.inicio.MainActivityMenuPrincipal::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            finish()
        }
    }

    private fun cargarIrregularidades() {
        lifecycleScope.launch {
            try {
                val database = AppDatabase.getDatabase(this@IrregularidadesActivity)
                val irregularidadesList = database.irregularidadDao().obtenerTodasLasIrregularidades()
                
                irregularidades.clear()
                irregularidades.addAll(irregularidadesList)
                irregularidadesOriginales.clear()
                irregularidadesOriginales.addAll(irregularidadesList)
                
                runOnUiThread {
                    adapter.notifyDataSetChanged()
                    actualizarVisibilidad()
                }
                
            } catch (e: Exception) {
                Log.e("SSIMCE", "Error al cargar irregularidades", e)
                runOnUiThread {
                    Toast.makeText(this@IrregularidadesActivity, "Error al cargar irregularidades", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun actualizarVisibilidad() {
        if (irregularidades.isEmpty()) {
            textViewNoIrregularidades.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
        } else {
            textViewNoIrregularidades.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
        }
    }

    private fun mostrarTodasLasIrregularidades() {
        irregularidades.clear()
        irregularidades.addAll(irregularidadesOriginales)
        adapter.notifyDataSetChanged()
        actualizarVisibilidad()
    }

    private fun buscarPorFolio() {
        val folioBuscar = editTextBuscarFolio.text.toString().trim()
        
        if (folioBuscar.isEmpty()) {
            mostrarTodasLasIrregularidades()
            return
        }
        
        // Si no empieza con IRR-, agregarlo
        val folioParaBuscar = if (!folioBuscar.startsWith("IRR-")) {
            "IRR-$folioBuscar"
        } else {
            folioBuscar
        }
        
        // Filtrar por folio
        val irregularidadesFiltradas = irregularidadesOriginales.filter { 
            it.folio.contains(folioParaBuscar, ignoreCase = true) 
        }
        
        irregularidades.clear()
        irregularidades.addAll(irregularidadesFiltradas)
        adapter.notifyDataSetChanged()
        actualizarVisibilidad()
        
        if (irregularidadesFiltradas.isEmpty()) {
            Toast.makeText(this, "No se encontró el folio: $folioParaBuscar", Toast.LENGTH_SHORT).show()
        }
    }

    private fun mostrarDetallesIrregularidad(irregularidad: Irregularidad) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Detalles de Irregularidad")
        
        val fecha = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())
            .format(Date(irregularidad.fechaCreacion))
        
        val mensaje = """
            Folio: ${irregularidad.folio}
            SKU: ${irregularidad.sku}
            Descripción: ${irregularidad.descripcion}
            Cantidad: ${irregularidad.cantidad}
            Observaciones: ${irregularidad.observaciones}
            Fecha: $fecha
        """.trimIndent()
        
        builder.setMessage(mensaje)
        builder.setPositiveButton("IMPRIMIR") { _, _ ->
            imprimirIrregularidad(irregularidad)
        }
        builder.setNegativeButton("CERRAR") { dialog, _ ->
            dialog.dismiss()
        }
        builder.show()
    }

    private fun imprimirIrregularidad(irregularidad: Irregularidad) {
        // TODO: Implementar impresión real
        Toast.makeText(this, "Imprimiendo irregularidad: ${irregularidad.folio}", Toast.LENGTH_SHORT).show()
    }

    class IrregularidadesAdapter(
        private val irregularidades: List<Irregularidad>,
        private val onItemClick: (Irregularidad) -> Unit
    ) : RecyclerView.Adapter<IrregularidadesAdapter.ViewHolder>() {

        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val textViewFolio: TextView = view.findViewById(R.id.textViewFolio)
            val textViewSKU: TextView = view.findViewById(R.id.textViewSKU)
            val textViewFecha: TextView = view.findViewById(R.id.textViewFecha)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_irregularidad, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val irregularidad = irregularidades[position]
            holder.textViewFolio.text = irregularidad.folio
            holder.textViewSKU.text = irregularidad.sku
            
            val fecha = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                .format(Date(irregularidad.fechaCreacion))
            holder.textViewFecha.text = fecha
            
            holder.itemView.setOnClickListener {
                onItemClick(irregularidad)
            }
        }

        override fun getItemCount() = irregularidades.size
    }
} 