package com.example.ssimce.entradas.guia

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ssimce.databinding.ActivityMainMostrarDatosGuiaBinding
import org.json.JSONObject
import org.json.JSONArray
import com.android.volley.toolbox.Volley
import com.android.volley.toolbox.JsonObjectRequest
import com.example.ssimce.entradas.bitacora.MainActivityEscaneoBitacora
import java.util.UUID

class MainActivityMostrarDatosGuia : AppCompatActivity() {

    private lateinit var binding: ActivityMainMostrarDatosGuiaBinding
    private val SERVER_URL = "http://192.168.1.65/ssimce/"
    private val API_KEY = "MI_API_KEY_SECRETA"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainMostrarDatosGuiaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mostrarDatos()

        binding.btnOK.setOnClickListener {
            enviarDatosGuia()
        }
    }

    private fun mostrarDatos() {
        val extras = intent.extras

        binding.tvBitacora.text = extras?.getString("bitacora") ?: ""
        binding.tvFecha.text = extras?.getString("fecha") ?: ""
        binding.tvOrigen.text = extras?.getString("origen") ?: ""
        binding.tvDestino.text = extras?.getString("destino") ?: ""
        binding.tvEmpleado.text = extras?.getString("empleado") ?: ""
        binding.tvChofer.text = extras?.getString("chofer") ?: ""
        binding.tvCamion.text = extras?.getString("camion") ?: ""
        binding.tvCaja1.text = extras?.getString("caja1") ?: ""
        binding.tvCaja2.text = extras?.getString("caja2") ?: ""
        binding.tvSello.text = extras?.getString("sello") ?: ""
        binding.tvSelloRepuesto.text = extras?.getString("selloRepuesto") ?: ""
    }

    private fun enviarDatosGuia() {
        try {
            // Crear estructura de datos para la nueva tabla guias
            val datosGuia = JSONObject().apply {
                put("folio", generarFolioGuia())
                put("fecha", binding.tvFecha.text.toString())
                put("tipo_documento", "Guía de Transporte")
                put("observaciones", crearObservaciones())
                put("usuario", "admin")
                put("lineas", crearLineasGuia())
            }

            Log.d("Guia", "Datos a enviar: $datosGuia")

            enviarDatosAlServidor(
                this,
                datosGuia,
                onSuccess = {
                    Toast.makeText(this, "Guía registrada exitosamente", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, MainActivityEscaneoBitacora::class.java)
                    startActivity(intent)
                    finish()
                },
                onError = { mensaje ->
                    Toast.makeText(this, "Error: $mensaje", Toast.LENGTH_LONG).show()
                }
            )

        } catch (e: Exception) {
            Log.e("Guia", "Error preparando datos: ${e.message}")
            Toast.makeText(this, "Error preparando datos: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun generarFolioGuia(): String {
        val timestamp = System.currentTimeMillis()
        return "GUI-${timestamp}"
    }

    private fun crearObservaciones(): String {
        val observaciones = StringBuilder()
        
        if (binding.tvBitacora.text.isNotEmpty()) {
            observaciones.append("Bitácora: ${binding.tvBitacora.text}. ")
        }
        if (binding.tvCamion.text.isNotEmpty()) {
            observaciones.append("Camión: ${binding.tvCamion.text}. ")
        }
        if (binding.tvChofer.text.isNotEmpty()) {
            observaciones.append("Chofer: ${binding.tvChofer.text}. ")
        }
        if (binding.tvOrigen.text.isNotEmpty()) {
            observaciones.append("Origen: ${binding.tvOrigen.text}. ")
        }
        if (binding.tvDestino.text.isNotEmpty()) {
            observaciones.append("Destino: ${binding.tvDestino.text}. ")
        }
        if (binding.tvCaja1.text.isNotEmpty()) {
            observaciones.append("Caja1: ${binding.tvCaja1.text}. ")
        }
        if (binding.tvCaja2.text.isNotEmpty()) {
            observaciones.append("Caja2: ${binding.tvCaja2.text}. ")
        }
        if (binding.tvSello.text.isNotEmpty()) {
            observaciones.append("Sello: ${binding.tvSello.text}. ")
        }
        if (binding.tvSelloRepuesto.text.isNotEmpty()) {
            observaciones.append("Sello Repuesto: ${binding.tvSelloRepuesto.text}. ")
        }

        return observaciones.toString().trim()
    }

    private fun crearLineasGuia(): JSONArray {
        val lineas = JSONArray()
        
        // Crear una línea por defecto con los datos principales
        val linea = JSONObject().apply {
            put("sku", "GUI-${System.currentTimeMillis()}")
            put("descripcion", "Guía de transporte - ${binding.tvOrigen.text} a ${binding.tvDestino.text}")
            put("cantidad", 1.0)
            put("tipo", "ENTRADA")
            put("observaciones", "Registro de guía de transporte")
        }
        
        lineas.put(linea)
        
        return lineas
    }

    private fun enviarDatosAlServidor(
        context: Context,
        datos: JSONObject,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val url = "${SERVER_URL}insertar_datos_guia.php"
        val requestQueue = Volley.newRequestQueue(context)

        val jsonRequest = object : JsonObjectRequest(
            Method.POST, url, datos,
            { response ->
                try {
                    Log.d("Guia", "Respuesta del servidor: $response")
                    val success = response.optBoolean("success", false)
                    if (success) {
                        val message = response.optString("message", "Guía registrada exitosamente")
                        Log.d("Guia", "Éxito: $message")
                        onSuccess()
                    } else {
                        val error = response.optString("error", "Error desconocido")
                        Log.e("Guia", "Error del servidor: $error")
                        onError(error)
                    }
                } catch (e: Exception) {
                    Log.e("Guia", "Error procesando respuesta: ${e.message}")
                    onError("Error procesando respuesta: ${e.message}")
                }
            },
            { error ->
                Log.e("Guia", "Error de red: ${error.toString()}")
                onError("Error de red: ${error.toString()}")
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Content-Type"] = "application/json"
                headers["api_key"] = API_KEY
                return headers
            }
        }

        requestQueue.add(jsonRequest)
    }
}