package com.example.ssimce.entradas.bitacora

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.ssimce.R
import com.example.ssimce.databinding.ActivityMainMostrarDatosBitacoraBinding
import com.example.ssimce.entradas.entradas.MainActivityEntradas
import org.json.JSONObject
import java.util.UUID
import java.text.SimpleDateFormat
import java.util.Locale

@Suppress("CAST_NEVER_SUCCEEDS")
class MainActivityMostrarDatosBitacora : AppCompatActivity() {

    private lateinit var binding: ActivityMainMostrarDatosBitacoraBinding
    private val lineasBitacora = mutableListOf<LineaBitacora>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainMostrarDatosBitacoraBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Procesar las líneas recibidas
        procesarLineasRecibidas()

        // Mostrar datos básicos
        mostrarDatosBasicos()

        // Crear tabla dinámica
        crearTablaDatos()

        binding.btnOK.setOnClickListener {
            enviarDatosAlServidor()
        }
    }

    private fun procesarLineasRecibidas() {
        val lineasSerializadas = intent.getStringExtra("lineas_serializadas") ?: ""

        android.util.Log.d("BitacoraMostrar", "Líneas serializadas recibidas: $lineasSerializadas")

        if (lineasSerializadas.isNotEmpty()) {
            val lineas = lineasSerializadas.split("|")
            for (linea in lineas) {
                val partes = linea.split(":")
                if (partes.size == 3) {
                    val tipo = partes[0].trim()
                    val folio = partes[1].trim()
                    val destino = partes[2].trim()
                    lineasBitacora.add(LineaBitacora(tipo, folio, destino))
                    android.util.Log.d("BitacoraMostrar", "Agregada línea: Tipo=$tipo, Folio=$folio, Destino=$destino")
                }
            }
        }

        android.util.Log.d("BitacoraMostrar", "Total de líneas procesadas: ${lineasBitacora.size}")
    }

    private fun mostrarDatosBasicos() {
        val extras = intent.extras

        binding.tvBitacora.setText(extras?.getString("bitacora") ?: "")
        binding.tvFecha.setText(extras?.getString("fecha") ?: "")
        binding.tvCaja.setText(extras?.getString("caja") ?: "")
        binding.tvSello.setText(extras?.getString("sello") ?: "")
        binding.tvrepuestoDeSello.setText(extras?.getString("repuesto_sello") ?: "")
    }

    private fun crearTablaDatos() {
        val tablaDatos = binding.tablaDatos

        // Limpiar tabla existente
        tablaDatos.removeAllViews()

        // Crear filas para cada línea de bitácora
        for (linea in lineasBitacora) {
            val rowView = LayoutInflater.from(this).inflate(R.layout.table_row_mostrar_bitacora, tablaDatos, false)

            val textTipo = rowView.findViewById<TextView>(R.id.textTipo)
            val textFolio = rowView.findViewById<TextView>(R.id.textFolio)
            val textDestino = rowView.findViewById<TextView>(R.id.textDestino)

            textTipo.text = linea.tipo
            textFolio.text = linea.folio
            textDestino.text = linea.destino

            tablaDatos.addView(rowView)
        }
    }

    private fun formatearFecha(fecha: String): String {
        return try {
            // Si la fecha está vacía, devolver cadena vacía
            if (fecha.trim().isEmpty()) {
                android.util.Log.d("BitacoraMostrar", "Fecha vacía detectada")
                return ""
            }
            
            val fechaOriginal = fecha.trim()
            android.util.Log.d("BitacoraMostrar", "Procesando fecha: '$fechaOriginal'")
            
            // Mapeo de meses completos en español
            val mesesCompletos = mapOf(
                "Enero" to "01", "Febrero" to "02", "Marzo" to "03", "Abril" to "04",
                "Mayo" to "05", "Junio" to "06", "Julio" to "07", "Agosto" to "08",
                "Septiembre" to "09", "Octubre" to "10", "Noviembre" to "11", "Diciembre" to "12"
            )
            
            // Mapeo de meses abreviados en español
            val mesesAbreviados = mapOf(
                "Ene" to "01", "Feb" to "02", "Mar" to "03", "Abr" to "04",
                "May" to "05", "Jun" to "06", "Jul" to "07", "Ago" to "08",
                "Sep" to "09", "Oct" to "10", "Nov" to "11", "Dic" to "12"
            )
            
            // Intentar con formato dd/mes_completo/yyyy primero
            val regexCompleto = Regex("""(\d{1,2})/([A-Za-z]+)/(\d{4})""")
            val matchCompleto = regexCompleto.find(fechaOriginal)
            
            if (matchCompleto != null) {
                val dia = matchCompleto.groupValues[1].padStart(2, '0')
                val mesTexto = matchCompleto.groupValues[2]
                val año = matchCompleto.groupValues[3]
                
                // Buscar en meses completos primero
                var mesNumero = mesesCompletos[mesTexto]
                if (mesNumero == null) {
                    // Si no está en completos, buscar en abreviados
                    mesNumero = mesesAbreviados[mesTexto]
                }
                
                if (mesNumero != null) {
                    val fechaFormateada = "$año-$mesNumero-$dia"
                    android.util.Log.d("BitacoraMostrar", "Fecha convertida con regex: '$fechaOriginal' -> '$fechaFormateada'")
                    return fechaFormateada
                } else {
                    android.util.Log.e("BitacoraMostrar", "Mes no reconocido: '$mesTexto' en fecha '$fechaOriginal'")
                }
            }
            
            // Si no funcionó el regex, intentar con SimpleDateFormat
            val formatos = listOf(
                "dd/MMMM/yyyy", // 28/Julio/2025
                "dd/MMM/yyyy",  // 28/Jul/2025
                "dd/MM/yyyy",   // 28/07/2025
                "dd-MM-yyyy",   // 28-07-2025
                "yyyy-MM-dd",   // 2025-07-28
                "MM/dd/yyyy",   // 07/28/2025
                "dd.MM.yyyy"    // 28.07.2025
            )
            
            for (formato in formatos) {
                try {
                    val parser = SimpleDateFormat(formato, Locale("es", "ES"))
                    val fechaDate = parser.parse(fechaOriginal)
                    if (fechaDate != null) {
                        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                        val fechaFormateada = formatter.format(fechaDate)
                        android.util.Log.d("BitacoraMostrar", "Fecha convertida exitosamente: '$fechaOriginal' -> '$fechaFormateada' usando formato '$formato'")
                        return fechaFormateada
                    }
                } catch (e: Exception) {
                    android.util.Log.d("BitacoraMostrar", "Formato '$formato' falló para fecha '$fechaOriginal': ${e.message}")
                    // Continuar con el siguiente formato
                }
            }
            
            // Si no se pudo parsear, devolver la fecha original y log de error
            android.util.Log.e("BitacoraMostrar", "No se pudo convertir fecha: '$fechaOriginal'")
            fechaOriginal
        } catch (e: Exception) {
            android.util.Log.e("BitacoraMostrar", "Error general formateando fecha: '$fecha'", e)
            fecha.trim()
        }
    }

    private fun enviarDatosAlServidor() {
        val fechaFormateada = formatearFecha(binding.tvFecha.text.toString())
        
        val datos = mapOf(
            "id" to UUID.randomUUID().toString(),
            "Bitacora" to binding.tvBitacora.text.toString(),
            "Fecha" to fechaFormateada,
            "Caja" to binding.tvCaja.text.toString(),
            "Sello" to binding.tvSello.text.toString(),
            "Repuesto_De_Sello" to binding.tvrepuestoDeSello.text.toString(),
            "lineas_serializadas" to lineasBitacora.joinToString("|") { "${it.tipo}:${it.folio}:${it.destino}" }
        )

        android.util.Log.d("BitacoraMostrar", "Fecha original: ${binding.tvFecha.text}")
        android.util.Log.d("BitacoraMostrar", "Fecha formateada: $fechaFormateada")

        enviarDatosAlServidor(
            this, datos,
            onSuccess = {
                Toast.makeText(this, "Datos subidos correctamente", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, MainActivityEntradas::class.java)
                startActivity(intent)
                finish()
            },
            onError = { mensaje ->
                Toast.makeText(this, "Error: $mensaje", Toast.LENGTH_LONG).show()
            }
        )
    }

    private fun enviarDatosAlServidor(
        context: Context,
        datos: Map<String, String>,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val url = "http://192.168.1.65/ssimce/insertar_datos_bitacora.php"
        val requestQueue = Volley.newRequestQueue(context)

        val jsonRequest = object : JsonObjectRequest(
            Method.POST, url, JSONObject(datos),
            { response ->
                val success = response.optBoolean("success", false)
                if (success) {
                    onSuccess()
                } else {
                    val mensaje = response.optString("message", "Error desconocido")
                    onError(mensaje)
                }
            },
            { error ->
                onError(error.toString())
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Content-Type"] = "application/json"
                headers["api_key"] = "MI_API_KEY_SECRETA"
                return headers
            }
        }

        requestQueue.add(jsonRequest)
    }
}