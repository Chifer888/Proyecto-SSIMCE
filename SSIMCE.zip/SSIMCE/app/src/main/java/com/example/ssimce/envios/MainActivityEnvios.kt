package com.example.ssimce.envios

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import android.view.ViewGroup
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.ssimce.R
import com.example.ssimce.data.local.AppDatabase
import com.example.ssimce.data.local.Producto
import com.example.ssimce.data.local.MRBRegistro
import com.example.ssimce.data.local.CTRegistro
import com.google.gson.Gson
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.appcompat.app.AlertDialog
import org.json.JSONObject
import com.android.volley.toolbox.Volley
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.Request
import android.util.Log

class MainActivityEnvios : AppCompatActivity() {

    private val SERVER_URL = "http://192.168.1.65/ssimce/datos_envios/datos_envios.php"
    private val API_KEY = "MI_API_KEY_SECRETA"

    private lateinit var imageUri: Uri
    private lateinit var videoUri: Uri
    private var evidenciaCapturada = false
    private var tipoRegistroActual = "" // "MRB" o "CT"
    private var evidenciaUri = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_envios)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val radioBtnMRB = findViewById<RadioButton>(R.id.radioBtnMRB)
        val radioBtnCT = findViewById<RadioButton>(R.id.radioBtnCT)
        val tableMRB = findViewById<View>(R.id.tableMRB)
        val layoutCTFields = findViewById<View>(R.id.layoutCTFields)
        val spinnerCausaMRB = findViewById<Spinner>(R.id.spinnerCausaMRB)
        val edtSKUMRB = findViewById<EditText>(R.id.edtSKUMRB)
        val txtDescripcionSKU = findViewById<TextView>(R.id.txtDescripcionSKU)
        val edtCantidadMRB = findViewById<EditText>(R.id.edtCantidadMRB)
        val edtMRB = findViewById<EditText>(R.id.edtMRB)
        val txtFechaMRB = findViewById<TextView>(R.id.txtFechaMRB)
        val txtFechaCT = findViewById<TextView>(R.id.txtFechaCT)
        val edtCT = findViewById<EditText>(R.id.edtCT)
        val edtTienda = findViewById<EditText>(R.id.edtTienda)
        val edtFolioTS = findViewById<EditText>(R.id.edtFolioTS)
        val edtSKUCT = findViewById<EditText>(R.id.edtSKUCT)
        val txtDescripcionCT = findViewById<TextView>(R.id.txtDescripcionCT)
        val spinnerMotivo = findViewById<Spinner>(R.id.spinnerMotivo)
        val edtCantidadCT = findViewById<EditText>(R.id.edtCantidadCT)
        val edtObservacionesCT = findViewById<EditText>(R.id.edtObservacionesCT)
        val btnGuardarMRB = findViewById<Button>(R.id.btnGuardarMRB)
        val btnGuardarCT = findViewById<Button>(R.id.btnGuardarCT)
        val layoutBotonesMRB = findViewById<LinearLayout>(R.id.layoutBotonesMRB)
        val layoutBotonesCT = findViewById<LinearLayout>(R.id.layoutBotonesCT)
        val btnCapturarEvidenciaMRB = findViewById<Button>(R.id.btnCapturarEvidenciaMRB)
        val btnCapturarEvidenciaCT = findViewById<Button>(R.id.btnCapturarEvidenciaCT)
        val edtFacturaMRB = findViewById<EditText>(R.id.edtFacturaMRB)

        // Establecer fecha actual para ambos layouts
        val fechaActual = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
        txtFechaMRB.text = fechaActual
        txtFechaCT.text = fechaActual

        // Configurar radio buttons
        radioBtnMRB.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                radioBtnCT.isChecked = false
                tableMRB.visibility = View.VISIBLE
                layoutCTFields.visibility = View.GONE
                layoutBotonesMRB.visibility = View.VISIBLE
                layoutBotonesCT.visibility = View.GONE
            } else {
                tableMRB.visibility = View.GONE
                layoutBotonesMRB.visibility = View.GONE
            }
        }
        radioBtnCT.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                radioBtnMRB.isChecked = false
                tableMRB.visibility = View.GONE
                layoutCTFields.visibility = View.VISIBLE
                layoutBotonesMRB.visibility = View.GONE
                layoutBotonesCT.visibility = View.VISIBLE
            } else {
                layoutCTFields.visibility = View.GONE
                layoutBotonesCT.visibility = View.GONE
            }
        }

        // Configurar navegación entre campos MRB y CT
        configurarNavegacionCamposMRB()
        configurarNavegacionCamposCT()

        // MRB: Buscar descripción online al presionar Enter
        edtSKUMRB.setOnEditorActionListener { _, _, _ ->
            val sku = edtSKUMRB.text.toString().trim()
            if (sku.isNotEmpty()) {
                buscarProductoOnline(sku, txtDescripcionSKU)
            }
            edtFacturaMRB.requestFocus()
            true
        }
        // MRB: Buscar descripción online en tiempo real
        edtSKUMRB.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                val sku = s.toString().trim()
                if (sku.isNotEmpty() && sku.length >= 3) {
                    buscarProductoOnline(sku, txtDescripcionSKU)
                } else if (sku.isEmpty()) {
                    txtDescripcionSKU.text = "Descripción"
                }
            }
        })
        // CT: Buscar descripción online al presionar Enter y navegar al siguiente campo
        edtSKUCT.setOnEditorActionListener { _, _, _ ->
            val sku = edtSKUCT.text.toString().trim()
            if (sku.isNotEmpty()) {
                buscarProductoOnline(sku, txtDescripcionCT)
            }
            // Navegar al siguiente campo (Spinner de Motivo)
            findViewById<Spinner>(R.id.spinnerMotivo).requestFocus()
            true
        }
        // CT: Buscar descripción online en tiempo real
        edtSKUCT.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                val sku = s.toString().trim()
                if (sku.isNotEmpty() && sku.length >= 3) {
                    buscarProductoOnline(sku, txtDescripcionCT)
                } else if (sku.isEmpty()) {
                    txtDescripcionCT.text = "Descripción"
                }
            }
        })

        // Cantidad por defecto en 1 para ambos layouts
        edtCantidadMRB.setText("1")
        edtCantidadCT.setText("1")

        btnCapturarEvidenciaMRB.setOnClickListener {
            mostrarDialogoTipoEvidencia(true) // true para MRB
        }

        btnCapturarEvidenciaCT.setOnClickListener {
            mostrarDialogoTipoEvidencia(false) // false para CT
        }

        // Botón Guardar MRB
        btnGuardarMRB.setOnClickListener {
            if (validarCamposMRB()) {
            guardarMRBRegistro()
            } else {
                Toast.makeText(this, "Por favor complete todos los campos obligatorios", Toast.LENGTH_LONG).show()
            }
        }

        // Botón Guardar CT
        btnGuardarCT.setOnClickListener {
            if (validarCamposCT()) {
            guardarCTRegistro()
            } else {
                Toast.makeText(this, "Por favor complete todos los campos obligatorios", Toast.LENGTH_LONG).show()
            }
        }

        val btnHome = findViewById<Button>(R.id.btnHome)
        btnHome.setOnClickListener {
            val intent = Intent(this, com.example.ssimce.inicio.MainActivityMenuPrincipal::class.java)
            startActivity(intent)
            finishAffinity()
        }

        // Configurar Spinners
        configurarSpinnerMotivo(spinnerMotivo)
        configurarSpinnerCausaMRB(spinnerCausaMRB)

        // Los productos se cargan desde la base de datos MySQL del servidor
    sincronizarProductosDesdeServidor()
    }

    private fun configurarNavegacionCamposMRB() {
        val edtMRB = findViewById<EditText>(R.id.edtMRB)
        val edtJaulaMRB = findViewById<EditText>(R.id.edtJaulaMRB)
        val spinnerCausaMRB = findViewById<Spinner>(R.id.spinnerCausaMRB)
        val edtSKUMRB = findViewById<EditText>(R.id.edtSKUMRB)
        val edtFacturaMRB = findViewById<EditText>(R.id.edtFacturaMRB)
        val edtCantidadMRB = findViewById<EditText>(R.id.edtCantidadMRB)
        val txtDescripcionSKU = findViewById<TextView>(R.id.txtDescripcionSKU)

        // MRB -> Jaula
        edtMRB.setOnEditorActionListener { _, _, _ ->
            edtJaulaMRB.requestFocus()
            true
        }

        // Jaula -> Causa (Spinner)
        edtJaulaMRB.setOnEditorActionListener { _, _, _ ->
            spinnerCausaMRB.requestFocus()
            true
        }

        // SKU -> Factura (con búsqueda automática)
        edtSKUMRB.setOnEditorActionListener { _, _, _ ->
            val sku = edtSKUMRB.text.toString().trim()
            if (sku.isNotEmpty()) {
                buscarProductoOnline(sku, txtDescripcionSKU)
            }
            edtFacturaMRB.requestFocus()
            true
        }

        // Factura -> Cantidad
        edtFacturaMRB.setOnEditorActionListener { _, _, _ ->
            edtCantidadMRB.requestFocus()
            true
        }

        // Cantidad -> Observaciones
        edtCantidadMRB.setOnEditorActionListener { _, _, _ ->
            findViewById<EditText>(R.id.edtObservacionesMRB).requestFocus()
            true
        }
    }

    private fun buscarProductoEnBaseDeDatos(sku: String, textViewDescripcion: TextView) {
        lifecycleScope.launch {
            try {
                val database = AppDatabase.getDatabase(this@MainActivityEnvios)
                
                // Buscar por código (que es el SKU en la tabla productos)
                val producto = database.productoDao().buscarPorCodigo(sku)
                
                runOnUiThread {
                    if (producto != null) {
                        textViewDescripcion.text = producto.descripcion
                        // Producto encontrado silenciosamente
                } else {
                        textViewDescripcion.text = "Producto no encontrado"
                        // SKU no encontrado silenciosamente
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    textViewDescripcion.text = "Error al buscar producto"
                    // Error al buscar producto silenciosamente
                }
            }
        }
    }

    // Busca la descripción del producto en línea usando Volley (igual que PdaEntregasClientesActivity)
    private fun buscarProductoOnline(sku: String, textViewDescripcion: TextView) {
        val url = "http://192.168.1.65/ssimce/imagenes/imagenes_productos.php?sku=$sku"
        val queue = com.android.volley.toolbox.Volley.newRequestQueue(this)
        val request = object : com.android.volley.toolbox.JsonObjectRequest(
            com.android.volley.Request.Method.GET, url, null,
            { response ->
                if (response.optBoolean("success", false)) {
                    val producto = response.getJSONObject("producto")
                    val descripcion = producto.optString("descripcion", "Sin descripción")
                    textViewDescripcion.text = descripcion
                } else {
                    textViewDescripcion.text = "Producto no encontrado"
                }
            },
            { error ->
                textViewDescripcion.text = "Error de conexión"
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = API_KEY
                return headers
            }
        }
        queue.add(request)
    }

    // Sincroniza productos desde el servidor y los guarda en la base de datos local
    private fun sincronizarProductosDesdeServidor() {
        val url = SERVER_URL.replace("datos_envios.php", "obtener_productos.php")
        val request = object : com.android.volley.toolbox.StringRequest(
            com.android.volley.Request.Method.GET, url,
            { response ->
                try {
                    val jsonResponse = org.json.JSONObject(response)
                    if (jsonResponse.optBoolean("success", false)) {
                        val productosArray = jsonResponse.optJSONArray("productos")
                        if (productosArray != null) {
                            val database = AppDatabase.getDatabase(this)
                            val productoDao = database.productoDao()
                            lifecycleScope.launch {
                                // Borra todos los productos locales antes de insertar los nuevos
                                productoDao.borrarTodos()
                                var productosInsertados = 0
                                for (i in 0 until productosArray.length()) {
                                    val productoJson = productosArray.optJSONObject(i)
                                    if (productoJson != null) {
                                        val codigo = if (productoJson.has("sku")) productoJson.optString("sku", "") else ""
                                        val descripcion = if (productoJson.has("descripcion")) productoJson.optString("descripcion", "") else ""
                                        if (codigo.isNotEmpty()) {
                                            val producto = com.example.ssimce.data.local.Producto(codigo, descripcion)
                                            try {
                                                productoDao.insertarProducto(producto)
                                                productosInsertados++
                                            } catch (_: Exception) {}
                                        }
                                    }
                                }

                            }
                        } else {
                            android.widget.Toast.makeText(
                                this,
                                "Respuesta sin productos",
                                android.widget.Toast.LENGTH_LONG
                            ).show()
                        }
                    } else {
                        android.widget.Toast.makeText(
                            this,
                            "Error al sincronizar: ${jsonResponse.optString("error", "Sin mensaje")}",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    }
                } catch (e: Exception) {
                    android.widget.Toast.makeText(
                        this,
                        "Error inesperado: ${e.message}",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                }
            },
            { error ->
                android.widget.Toast.makeText(
                    this,
                    "Error de conexión: ${error.message}",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = API_KEY
                return headers
            }
        }
        com.android.volley.toolbox.Volley.newRequestQueue(this).add(request)
    }

    private fun mostrarDialogoTipoEvidencia(esMRB: Boolean) {
        val opciones = arrayOf("Fotografía", "Video")
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Seleccionar tipo de evidencia")
        builder.setItems(opciones) { _, which ->
            when (which) {
                0 -> capturarFotografia(esMRB)
                1 -> capturarVideo(esMRB)
            }
        }
        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.dismiss()
        }
        builder.show()
    }

    private fun capturarFotografia(esMRB: Boolean) {
        tipoRegistroActual = if (esMRB) "MRB" else "CT"
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            val photoFile = createImageFile()

            photoFile?.also {
                imageUri = FileProvider.getUriForFile(
                    this,
                    "${packageName}.provider",
                    it
                )
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
            startActivityForResult(intent, if (esMRB) 100 else 102)
        }
    }

    private fun capturarVideo(esMRB: Boolean) {
        tipoRegistroActual = if (esMRB) "MRB" else "CT"
        val intent = Intent(MediaStore.ACTION_VIDEO_CAPTURE)
        val videoFile = createVideoFile()

        videoFile?.also {
            videoUri = FileProvider.getUriForFile(
                this,
                "${packageName}.provider",
                it
            )
            intent.putExtra(MediaStore.EXTRA_OUTPUT, videoUri)
            startActivityForResult(intent, if (esMRB) 101 else 103)
        }
    }

    private fun validarCamposMRB(): Boolean {
        val mrb = findViewById<EditText>(R.id.edtMRB).text.toString().trim()
        val jaula = findViewById<EditText>(R.id.edtJaulaMRB).text.toString().trim()
        val spinnerCausaMRB = findViewById<Spinner>(R.id.spinnerCausaMRB)
        val causa = spinnerCausaMRB.selectedItem?.toString() ?: ""
        val sku = findViewById<EditText>(R.id.edtSKUMRB).text.toString().trim()
        val factura = findViewById<EditText>(R.id.edtFacturaMRB).text.toString().trim()
        val cantidad = findViewById<EditText>(R.id.edtCantidadMRB).text.toString().trim()

        return mrb.isNotEmpty() && jaula.isNotEmpty() && causa.isNotEmpty() && 
               sku.isNotEmpty() && factura.isNotEmpty() && cantidad.isNotEmpty()
    }

    private fun validarCamposCT(): Boolean {
        val ct = findViewById<EditText>(R.id.edtCT).text.toString().trim()
        val tienda = findViewById<EditText>(R.id.edtTienda).text.toString().trim()
        val folioTS = findViewById<EditText>(R.id.edtFolioTS).text.toString().trim()
        val sku = findViewById<EditText>(R.id.edtSKUCT).text.toString().trim()
        val spinnerMotivo = findViewById<Spinner>(R.id.spinnerMotivo)
        val motivo = spinnerMotivo.selectedItem?.toString() ?: ""
        val cantidad = findViewById<EditText>(R.id.edtCantidadCT).text.toString().trim()

        return ct.isNotEmpty() && tienda.isNotEmpty() && folioTS.isNotEmpty() && 
               sku.isNotEmpty() && motivo.isNotEmpty() && cantidad.isNotEmpty()
    }

    private fun createImageFile(): File? {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val imageFileName = "MRB_${timeStamp}_"
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(imageFileName, ".jpg", storageDir)
    }

    private fun createVideoFile(): File? {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val videoFileName = "MRB_${timeStamp}_"
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES)
        return File.createTempFile(videoFileName, ".mp4", storageDir)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                100 -> {
                    evidenciaCapturada = true
                    evidenciaUri = imageUri.toString()
                    // Fotografía MRB capturada silenciosamente
                }
                101 -> {
                    evidenciaCapturada = true
                    evidenciaUri = videoUri.toString()
                    // Video MRB capturado silenciosamente
                }
                102 -> {
                    evidenciaCapturada = true
                    evidenciaUri = imageUri.toString()
                    // Fotografía CT capturada silenciosamente
                }
                103 -> {
                    evidenciaCapturada = true
                    evidenciaUri = videoUri.toString()
                    // Video CT capturado silenciosamente
                }
            }
        } else {
            when (requestCode) {
                100, 101, 102, 103 -> {
                    evidenciaCapturada = false
                    evidenciaUri = ""
                    Toast.makeText(this, "Captura cancelada", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun guardarMRBRegistro() {
        val mrb = findViewById<EditText>(R.id.edtMRB).text.toString().trim()
        val jaula = findViewById<EditText>(R.id.edtJaulaMRB).text.toString().trim()
        val spinnerCausaMRB = findViewById<Spinner>(R.id.spinnerCausaMRB)
        val causa = spinnerCausaMRB.selectedItem?.toString() ?: ""
        val sku = findViewById<EditText>(R.id.edtSKUMRB).text.toString().trim()
        val descripcion = findViewById<TextView>(R.id.txtDescripcionSKU).text.toString().trim()
        val factura = findViewById<EditText>(R.id.edtFacturaMRB).text.toString().trim()
        val cantidad = findViewById<EditText>(R.id.edtCantidadMRB).text.toString().trim()
        val observaciones = findViewById<EditText>(R.id.edtObservacionesMRB).text.toString().trim()

        val registro = MRBRegistro(
            mrb = mrb,
            jaula = jaula,
            causa = causa,
            sku = sku,
            descripcion = descripcion,
            factura = factura,
            cantidad = cantidad,
            observaciones = observaciones,
            evidenciaUri = evidenciaUri,
            fecha = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        )

        // Guardar en base de datos local
        lifecycleScope.launch {
            try {
                val database = AppDatabase.getDatabase(this@MainActivityEnvios)
                database.mrbRegistroDao().insertarMRBRegistro(registro)
                
                runOnUiThread {
                    // Registro MRB guardado localmente silenciosamente
                }
                
                // Enviar al servidor
                enviarMRBAlServidor(mrb, sku, descripcion, cantidad, factura, causa, observaciones)
                
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this@MainActivityEnvios, "Error al guardar localmente: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun enviarMRBAlServidor(mrb: String, sku: String, descripcion: String, cantidad: String, factura: String, causa: String, observaciones: String) {
        val url = "http://192.168.1.65/ssimce/datos_envios/guardar_envio_mrb.php"
        
        // Obtener usuario actual (puedes ajustar según tu sistema de usuarios)
        val usuario = "Admin" // Por defecto, puedes obtenerlo de SharedPreferences
        
        // Convertir evidencia a Base64 si existe
        val evidenciaBase64 = if (evidenciaCapturada && evidenciaUri.isNotEmpty()) {
            try {
                val uri = Uri.parse(evidenciaUri)
                val inputStream = contentResolver.openInputStream(uri)
                val bytes = inputStream?.readBytes()
                inputStream?.close()
                if (bytes != null) {
                    android.util.Base64.encodeToString(bytes, android.util.Base64.DEFAULT)
                } else {
                    ""
                }
            } catch (e: Exception) {
                Log.e("SSIMCE", "Error convirtiendo evidencia a Base64: ${e.message}")
                ""
            }
        } else {
            ""
        }
        
        val jsonObject = JSONObject().apply {
            put("fecha", SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
            put("sku", sku)
            put("descripcion", descripcion)
            put("cantidad", cantidad)
            put("factura_remision", factura)
            put("causa", causa)
            put("observaciones", observaciones)
            put("usuario", usuario)
            put("evidencia", evidenciaBase64)
            put("tipo_evidencia", if (evidenciaUri.contains(".mp4")) "video" else "imagen")
        }

        val request = object : JsonObjectRequest(
            Request.Method.POST, url, jsonObject,
            { response ->
                if (response.optBoolean("success", false)) {
                    runOnUiThread {
                        Toast.makeText(this, "Envío MRB guardado en servidor", Toast.LENGTH_LONG).show()
                        limpiarFormularioMRB()
                    }
                } else {
                    runOnUiThread {
                        Toast.makeText(this, "Error al guardar en servidor: ${response.optString("error", "Error desconocido")}", Toast.LENGTH_LONG).show()
                    }
                }
            },
            { error ->
                runOnUiThread {
                    Toast.makeText(this, "Error de conexión: ${error.message}", Toast.LENGTH_LONG).show()
                }
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = API_KEY
                return headers
            }
        }
        
        Volley.newRequestQueue(this).add(request)
    }

    private fun guardarCTRegistro() {
        val ct = findViewById<EditText>(R.id.edtCT).text.toString().trim()
        val tienda = findViewById<EditText>(R.id.edtTienda).text.toString().trim()
        val folioTS = findViewById<EditText>(R.id.edtFolioTS).text.toString().trim()
        val sku = findViewById<EditText>(R.id.edtSKUCT).text.toString().trim()
        val descripcion = findViewById<TextView>(R.id.txtDescripcionCT).text.toString().trim()
        val spinnerMotivo = findViewById<Spinner>(R.id.spinnerMotivo)
        val motivo = spinnerMotivo.selectedItem?.toString() ?: ""
        val cantidad = findViewById<EditText>(R.id.edtCantidadCT).text.toString().trim()
        val observaciones = findViewById<EditText>(R.id.edtObservacionesCT).text.toString().trim()

        val registro = CTRegistro(
            ct = ct,
            tienda = tienda,
            folioTS = folioTS,
            sku = sku,
            descripcion = descripcion,
            motivo = motivo,
            cantidad = cantidad,
            observaciones = observaciones,
            evidenciaUri = evidenciaUri,
            fecha = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        )

        // Guardar en base de datos local
        lifecycleScope.launch {
            try {
                val database = AppDatabase.getDatabase(this@MainActivityEnvios)
                database.ctRegistroDao().insertarCTRegistro(registro)
                
                runOnUiThread {
                    // Registro CT guardado localmente silenciosamente
                }
                
                // Enviar al servidor
                enviarCTAlServidor(ct, tienda, folioTS, sku, descripcion, motivo, cantidad, observaciones)
                
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this@MainActivityEnvios, "Error al guardar localmente: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun enviarCTAlServidor(ct: String, tienda: String, folioTS: String, sku: String, descripcion: String, motivo: String, cantidad: String, observaciones: String) {
        val url = "http://192.168.1.65/ssimce/datos_envios/guardar_envio_ct.php"
        
        // Obtener usuario actual (puedes ajustar según tu sistema de usuarios)
        val usuario = "Admin" // Por defecto, puedes obtenerlo de SharedPreferences
        
        // Convertir evidencia a Base64 si existe
        val evidenciaBase64 = if (evidenciaCapturada && evidenciaUri.isNotEmpty()) {
            try {
                val uri = Uri.parse(evidenciaUri)
                val inputStream = contentResolver.openInputStream(uri)
                val bytes = inputStream?.readBytes()
                inputStream?.close()
                if (bytes != null) {
                    android.util.Base64.encodeToString(bytes, android.util.Base64.DEFAULT)
                } else {
                    ""
                }
            } catch (e: Exception) {
                Log.e("SSIMCE", "Error convirtiendo evidencia a Base64: ${e.message}")
                ""
            }
        } else {
            ""
        }
        
        val jsonObject = JSONObject().apply {
            put("fecha", SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
            put("sku", sku)
            put("descripcion", descripcion)
            put("cantidad", cantidad)
            put("ct", ct)
            put("tienda", tienda)
            put("folio_ts", folioTS)
            put("motivo", motivo)
            put("observaciones", observaciones)
            put("usuario", usuario)
            put("evidencia", evidenciaBase64)
            put("tipo_evidencia", if (evidenciaUri.contains(".mp4")) "video" else "imagen")
        }

        val request = object : JsonObjectRequest(
            Request.Method.POST, url, jsonObject,
            { response ->
                if (response.optBoolean("success", false)) {
                    runOnUiThread {
                        Toast.makeText(this, "Envío CT guardado en servidor", Toast.LENGTH_LONG).show()
                        limpiarFormularioCT()
                    }
                } else {
                    runOnUiThread {
                        Toast.makeText(this, "Error al guardar en servidor: ${response.optString("error", "Error desconocido")}", Toast.LENGTH_LONG).show()
                    }
                }
            },
            { error ->
                runOnUiThread {
                    Toast.makeText(this, "Error de conexión: ${error.message}", Toast.LENGTH_LONG).show()
                }
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = API_KEY
                return headers
            }
        }
        
        Volley.newRequestQueue(this).add(request)
    }

    private fun limpiarFormularioMRB() {
        findViewById<EditText>(R.id.edtMRB).text.clear()
        findViewById<EditText>(R.id.edtJaulaMRB).text.clear()
        findViewById<Spinner>(R.id.spinnerCausaMRB).setSelection(0)
        findViewById<EditText>(R.id.edtSKUMRB).text.clear()
        findViewById<EditText>(R.id.edtFacturaMRB).text.clear()
        findViewById<EditText>(R.id.edtCantidadMRB).text.clear()
        findViewById<EditText>(R.id.edtObservacionesMRB).text.clear()
        findViewById<TextView>(R.id.txtDescripcionSKU).text = "Descripción"
        evidenciaCapturada = false
        evidenciaUri = ""
        tipoRegistroActual = ""
    }

    private fun limpiarFormularioCT() {
        findViewById<EditText>(R.id.edtCT).text.clear()
        findViewById<EditText>(R.id.edtTienda).text.clear()
        findViewById<EditText>(R.id.edtFolioTS).text.clear()
        findViewById<EditText>(R.id.edtSKUCT).text.clear()
        findViewById<Spinner>(R.id.spinnerMotivo).setSelection(0)
        findViewById<EditText>(R.id.edtCantidadCT).text.clear()
        findViewById<EditText>(R.id.edtObservacionesCT).text.clear()
        findViewById<TextView>(R.id.txtDescripcionCT).text = "Descripción"
        evidenciaCapturada = false
        evidenciaUri = ""
        tipoRegistroActual = ""
    }

    private fun configurarSpinnerMotivo(spinner: Spinner) {
        val opcionesMotivo = arrayOf(
            "Seleccione motivo",
            "Incompleto",
            "Dañado en exhibición", 
            "Sobrestock",
            "No funciono al desempacar",
            "Convenio",
            "Enviar a Bodega",
            "Orden de cambio"
        )
        
        val adapter = ArrayAdapter(this, R.layout.spinner_item_black_text, opcionesMotivo)
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item_black_text)
        spinner.adapter = adapter
    }

    private fun configurarSpinnerCausaMRB(spinner: Spinner) {
        val opcionesCausa = arrayOf(
            "Seleccione causa",
            "C-16 Acta",
            "C-16 VP",
            "C-15",
            "C-15 VS",
            "RR",
            "RE",
            "DV"
        )
        
        val adapter = ArrayAdapter(this, R.layout.spinner_item_black_text, opcionesCausa)
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item_black_text)
        spinner.adapter = adapter
    }

    private fun configurarNavegacionCamposCT() {
        val edtCT = findViewById<EditText>(R.id.edtCT)
        val edtTienda = findViewById<EditText>(R.id.edtTienda)
        val edtFolioTS = findViewById<EditText>(R.id.edtFolioTS)
        val edtSKUCT = findViewById<EditText>(R.id.edtSKUCT)
        val spinnerMotivo = findViewById<Spinner>(R.id.spinnerMotivo)
        val edtCantidadCT = findViewById<EditText>(R.id.edtCantidadCT)
        val edtObservacionesCT = findViewById<EditText>(R.id.edtObservacionesCT)

        // CT -> Tienda
        edtCT.setOnEditorActionListener { _, _, _ ->
            edtTienda.requestFocus()
            true
        }

        // Tienda -> Folio TS
        edtTienda.setOnEditorActionListener { _, _, _ ->
            edtFolioTS.requestFocus()
            true
        }

        // Folio TS -> SKU
        edtFolioTS.setOnEditorActionListener { _, _, _ ->
            edtSKUCT.requestFocus()
            true
        }

        // SKU -> Motivo (Spinner) - ya configurado arriba
        // Motivo -> Cantidad (Spinner no necesita navegación automática)
        // Cantidad -> Observaciones
        edtCantidadCT.setOnEditorActionListener { _, _, _ ->
            edtObservacionesCT.requestFocus()
            true
        }

        // Observaciones -> Botón Guardar (opcional, para completar el flujo)
        edtObservacionesCT.setOnEditorActionListener { _, _, _ ->
            // Al presionar Enter en observaciones, se puede activar el botón guardar
            // o simplemente quitar el foco
            edtObservacionesCT.clearFocus()
            true
        }
    }


}