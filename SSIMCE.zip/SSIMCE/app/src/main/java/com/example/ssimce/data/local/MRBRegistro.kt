package com.example.ssimce.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "mrb_registros")
data class MRBRegistro(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val mrb: String,
    val jaula: String,
    val causa: String,
    val sku: String,
    val descripcion: String,
    val factura: String,
    val cantidad: String,
    val observaciones: String,
    val evidenciaUri: String,
    val fecha: String
) 