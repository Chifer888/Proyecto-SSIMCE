package com.example.ssimce.salidas

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.ssimce.R
import com.bumptech.glide.Glide
import android.util.Log
import androidx.lifecycle.lifecycleScope
import com.example.ssimce.data.local.AppDatabase
import com.example.ssimce.data.local.Irregularidad
import kotlinx.coroutines.launch

class PdaSalidasActivity : AppCompatActivity() {

    private lateinit var editSKU: EditText
    private lateinit var editDescripcion: EditText
    private lateinit var editCantidad: EditText
    private lateinit var btnGuardar: Button
    private lateinit var btnLimpiar: Button
    private lateinit var btnRegresar: Button
    private lateinit var btnEscanear: Button
    private lateinit var imageViewProducto: ImageView
    private lateinit var progressBarBusqueda: ProgressBar
    private lateinit var txtStock: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pda_salidas)

        // Inicializar vistas
        editSKU = findViewById(R.id.editSKU)
        editDescripcion = findViewById(R.id.editDescripcion)
        editCantidad = findViewById(R.id.editCantidad)
        btnGuardar = findViewById(R.id.btnGuardar)
        btnLimpiar = findViewById(R.id.btnLimpiar)
        btnRegresar = findViewById(R.id.btnRegresar)
        btnEscanear = findViewById(R.id.btnEscanear)
        imageViewProducto = findViewById(R.id.imageViewProducto)
        progressBarBusqueda = findViewById(R.id.progressBarBusqueda)
        txtStock = findViewById(R.id.txtStock)

        // Configurar listeners
        btnGuardar.setOnClickListener {
            guardarDatos()
        }

        btnLimpiar.setOnClickListener {
            limpiarFormulario()
        }

        btnRegresar.setOnClickListener {
            finish()
        }

        btnEscanear.setOnClickListener {
            abrirScanner()
        }

        // Ampliar imagen al pulsar sobre ella
        imageViewProducto.setOnTouchListener { _, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    imageViewProducto.animate().scaleX(2.5f).scaleY(2.5f).setDuration(300).start()
                    true
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    imageViewProducto.animate().scaleX(1.0f).scaleY(1.0f).setDuration(300).start()
                    true
                }
                else -> false
            }
        }

        // Configurar validaciones
        configurarValidaciones()

        // Configurar búsqueda automática al cambiar foco
        configurarBusquedaAutomatica()

        // Buscar producto al presionar Enter/Siguiente en el campo SKU
        editSKU.setOnEditorActionListener { v, actionId, event ->
            val sku = editSKU.text.toString().trim()
            if (sku.isNotEmpty()) {
                buscarProducto(sku)
                // Si la cantidad está vacía, poner 1
                if (editCantidad.text.toString().trim().isEmpty()) {
                    editCantidad.setText("1")
                }
            }
            false // Permite que el evento siga su curso normal
        }
    }

    private fun configurarValidaciones() {
        // Validar que cantidad solo acepte números
        editCantidad.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                val texto = s.toString()
                if (texto.isNotEmpty() && !texto.all { it.isDigit() }) {
                    editCantidad.setText("")
                    editCantidad.setSelection(0)
                    Toast.makeText(this@PdaSalidasActivity,
                        "El campo cantidad solo acepta números", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun guardarDatos() {
        val sku = editSKU.text.toString().trim()
        val descripcion = editDescripcion.text.toString().trim()
        val cantidad = editCantidad.text.toString().trim()

        // Validar campos obligatorios
        if (sku.isEmpty() || descripcion.isEmpty() || cantidad.isEmpty()) {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
            return
        }

        // Verificar si el producto existe (si la descripción es "Producto no encontrado" o "Error de conexión")
        if (descripcion == "Producto no encontrado" || descripcion == "Error de conexión" || descripcion == "Sin descripción") {
            Toast.makeText(this, "No se puede guardar: Producto no encontrado en la base de datos", Toast.LENGTH_LONG).show()
            return
        }

        // Verificar si se cargó la imagen del producto (opcional, pero indica que el producto existe)
        if (imageViewProducto.visibility == View.GONE) {
            Toast.makeText(this, "No se puede guardar: Producto no encontrado o sin imagen", Toast.LENGTH_LONG).show()
            return
        }

        // Validar que la cantidad sea un número válido
        val cantidadNum = try {
            cantidad.toDouble()
        } catch (e: NumberFormatException) {
            Toast.makeText(this, "La cantidad debe ser un número válido", Toast.LENGTH_SHORT).show()
            return
        }

        if (cantidadNum <= 0) {
            Toast.makeText(this, "La cantidad debe ser mayor a 0", Toast.LENGTH_SHORT).show()
            return
        }

        // Verificar stock disponible antes de permitir la salida
        val stockActual = txtStock.text.toString().toIntOrNull() ?: 0
        if (stockActual <= 0) {
            Toast.makeText(this, "❌ No se puede generar salida: Stock insuficiente (Stock actual: $stockActual)", Toast.LENGTH_LONG).show()
            return
        }

        // Verificar que la cantidad a salir no exceda el stock disponible
        if (cantidadNum > stockActual) {
            Toast.makeText(this, "❌ No se puede generar salida: Cantidad ($cantidadNum) excede el stock disponible ($stockActual)", Toast.LENGTH_LONG).show()
            return
        }

        // Guardar salida directamente sin preguntar por irregularidades
        guardarSalidaEnServidor(sku, descripcion, cantidad, "SALIDA_NORMAL", "")
    }

    private fun mostrarDialogoIrregularidades(sku: String, descripcion: String, cantidad: String) {
        Log.d("SSIMCE", "Mostrando diálogo de irregularidades para SKU: $sku")
        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
        builder.setTitle("Verificación de Irregularidades")
        builder.setMessage("¿Hay alguna irregularidad con este producto?")
        builder.setPositiveButton("SÍ") { _, _ ->
            Log.d("SSIMCE", "Usuario seleccionó SÍ - Abriendo cámara para evidencia")
            abrirCamaraParaEvidencia(sku, descripcion, cantidad)
        }
        builder.setNegativeButton("NO") { _, _ ->
            Log.d("SSIMCE", "Usuario seleccionó NO - Guardando salida normal")
            guardarSalidaEnServidor(sku, descripcion, cantidad, "SALIDA_NORMAL", "")
        }
        builder.setNeutralButton("CANCELAR") { dialog, _ ->
            Log.d("SSIMCE", "Usuario canceló el diálogo")
            dialog.dismiss()
        }
        builder.show()
    }

    private fun limpiarFormulario() {
        editSKU.setText("")
        editDescripcion.setText("")
        editCantidad.setText("")
        
        // Limpiar stock con solo el número
        txtStock.text = "0"
        txtStock.setTextColor(resources.getColor(android.R.color.darker_gray, null))

        // Limpiar la imagen del producto
        imageViewProducto.setImageDrawable(null)
        imageViewProducto.visibility = View.GONE

        // Ocultar el progress bar si está visible
        progressBarBusqueda.visibility = View.GONE
        
        // Enfocar el campo SKU para facilitar la siguiente entrada
        editSKU.requestFocus()
    }

    private fun configurarBusquedaAutomatica() {
        editSKU.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val sku = editSKU.text.toString().trim()
                if (sku.isNotEmpty()) {
                    buscarProducto(sku)
                    // También calcular stock automáticamente
                    calcularStockDisponible(sku)
                } else {
                    // Limpiar stock si el SKU está vacío
                    txtStock.text = "0"
                    txtStock.setTextColor(resources.getColor(android.R.color.darker_gray, null))
                }
            }
        }

        // También actualizar stock cuando se presiona Enter en el campo SKU
        editSKU.setOnEditorActionListener { v, actionId, event ->
            val sku = editSKU.text.toString().trim()
            if (sku.isNotEmpty()) {
                buscarProducto(sku)
                calcularStockDisponible(sku)
                // Si la cantidad está vacía, poner 1
                if (editCantidad.text.toString().trim().isEmpty()) {
                    editCantidad.setText("1")
                }
            }
            false // Permite que el evento siga su curso normal
        }
    }

    private fun buscarProducto(sku: String) {
        progressBarBusqueda.visibility = View.VISIBLE
        imageViewProducto.visibility = View.GONE
        editDescripcion.setText("")

        val url = "http://192.168.1.65/ssimce/imagenes/imagenes_productos.php?sku=$sku"
        Log.d("SSIMCE", "Intentando conectar a: $url")
        val queue = Volley.newRequestQueue(this)

        val jsonObjectRequest = object : JsonObjectRequest(
            Request.Method.GET, url, null,
            { response ->
                Log.d("SSIMCE", "Respuesta completa del servidor: $response")
                progressBarBusqueda.visibility = View.GONE
                if (response.optBoolean("success", false)) {
                    val producto = response.getJSONObject("producto")
                    val descripcion = producto.optString("descripcion", "Sin descripción")
                    val imagenUrl = producto.optString("imagen_url", "")
                    Log.d("SSIMCE", "Descripción recibida: $descripcion")
                    Log.d("SSIMCE", "URL de imagen recibida: $imagenUrl")
                    editDescripcion.setText(descripcion)
                    if (imagenUrl.isNotEmpty()) {
                        Log.d("SSIMCE", "Intentando cargar imagen desde: $imagenUrl")
                        imageViewProducto.visibility = View.VISIBLE
                        Glide.with(this)
                            .load(imagenUrl)
                            .placeholder(R.drawable.ic_launcher_foreground)
                            .error(R.drawable.ic_launcher_foreground)
                            .listener(object : com.bumptech.glide.request.RequestListener<android.graphics.drawable.Drawable> {
                                override fun onLoadFailed(e: com.bumptech.glide.load.engine.GlideException?, model: Any?, target: com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable>, isFirstResource: Boolean): Boolean {
                                    Log.e("SSIMCE", "Error al cargar imagen: ${e?.message}")
                                    return false
                                }

                                override fun onResourceReady(resource: android.graphics.drawable.Drawable, model: Any, target: com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable>, dataSource: com.bumptech.glide.load.DataSource, isFirstResource: Boolean): Boolean {
                                    Log.d("SSIMCE", "Imagen cargada exitosamente")
                                    return false
                                }
                            })
                            .into(imageViewProducto)
                    } else {
                        Log.d("SSIMCE", "URL de imagen está vacía")
                        imageViewProducto.visibility = View.GONE
                    }
                } else {
                    editDescripcion.setText("Producto no encontrado")
                    imageViewProducto.visibility = View.GONE
                }

                // Calcular stock disponible después de obtener la información del producto
                calcularStockDisponible(sku)
            },
            { error ->
                Log.e("SSIMCE", "Error en la petición: ${error.message}")
                progressBarBusqueda.visibility = View.GONE
                editDescripcion.setText("Error de conexión")
                imageViewProducto.visibility = View.GONE
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = "MI_API_KEY_SECRETA"
                return headers
            }
        }
        queue.add(jsonObjectRequest)
    }

    // Función para calcular el stock disponible del SKU
    private fun calcularStockDisponible(sku: String) {
        val url = "http://192.168.1.65/ssimce/calcular_stock.php?sku=$sku"
        Log.d("SSIMCE", "Calculando stock para SKU: $sku")
        val queue = Volley.newRequestQueue(this)

        val jsonObjectRequest = object : JsonObjectRequest(
            Request.Method.GET, url, null,
            { response ->
                Log.d("SSIMCE", "Respuesta de cálculo de stock: $response")
                if (response.optBoolean("success", false)) {
                    val stockData = response.getJSONObject("stock")
                    val stockDisponible = stockData.optDouble("stock_disponible", 0.0)
                    val totalEntradas = stockData.optDouble("total_entradas", 0.0)
                    val totalSalidas = stockData.optDouble("total_salidas", 0.0)

                    runOnUiThread {
                        // Mostrar solo el número del stock disponible
                        val stockText = when {
                            stockDisponible > 0 -> stockDisponible.toInt().toString()
                            stockDisponible == 0.0 -> "0"
                            else -> stockDisponible.toInt().toString()
                        }
                        
                        txtStock.text = stockText

                        // Cambiar solo el color del texto según el stock disponible
                        when {
                            stockDisponible <= 0 -> {
                                txtStock.setTextColor(resources.getColor(android.R.color.holo_red_dark, null))
                            }
                            stockDisponible < 5 -> {
                                txtStock.setTextColor(resources.getColor(android.R.color.holo_orange_dark, null))
                            }
                            else -> {
                                txtStock.setTextColor(resources.getColor(android.R.color.holo_green_dark, null))
                            }
                        }

                        // Quitar la notificación Toast de entradas y salidas
                        // val infoAdicional = "Entradas: $totalEntradas | Salidas: $totalSalidas"
                        // Toast.makeText(this@PdaSalidasActivity, infoAdicional, Toast.LENGTH_SHORT).show()
                    }
                } else {
                    runOnUiThread {
                        txtStock.text = "0"
                        txtStock.setTextColor(resources.getColor(android.R.color.holo_red_dark, null))
                    }
                }
            },
            { error ->
                Log.e("SSIMCE", "Error al calcular stock: ${error.message}")
                runOnUiThread {
                    txtStock.text = "0"
                    txtStock.setTextColor(resources.getColor(android.R.color.holo_red_dark, null))
                }
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = "MI_API_KEY_SECRETA"
                return headers
            }
        }
        queue.add(jsonObjectRequest)
    }

    // Función para guardar la salida en el servidor
    private fun guardarSalidaEnServidor(sku: String, descripcion: String, cantidad: String, tipoSalida: String, observaciones: String) {
        val url = "http://192.168.1.65/ssimce/guardar_salida.php"
        val queue = Volley.newRequestQueue(this)

        // Obtener usuario actual desde SharedPreferences
        val sharedPreferences = getSharedPreferences("SSIMCE_PREFS", MODE_PRIVATE)
        val usuario = sharedPreferences.getString("numero_empleado", "admin") ?: "admin"

        val jsonObject = org.json.JSONObject().apply {
            put("sku", sku)
            put("descripcion", descripcion)
            put("cantidad", cantidad.toDouble())
            put("usuario", usuario)
            put("tipo_salida", tipoSalida)
            put("observaciones", observaciones)
        }

        Log.d("SSIMCE", "Enviando datos al servidor: $jsonObject")
        Log.d("SSIMCE", "URL: $url")

        val jsonObjectRequest = object : JsonObjectRequest(
            Request.Method.POST, url, jsonObject,
            { response ->
                Log.d("SSIMCE", "Respuesta del servidor: $response")
                if (response.optBoolean("success", false)) {
                    val folioSalida = response.optString("folio_salida", "")
                    val stockAnterior = response.optDouble("stock_anterior", 0.0)
                    val stockNuevo = response.optDouble("stock_nuevo", 0.0)

                    Log.d("SSIMCE", "Salida guardada exitosamente - Folio: $folioSalida, Stock: $stockAnterior → $stockNuevo")

                    Toast.makeText(
                        this,
                        "✅ Salida registrada exitosamente\nFolio: $folioSalida\nStock: $stockAnterior → $stockNuevo",
                        Toast.LENGTH_LONG
                    ).show()

                    // Limpiar formulario inmediatamente (incluye limpiar stock)
                    limpiarFormulario()
                } else {
                    val error = response.optString("error", "Error desconocido")
                    Log.e("SSIMCE", "Error del servidor: $error")
                    Toast.makeText(this, "❌ Error al guardar: $error", Toast.LENGTH_LONG).show()
                }
            },
            { error ->
                Log.e("SSIMCE", "Error de conexión al guardar salida: ${error.message}")
                Log.e("SSIMCE", "Error completo: $error")
                Toast.makeText(this, "❌ Error de conexión: ${error.message}", Toast.LENGTH_LONG).show()
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = "MI_API_KEY_SECRETA"
                headers["Content-Type"] = "application/json"
                return headers
            }
        }
        queue.add(jsonObjectRequest)
    }

    private fun abrirScanner() {
        val intent = Intent(this, com.example.ssimce.entradas.entradas.BarcodeScannerActivity::class.java)
        intent.putExtra("TIPO_TABLA", "SALIDAS")
        startActivityForResult(intent, REQUEST_CODE_SCANNER)
    }

    companion object {
        private const val REQUEST_CODE_SCANNER = 1001
        private const val REQUEST_CODE_CAMERA_EVIDENCIA = 1002
    }

    private var datosTemporales: Map<String, String> = emptyMap()

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.d("SSIMCE", "onActivityResult - requestCode: $requestCode, resultCode: $resultCode")

        if (requestCode == REQUEST_CODE_SCANNER && resultCode == RESULT_OK) {
            Log.d("SSIMCE", "Resultado del scanner recibido")
            data?.let { intent ->
                val scannedSku = intent.getStringExtra("SCANNED_SKU") ?: ""
                val scannedDescription = intent.getStringExtra("SCANNED_DESCRIPTION") ?: ""
                val scannedQuantity = intent.getStringExtra("SCANNED_QUANTITY") ?: "1"
                Log.d("SSIMCE", "Datos escaneados - SKU: $scannedSku, Descripción: $scannedDescription, Cantidad: $scannedQuantity")
                editSKU.setText(scannedSku)
                editDescripcion.setText(scannedDescription)
                if (scannedQuantity.isEmpty() || scannedQuantity == "0") {
                    editCantidad.setText("1")
                } else {
                    editCantidad.setText(scannedQuantity)
                }
                if (scannedSku.isNotEmpty()) {
                    buscarProducto(scannedSku)
                }
            }
        } else if (requestCode == REQUEST_CODE_CAMERA_EVIDENCIA && resultCode == RESULT_OK) {
            Log.d("SSIMCE", "Resultado de cámara para evidencia recibido")
            data?.let { intent ->
                val imagenEvidencia = intent.getParcelableExtra<android.graphics.Bitmap>("data")
                if (imagenEvidencia != null) {
                    Log.d("SSIMCE", "Imagen de evidencia capturada exitosamente: ${imagenEvidencia.width}x${imagenEvidencia.height}")
                    mostrarDialogoObservaciones(imagenEvidencia)
                } else {
                    Log.e("SSIMCE", "Error: imagenEvidencia es null")
                    Toast.makeText(this, "Error al capturar imagen", Toast.LENGTH_SHORT).show()
                }
            }
        } else if (requestCode == REQUEST_CODE_CAMERA_EVIDENCIA) {
            Log.d("SSIMCE", "Cámara cancelada o error - resultCode: $resultCode")
        }
    }

    private fun abrirCamaraParaEvidencia(sku: String, descripcion: String, cantidad: String) {
        Log.d("SSIMCE", "Abriendo cámara para evidencia - SKU: $sku, Descripción: $descripcion, Cantidad: $cantidad")
        val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, REQUEST_CODE_CAMERA_EVIDENCIA)
        datosTemporales = mapOf(
            "sku" to sku,
            "descripcion" to descripcion,
            "cantidad" to cantidad
        )
        Log.d("SSIMCE", "Datos temporales guardados: $datosTemporales")
    }

    private fun mostrarDialogoObservaciones(imagenEvidencia: android.graphics.Bitmap) {
        Log.d("SSIMCE", "Mostrando diálogo de observaciones - Imagen capturada: ${imagenEvidencia.width}x${imagenEvidencia.height}")
        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
        builder.setTitle("Observaciones de Irregularidad")
        builder.setMessage("Ingrese las observaciones sobre la irregularidad:")
        val input = EditText(this)
        input.hint = "Escriba las observaciones aquí..."
        input.setSingleLine(false)
        input.minLines = 3
        input.maxLines = 5
        builder.setView(input)
        builder.setPositiveButton("GUARDAR") { _, _ ->
            val observaciones = input.text.toString().trim()
            Log.d("SSIMCE", "Observaciones ingresadas: $observaciones")
            if (observaciones.isNotEmpty()) {
                val sku = datosTemporales["sku"] ?: ""
                val descripcion = datosTemporales["descripcion"] ?: ""
                val cantidad = datosTemporales["cantidad"] ?: ""
                Log.d("SSIMCE", "Datos para guardar irregularidad - SKU: $sku, Descripción: $descripcion, Cantidad: $cantidad")
                guardarIrregularidadLocal(sku, descripcion, cantidad, observaciones, imagenEvidencia)
            } else {
                Log.w("SSIMCE", "Usuario no ingresó observaciones")
                Toast.makeText(this, "Debe ingresar observaciones", Toast.LENGTH_SHORT).show()
            }
        }
        builder.setNegativeButton("CANCELAR") { dialog, _ ->
            Log.d("SSIMCE", "Usuario canceló el diálogo de observaciones")
            dialog.dismiss()
        }
        builder.show()
    }

    private fun guardarIrregularidadLocal(sku: String, descripcion: String, cantidad: String, observaciones: String, imagenEvidencia: android.graphics.Bitmap) {
        Log.d("SSIMCE", "Iniciando guardado de irregularidad: SKU=$sku, Descripción=$descripcion, Cantidad=$cantidad")

        // Convertir imagen a WebP
        val imagenWebP = convertirImagenAWebP(imagenEvidencia)
        if (imagenWebP == null) {
            Log.e("SSIMCE", "Error al convertir imagen a WebP")
            Toast.makeText(this, "Error al procesar la imagen", Toast.LENGTH_SHORT).show()
            return
        }

        Log.d("SSIMCE", "Imagen convertida exitosamente, tamaño: ${imagenWebP.size} bytes")

        // Guardar en el servidor primero (salida con tipo irregularidad)
        guardarSalidaEnServidor(sku, descripcion, cantidad, "SALIDA_IRREGULAR", observaciones)
        
        // Luego guardar la irregularidad localmente
        lifecycleScope.launch {
            try {
                val database = AppDatabase.getDatabase(this@PdaSalidasActivity)
                
                // Generar folio único
                val folio = "IRR_${System.currentTimeMillis()}"
                
                val irregularidad = Irregularidad(
                    folio = folio,
                    sku = sku,
                    descripcion = descripcion,
                    cantidad = cantidad,
                    observaciones = observaciones,
                    imagenWebP = imagenWebP
                )
                
                database.irregularidadDao().insertarIrregularidad(irregularidad)
                Log.d("SSIMCE", "Irregularidad guardada localmente exitosamente")
                
                runOnUiThread {
                    Toast.makeText(this@PdaSalidasActivity, "✅ Irregularidad registrada y guardada", Toast.LENGTH_LONG).show()
                    limpiarFormulario()
                }
                
                // Sincronizar con el servidor
                enviarIrregularidadAlServidor(sku, descripcion, cantidad, observaciones, imagenWebP)
                
            } catch (e: Exception) {
                Log.e("SSIMCE", "Error al guardar irregularidad localmente: ${e.message}")
                runOnUiThread {
                    Toast.makeText(this@PdaSalidasActivity, "❌ Error al guardar irregularidad: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun convertirImagenAWebP(bitmap: android.graphics.Bitmap): ByteArray? {
        return try {
            val outputStream = java.io.ByteArrayOutputStream()
            bitmap.compress(android.graphics.Bitmap.CompressFormat.WEBP, 85, outputStream)
            outputStream.toByteArray()
        } catch (e: Exception) {
            Log.e("SSIMCE", "Error al convertir imagen a WebP: ${e.message}")
            null
        }
    }

    private fun enviarIrregularidadAlServidor(sku: String, descripcion: String, cantidad: String, observaciones: String, imagenEvidencia: ByteArray) {
        val url = "http://192.168.1.65/ssimce/sincronizar_irregularidades.php"
        val queue = Volley.newRequestQueue(this)

        // Obtener usuario actual desde SharedPreferences
        val sharedPreferences = getSharedPreferences("SSIMCE_PREFS", MODE_PRIVATE)
        val usuario = sharedPreferences.getString("numero_empleado", "admin") ?: "admin"

        // Convertir imagen a Base64
        val imagenBase64 = android.util.Base64.encodeToString(imagenEvidencia, android.util.Base64.DEFAULT)

        val jsonObject = org.json.JSONObject().apply {
            put("sku", sku)
            put("descripcion", descripcion)
            put("cantidad", cantidad.toDouble())
            put("observaciones", observaciones)
            put("usuario", usuario)
            put("evidencia", imagenBase64)
            put("tipo_evidencia", "imagen")
        }

        val jsonObjectRequest = object : JsonObjectRequest(
            Request.Method.POST, url, jsonObject,
            { response ->
                Log.d("SSIMCE", "Respuesta del servidor para irregularidad: $response")
                if (response.optBoolean("success", false)) {
                    Log.d("SSIMCE", "Irregularidad sincronizada exitosamente con el servidor")
                    // Nota: No tenemos método para marcar como sincronizado, pero la irregularidad ya se guardó
                } else {
                    val error = response.optString("error", "Error desconocido")
                    Log.e("SSIMCE", "Error al sincronizar irregularidad: $error")
                }
            },
            { error ->
                Log.e("SSIMCE", "Error de conexión al sincronizar irregularidad: ${error.message}")
            }
        ) {
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["api_key"] = "MI_API_KEY_SECRETA"
                headers["Content-Type"] = "application/json"
                return headers
            }
        }
        queue.add(jsonObjectRequest)
    }
}