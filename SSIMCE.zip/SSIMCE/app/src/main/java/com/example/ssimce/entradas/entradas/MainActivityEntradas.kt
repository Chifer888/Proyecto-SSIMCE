package com.example.ssimce.entradas.entradas

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.ssimce.inicio.MainActivityMenuPrincipal
import com.example.ssimce.R

class MainActivityEntradas : AppCompatActivity() {

    private lateinit var btnEntregasClientes: Button
    private lateinit var btnSurtidoTiendasNuevo: Button
    private lateinit var btnLoteoJabas: Button
    private lateinit var btnRopa: Button
    private lateinit var btnHome: Button
    private lateinit var imageViewFoto: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_entradas)

        // Inicializa los elementos
        btnEntregasClientes = findViewById(R.id.btnEntregasClientes)
        btnSurtidoTiendasNuevo = findViewById(R.id.btnSurtidoTiendasNuevo)
        btnLoteoJabas = findViewById(R.id.btnLoteoJabas)
        btnRopa = findViewById(R.id.btnRopa)
        btnHome = findViewById(R.id.btnHome)
        imageViewFoto = findViewById(R.id.imageViewFoto)

        // Configurar listeners para cada tipo de tabla
        btnEntregasClientes.setOnClickListener {
            val intent = Intent(this, PdaEntregasClientesActivity::class.java)
            startActivity(intent)
        }

        btnSurtidoTiendasNuevo.setOnClickListener {
            val intent = Intent(this, PdaSurtidoTiendasActivity::class.java)
            startActivity(intent)
        }

        btnLoteoJabas.setOnClickListener {
            val intent = Intent(this, PdaLoteoJabasActivity::class.java)
            startActivity(intent)
        }

        btnRopa.setOnClickListener {
            val intent = Intent(this, PdaRopaActivity::class.java)
            startActivity(intent)
        }

        // Regresar a menú principal
        btnHome.setOnClickListener {
            val intent = Intent(this, MainActivityMenuPrincipal::class.java)
            startActivity(intent)
            finishAffinity()
        }
    }
}