<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, api_key');

// Habilitar reporte de errores para debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log de información de debugging
error_log("=== GUARDAR_ENVIO_CT.PHP EJECUTADO ===");

// Manejar preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Leer configuración de base de datos
$config_path = 'D:/Programas Instalados/XAMMP/htdocs/private/config.ini';

if (!file_exists($config_path)) {
    error_log("ERROR: Archivo de configuración no encontrado en: $config_path");
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Archivo de configuración no encontrado'
    ]);
    exit();
}

try {
    $config = parse_ini_file($config_path);
} catch (Exception $e) {
    error_log("ERROR leyendo configuración: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error leyendo configuración: ' . $e->getMessage()
    ]);
    exit();
}

$host = $config['host'] ?? 'localhost';
$dbname = $config['dbname'] ?? 'ssimce_db';
$username = $config['username'] ?? 'root';
$password = $config['password'] ?? '';
$api_key_config = $config['api_key'] ?? 'MI_API_KEY_SECRETA';

// Verificar API key
$headers = getallheaders();
$api_key = isset($headers['api_key']) ? $headers['api_key'] : '';

if ($api_key !== $api_key_config) {
    error_log("ERROR: API key inválida - Recibida: $api_key, Esperada: $api_key_config");
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'API key inválida'
    ]);
    exit();
}

// Intentar conexión a base de datos
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    error_log("Conexión a BD exitosa");
} catch (PDOException $e) {
    error_log("ERROR de conexión a BD: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error de conexión a la base de datos: ' . $e->getMessage()
    ]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Obtener datos del POST
        $input = file_get_contents('php://input');
        $data = json_decode($input, true);
        
        error_log("Datos recibidos: " . ($data ? json_encode(array_keys($data)) : "NULL"));
        
        if (!$data) {
            throw new Exception('Datos JSON inválidos');
        }
        
        // Validar campos requeridos
        $campos_requeridos = ['fecha', 'sku', 'descripcion', 'cantidad', 'ct', 'tienda', 'folio_ts', 'motivo', 'usuario'];
        foreach ($campos_requeridos as $campo) {
            if (!isset($data[$campo]) || empty($data[$campo])) {
                throw new Exception("Campo requerido faltante: $campo");
            }
        }
        
        // Procesar evidencia si existe
        $evidencia_blob = null;
        $tipo_evidencia = null;
        
        if (isset($data['evidencia']) && !empty($data['evidencia'])) {
            $evidencia_base64 = $data['evidencia'];
            $evidencia_blob = base64_decode($evidencia_base64);
            $tipo_evidencia = $data['tipo_evidencia'] ?? 'imagen';
            error_log("Evidencia recibida - Tipo: $tipo_evidencia, Tamaño: " . strlen($evidencia_blob) . " bytes");
        }
        
        // Insertar en tabla envios_ct
        $stmt = $pdo->prepare("
            INSERT INTO envios_ct 
            (fecha, sku, descripcion, cantidad, ct, tienda, folio_ts, motivo, observaciones, usuario, evidencia, tipo_evidencia) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $data['fecha'],
            $data['sku'],
            $data['descripcion'],
            $data['cantidad'],
            $data['ct'],
            $data['tienda'],
            $data['folio_ts'],
            $data['motivo'],
            $data['observaciones'] ?? null,
            $data['usuario'],
            $evidencia_blob,
            $tipo_evidencia
        ]);
        
        $id_insertado = $pdo->lastInsertId();
        error_log("Registro CT insertado con ID: $id_insertado");
        
        echo json_encode([
            'success' => true,
            'message' => 'Envío CT guardado correctamente',
            'id' => $id_insertado,
            'evidencia_incluida' => $evidencia_blob !== null
        ]);
        
    } catch (PDOException $e) {
        error_log("ERROR al guardar CT: " . $e->getMessage());
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Error al guardar envío CT: ' . $e->getMessage()
        ]);
    } catch (Exception $e) {
        error_log("ERROR de validación: " . $e->getMessage());
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Método no permitido'
    ]);
}
?> 