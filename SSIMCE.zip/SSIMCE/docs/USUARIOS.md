# 👥 Módulo de Gestión de Usuarios

## 📋 Descripción
Módulo completo para gestión de usuarios del sistema SSIMCE. Permite crear, leer, actualizar y eliminar usuarios con diferentes roles y permisos. Incluye interfaz optimizada para dispositivos móviles con cámara frontal.

## ✅ Funcionalidades Implementadas

### 🔐 **Sistema de Roles**
- **Admin** - Control total del sistema
- **Supervisor** - Acceso a catálogo, usuarios e irregularidades
- **Rampero** - Acceso a entradas, envíos e irregularidades
- **Operador** - Acceso solo a salidas e irregularidades

### 📝 **CRUD Completo**
- **Crear usuarios** - Nuevos registros con contraseña hasheada
- **Leer usuarios** - Lista completa con texto azul para mejor visibilidad
- **Actualizar usuarios** - Modificación de datos existentes
- **Eliminar usuarios** - Eliminación con protección de admin

### 🎨 **Interfaz Optimizada**
- **Diseño para cámara frontal** - Elementos desplazados hacia abajo
- **Texto azul** - Mejor visibilidad en listas
- **Formulario completo** - Todos los campos necesarios
- **Validación en tiempo real** - Verificación de datos

## 🗄️ Estructura de Base de Datos

### Tabla `usuarios`
```sql
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    perfil ENUM('admin', 'supervisor', 'rampero', 'operador') DEFAULT 'operador',
    email VARCHAR(100),
    telefono VARCHAR(20),
    activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_modificacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### 👤 **Usuario Administrador por Defecto**
```sql
INSERT INTO usuarios (nombre, apellido, usuario, password, perfil, email, activo) 
VALUES ('Administrador', 'Sistema', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'admin@ssimce.com', TRUE);
```

## 🔧 Archivos PHP del Servidor

### 📁 Endpoints Disponibles
- **`guardar_usuario.php`** - Crear nuevo usuario
- **`modificar_usuario.php`** - Actualizar usuario existente
- **`eliminar_usuario.php`** - Eliminar usuario
- **`obtener_usuarios.php`** - Obtener lista completa

### 🔐 Seguridad
- **API Key** - Autenticación en todos los endpoints
- **Password hashing** - Contraseñas encriptadas con bcrypt
- **Protección de admin** - No se puede eliminar usuario admin
- **Validación de datos** - Verificación en servidor

## 📱 Características de la App

### 🎯 **Campos del Formulario**
1. **Nombre** - Campo de texto requerido
2. **Apellido** - Campo de texto requerido
3. **Usuario** - Campo único para login
4. **Contraseña** - Campo de contraseña
5. **Perfil** - Spinner con roles disponibles
6. **Email** - Campo de email opcional
7. **Teléfono** - Campo de teléfono opcional
8. **Activo** - Checkbox para estado

### 🎨 **Interfaz Optimizada**
```xml
<!-- Diseño para evitar cámara frontal -->
<LinearLayout
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="vertical"
    android:background="#F5F5F5"
    android:padding="20dp">

    <!-- Título desplazado hacia abajo -->
    <TextView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="Gestión de Usuarios"
        android:textSize="22sp"
        android:textColor="#0965AE"
        android:gravity="center"
        android:layout_marginTop="10dp"
        android:layout_marginBottom="20dp" />
```

### 📊 **Lista con Texto Azul**
```kotlin
val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, usuariosArray) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = super.getView(position, convertView, parent)
        val textView = view.findViewById<TextView>(android.R.id.text1)
        textView.setTextColor(ContextCompat.getColor(context, android.R.color.holo_blue_dark))
        return view
    }
}
```

## 🔄 Flujo de Trabajo

### 📝 **Crear Usuario**
1. Llenar todos los campos requeridos
2. Seleccionar perfil del spinner
3. Marcar checkbox "Activo" si es necesario
4. Presionar botón "Guardar"
5. Confirmar creación exitosa
6. Lista se actualiza automáticamente

### 🔍 **Seleccionar Usuario**
1. Tocar usuario en la lista
2. Datos se cargan automáticamente en formulario
3. Modificar campos necesarios
4. Presionar "Modificar" o "Eliminar"

### ✏️ **Modificar Usuario**
1. Seleccionar usuario de la lista
2. Datos se cargan automáticamente
3. Modificar campos necesarios
4. Presionar "Modificar"
5. Confirmar actualización exitosa

### 🗑️ **Eliminar Usuario**
1. Seleccionar usuario de la lista
2. Presionar "Eliminar"
3. Confirmar eliminación en diálogo
4. Usuario se elimina (excepto admin)
5. Lista se actualiza automáticamente

## 🔐 Sistema de Permisos

### 👑 **Admin**
- ✅ Control total del sistema
- ✅ Gestión completa de usuarios
- ✅ Acceso a todos los módulos
- ✅ No puede ser eliminado

### 👨‍💼 **Supervisor**
- ✅ Acceso a catálogo de productos
- ✅ Gestión de usuarios
- ✅ Visualización de irregularidades
- ✅ Reportes y estadísticas

### 🚛 **Rampero**
- ✅ Acceso a módulo de entradas
- ✅ Gestión de envíos
- ✅ Registro de irregularidades
- ✅ Operaciones de carga

### 👷 **Operador**
- ✅ Acceso solo a salidas
- ✅ Registro de irregularidades
- ✅ Operaciones básicas
- ✅ Permisos limitados

## ⚙️ Configuración

### 🔧 **Constantes de la App**
```kotlin
companion object {
    private const val SERVER_URL = "http://192.168.1.65/ssimce/"
    private const val API_KEY = "MI_API_KEY_SECRETA"
}
```

### 📱 **Permisos Requeridos**
- **Internet** - Para comunicación con servidor
- **Estado de red** - Para verificar conectividad

## 🐛 Solución de Problemas

### ❌ **Error de Conexión**
- Verificar conectividad de red
- Confirmar IP del servidor correcta
- Verificar que servidor esté funcionando

### ❌ **Usuario No Encontrado**
- Verificar que usuario exista en base de datos
- Confirmar formato correcto del usuario
- Verificar permisos de lectura en servidor

### ❌ **Error al Guardar**
- Verificar campos requeridos completos
- Confirmar usuario único (no duplicado)
- Verificar permisos de escritura en servidor

### ❌ **No Se Puede Eliminar Admin**
- Protección automática del usuario admin
- Mensaje informativo sobre restricción
- Solo admin puede eliminar otros usuarios

## 📊 Métricas de Rendimiento

### ⚡ **Optimizaciones Aplicadas**
- ✅ Interfaz optimizada para cámara frontal
- ✅ Texto azul para mejor visibilidad
- ✅ Validación en tiempo real
- ✅ Manejo de errores mejorado
- ✅ Protección de usuario admin

### 📈 **Beneficios**
- **Mejor UX** - Elementos no bloqueados por cámara
- **Mayor visibilidad** - Texto azul en listas
- **Mayor seguridad** - Protección de admin
- **Validación robusta** - Menos errores de datos

## 🔮 Futuras Mejoras

### 🎯 **Posibles Implementaciones**
- **Cambio de contraseña** - Función específica
- **Recuperación de contraseña** - Por email
- **Historial de cambios** - Auditoría de modificaciones
- **Bloqueo temporal** - Por intentos fallidos
- **Notificaciones** - Alertas de cambios importantes

---

**Versión**: 2.0.0  
**Estado**: ✅ Completamente funcional  
**Última actualización**: Diciembre 2024 