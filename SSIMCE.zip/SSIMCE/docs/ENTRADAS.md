# 📦 Módulo de Entradas

## 📋 Descripción
Módulo completo para gestión de entradas de inventario con diferentes tipos de PDA (Personal Digital Assistant). Incluye scanner optimizado y descripción inteligente de productos.

## ✅ Tipos de Entrada Disponibles

### 🚚 **PDA Entregas a Clientes**
- Registro de entregas a clientes
- Gestión de irregularidades con evidencia
- Guardado en tabla `entradas` y `irregularidades`
- Scanner optimizado sin delays

### 🏪 **PDA Surtido Tiendas**
- Gestión de surtido para tiendas
- Evidencia fotográfica/video
- Registro completo de operaciones
- Validación de datos en tiempo real

### 📦 **PDA Loteo Jabas**
- Loteo con códigos de barras Code 128
- Descripción automática según código:
  - **M** → "Loteo Muebles"
  - **C** → "Loteo Celulares"
- Scanner personalizado optimizado

### 👕 **PDA Ropa**
- Gestión de ropa con códigos específicos
- Descripción automática según contenido:
  - **J-GD** → "Jaba Grande"
  - **J-CH** → "Jaba Chica"
  - **CART** → "Cartón"
- Validación de códigos en tiempo real

## 🔧 Archivos PHP del Servidor

### 📁 Endpoints por Tipo
- **`guardar_entrada_ropa.php`** - Entradas de ropa
- **`guardar_entrada_loteo.php`** - Entradas de loteo
- **`guardar_entrada_surtido.php`** - Entradas de surtido
- **`guardar_entrada_entregas.php`** - Entradas de entregas

### 🔐 Seguridad
- **API Key** - Autenticación en todos los endpoints
- **Validación de datos** - Verificación en servidor
- **Manejo de errores** - Respuestas JSON estructuradas

## 📱 Características del Scanner

### ⚡ **Optimizaciones Aplicadas**
- **Sin delays** - Respuesta inmediata después de escanear
- **ToneGenerator** - Sonido más rápido que MediaPlayer
- **Vibración reducida** - Menor duración para mejor UX
- **Procesamiento externo** - Lógica fuera de runOnUiThread

### 🔍 **Descripción Inteligente**
```kotlin
// Lógica personalizada según tipo de tabla
when (TIPO_TABLA) {
    "LOTEO_JABAS" -> {
        when {
            codigo.startsWith("M") -> "Loteo Muebles"
            codigo.startsWith("C") -> "Loteo Celulares"
            else -> "Producto no encontrado"
        }
    }
    "ROPA" -> {
        when {
            codigo.contains("J-GD") -> "Jaba Grande"
            codigo.contains("J-CH") -> "Jaba Chica"
            codigo.contains("CART") -> "Cartón"
            else -> "Producto no encontrado"
        }
    }
}
```

## 🗄️ Estructura de Base de Datos

### Tabla `entradas`
```sql
CREATE TABLE entradas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(50) NOT NULL,
    descripcion TEXT NOT NULL,
    cantidad INT NOT NULL,
    tipo_entrada VARCHAR(50) NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario VARCHAR(50),
    observaciones TEXT
);
```

### Tabla `irregularidades`
```sql
CREATE TABLE irregularidades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(50) NOT NULL,
    descripcion TEXT NOT NULL,
    evidencia LONGBLOB,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario VARCHAR(50),
    sincronizado BOOLEAN DEFAULT FALSE
);
```

## 🔄 Flujo de Trabajo

### 📝 **Entrada Normal**
1. Escanear código de barras
2. Descripción se auto-completa
3. Ingresar cantidad
4. Agregar observaciones si es necesario
5. Presionar "Guardar"
6. Datos se envían al servidor

### ⚠️ **Entrada con Irregularidad**
1. Escanear código de barras
2. Descripción se auto-completa
3. Marcar "Hay irregularidad"
4. Ingresar detalles de irregularidad
5. Capturar evidencia (foto/video)
6. Presionar "Guardar"
7. Datos se guardan en `entradas` e `irregularidades`

## 📊 Características Avanzadas

### 🎯 **Scanner Optimizado**
- **Respuesta inmediata** - Sin delays de 1.5 segundos
- **Sonido optimizado** - ToneGenerator más rápido
- **Vibración reducida** - Mejor experiencia de usuario
- **Procesamiento eficiente** - Lógica optimizada

### 🔍 **Búsqueda Inteligente**
- **Códigos Code 128** - Soporte completo
- **Descripción automática** - Según tipo de producto
- **Validación en tiempo real** - Verificación de códigos
- **Mensajes informativos** - Estado de búsqueda

### 📱 **Interfaz de Usuario**
- **Diseño intuitivo** - Fácil de usar
- **Validación visual** - Indicadores de estado
- **Mensajes claros** - Información específica
- **Navegación fluida** - Transiciones suaves

## ⚙️ Configuración

### 🔧 **Constantes de la App**
```kotlin
companion object {
    private const val SERVER_URL = "http://192.168.1.65/ssimce/"
    private const val API_KEY = "MI_API_KEY_SECRETA"
}
```

### 📱 **Permisos Requeridos**
- **Cámara** - Para escaneo de códigos
- **Internet** - Para comunicación con servidor
- **Almacenamiento** - Para evidencia multimedia

## 🐛 Solución de Problemas

### ❌ **Scanner No Funciona**
- Verificar permisos de cámara
- Confirmar que código sea Code 128
- Verificar iluminación adecuada
- Reiniciar aplicación si es necesario

### ❌ **Error de Conexión**
- Verificar conectividad de red
- Confirmar IP del servidor correcta
- Verificar que servidor esté funcionando

### ❌ **Descripción No Se Completa**
- Verificar formato del código
- Confirmar que código esté en base de datos
- Verificar lógica de descripción según tipo

## 📊 Métricas de Rendimiento

### ⚡ **Optimizaciones Aplicadas**
- ✅ Eliminación de delays en scanner
- ✅ Optimización de sonido y vibración
- ✅ Procesamiento eficiente de códigos
- ✅ Descripción inteligente por tipo

### 📈 **Beneficios**
- **Mayor velocidad** - Escaneo inmediato
- **Mejor UX** - Sin esperas innecesarias
- **Precisión mejorada** - Descripción automática
- **Menos errores** - Validación en tiempo real

## 🔮 Futuras Mejoras

### 🎯 **Posibles Implementaciones**
- **Más tipos de códigos** - Soporte para otros formatos
- **Historial de escaneos** - Registro de operaciones
- **Estadísticas** - Métricas de uso
- **Modo offline** - Funcionamiento sin conexión
- **Sincronización automática** - Datos en tiempo real

---

**Versión**: 2.0.0  
**Estado**: ✅ Completamente funcional  
**Última actualización**: Diciembre 2024 