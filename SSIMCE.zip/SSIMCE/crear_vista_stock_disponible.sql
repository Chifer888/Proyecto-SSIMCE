-- Script para verificar y crear vista de stock disponible

-- Verificar si existe la vista
SELECT COUNT(*) as existe_vista FROM information_schema.views 
WHERE table_schema = 'ssimce_db' AND table_name = 'v_stock_disponible';

-- Crear vista de stock disponible si no existe
CREATE OR REPLACE VIEW v_stock_disponible AS
SELECT 
    sku,
    COALESCE(SUM(CASE WHEN tipo = 'entrada' THEN cantidad ELSE 0 END), 0) as total_entradas,
    COALESCE(SUM(CASE WHEN tipo = 'salida' THEN cantidad ELSE 0 END), 0) as total_salidas,
    (COALESCE(SUM(CASE WHEN tipo = 'entrada' THEN cantidad ELSE 0 END), 0) - 
     COALESCE(SUM(CASE WHEN tipo = 'salida' THEN cantidad ELSE 0 END), 0)) as stock_disponible
FROM (
    SELECT sku, cantidad, 'entrada' as tipo FROM entradas
    UNION ALL
    SELECT sku, cantidad, 'salida' as tipo FROM salidas
) combined_data
GROUP BY sku;

-- Verificar la vista creada
SELECT * FROM v_stock_disponible LIMIT 5;

-- Probar con un SKU específico
SELECT * FROM v_stock_disponible WHERE sku = '123456';

-- Mostrar estructura de las tablas
DESCRIBE entradas;
DESCRIBE salidas; 