<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, api_key');

// Manejar preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Leer configuración de base de datos
$config_path = 'D:/Programas Instalados/XAMMP/htdocs/private/config.ini';
if (!file_exists($config_path)) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Archivo de configuración no encontrado'
    ]);
    exit();
}

$config = parse_ini_file($config_path);
$host = $config['host'] ?? 'localhost';
$dbname = $config['dbname'] ?? 'ssimce_db';
$username = $config['username'] ?? 'root';
$password = $config['password'] ?? '';
$api_key_config = $config['api_key'] ?? 'MI_API_KEY_SECRETA';

// Verificar API key
$headers = getallheaders();
$api_key = isset($headers['api_key']) ? $headers['api_key'] : '';

if ($api_key !== $api_key_config) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'API key inválida'
    ]);
    exit();
}

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error de conexión a la base de datos: ' . $e->getMessage()
    ]);
    exit();
}

// Obtener datos del POST
$input = json_decode(file_get_contents('php://input'), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sku = isset($input['sku']) ? trim($input['sku']) : '';
    $descripcion = isset($input['descripcion']) ? trim($input['descripcion']) : '';
    $cantidad = isset($input['cantidad']) ? intval($input['cantidad']) : 0;
    $tipo_entrada = isset($input['tipo_entrada']) ? trim($input['tipo_entrada']) : 'Entregas a Clientes';
    $observaciones = isset($input['observaciones']) ? trim($input['observaciones']) : '';
    $usuario = isset($input['usuario']) ? trim($input['usuario']) : 'admin';

    // Validar datos requeridos
    if (empty($sku) || empty($descripcion) || $cantidad <= 0) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'SKU, descripción y cantidad son requeridos'
        ]);
        exit();
    }

    try {
        $pdo->beginTransaction();

        // Insertar en la tabla entradas
        $stmt = $pdo->prepare("
            INSERT INTO entradas (sku, descripcion, cantidad, tipo_entrada, observaciones, usuario, fecha_registro)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([$sku, $descripcion, $cantidad, $tipo_entrada, $observaciones, $usuario]);
        $entrada_id = $pdo->lastInsertId();

        $pdo->commit();

        echo json_encode([
            'success' => true,
            'message' => 'Entrada registrada exitosamente',
            'entrada_id' => $entrada_id,
            'sku' => $sku,
            'cantidad' => $cantidad,
            'tipo_entrada' => $tipo_entrada
        ]);

    } catch (PDOException $e) {
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Error al guardar la entrada: ' . $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Método no permitido'
    ]);
}
?> 