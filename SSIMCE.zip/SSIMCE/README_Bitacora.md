# 📝 README - Módulo de Bitácora

## 🎯 Descripción General
Este módulo permite el registro y seguimiento de actividades diarias mediante bitácoras digitales, incluyendo captura de evidencia y sincronización con servidor.

## 🔍 Funcionalidades Principales

### ✅ Registro de Bitácoras
- **Escaneo de códigos** - Lectura de códigos de barras
- **Formulario digital** - Captura de datos estructurados
- **Validación automática** - Verificación de campos
- **Almacenamiento local** - Base de datos Room

### 📸 Captura de Evidencia
- **Fotografía** - Captura de imágenes
- **Video** - Grabación de videos
- **Compresión optimizada** - WebP 85% calidad
- **Redimensionamiento** - Máximo 1024px

### 📊 Visualización de Datos
- **Tabla organizada** - Vista tipo Excel
- **Filtros** - Búsqueda por fecha, tipo
- **Exportación** - Envío al servidor
- **Historial** - Registros anteriores

## 📁 Archivos Principales

### 🎭 Activities
- `MainActivityEscaneoBitacora.kt` - Escaneo principal
- `MainActivityFormularioBitacora.kt` - Formulario de datos
- `MainActivityMostrarDatosBitacora.kt` - Visualización
- `CameraActivityBitacora.kt` - Captura de evidencia

### 🎨 Layouts
- `activity_main_escaneo_bitacora.xml` - Interfaz de escaneo
- `activity_main_formulario_bitacora.xml` - Formulario
- `activity_main_mostrar_datos_bitacora.xml` - Lista
- `activity_camera_bitacora.xml` - Cámara

### 🗄️ Base de Datos
- **Room Database** - Almacenamiento local
- **Entidades** - BitacoraRegistro, Producto
- **DAOs** - Operaciones de base de datos
- **Sincronización** - Envío al servidor

## 🚀 Características Destacadas

### ✅ Funcionalidades Implementadas
- ✅ Escaneo de códigos de barras
- ✅ Captura de fotografía y video
- ✅ Almacenamiento local con Room
- ✅ Sincronización con servidor
- ✅ Validación de datos
- ✅ Compresión de evidencia
- ✅ Interfaz responsiva
- ✅ Navegación intuitiva

### 🔄 Flujo de Usuario
1. **Escaneo de código** → Lectura de barras
2. **Captura de evidencia** → Foto o video
3. **Guardado local** → Base de datos Room
4. **Sincronización** → Envío al servidor
5. **Visualización** → Historial de registros

## 🛠️ Tecnologías Utilizadas
- **Kotlin** - Lenguaje principal
- **Room Database** - Almacenamiento local
- **Camera API** - Captura de evidencia
- **Volley** - Comunicación con servidor
- **ZXing** - Escaneo de códigos
- **FileProvider** - Manejo de archivos

## 📱 Compatibilidad
- **Android 6.0+** (API 23+)
- **Permisos dinámicos** para cámara y almacenamiento
- **Autofocus** para mejor escaneo
- **Compresión WebP** para optimización

## 🔧 Configuración

### 📋 Permisos Requeridos
```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.INTERNET" />
```

### 🎯 Características de Evidencia
- **Formato:** WebP
- **Calidad:** 85%
- **Tamaño máximo:** 1024px
- **Compresión:** Automática
- **Almacenamiento:** Local + Servidor

## 📊 Estadísticas de Uso
- **Escaneo rápido** - < 2 segundos por código
- **Compresión eficiente** - 85% de calidad WebP
- **Almacenamiento optimizado** - Máximo 1024px
- **Sincronización confiable** - Envío automático

## 🔄 Actualizaciones Recientes
- ✅ **Compresión mejorada** - WebP 85% calidad
- ✅ **Redimensionamiento** - Máximo 1024px
- ✅ **Manejo de errores** - Try-catch robusto
- ✅ **Logs detallados** - Debugging mejorado
- ✅ **Optimización de memoria** - Evita OutOfMemoryError 