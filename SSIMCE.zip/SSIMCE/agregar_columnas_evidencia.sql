-- Script para agregar columnas de evidencia a las tablas de envíos

-- Verificar si las columnas ya existen en envios_mrb
SELECT COUNT(*) as existe_evidencia FROM information_schema.columns 
WHERE table_schema = 'ssimce_db' AND table_name = 'envios_mrb' AND column_name = 'evidencia';

-- Verificar si las columnas ya existen en envios_ct
SELECT COUNT(*) as existe_evidencia FROM information_schema.columns 
WHERE table_schema = 'ssimce_db' AND table_name = 'envios_ct' AND column_name = 'evidencia';

-- Agregar columnas a tabla envios_mrb si no existen
ALTER TABLE envios_mrb 
ADD COLUMN IF NOT EXISTS evidencia LONGBLOB NULL COMMENT 'Evidencia en formato binario',
ADD COLUMN IF NOT EXISTS tipo_evidencia ENUM('imagen', 'video') NULL COMMENT 'Tipo de evidencia capturada';

-- Agregar columnas a tabla envios_ct si no existen
ALTER TABLE envios_ct 
ADD COLUMN IF NOT EXISTS evidencia LONGBLOB NULL COMMENT 'Evidencia en formato binario',
ADD COLUMN IF NOT EXISTS tipo_evidencia ENUM('imagen', 'video') NULL COMMENT 'Tipo de evidencia capturada';

-- Verificar la estructura final
DESCRIBE envios_mrb;
DESCRIBE envios_ct; 