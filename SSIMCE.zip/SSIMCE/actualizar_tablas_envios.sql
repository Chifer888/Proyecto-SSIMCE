-- Script para agregar columnas de evidencia a las tablas de envíos

-- Agregar columnas a tabla envios_mrb
ALTER TABLE envios_mrb 
ADD COLUMN evidencia LONGBLOB NULL COMMENT 'Evidencia en formato binario',
ADD COLUMN tipo_evidencia ENUM('imagen', 'video') NULL COMMENT 'Tipo de evidencia capturada';

-- Agregar columnas a tabla envios_ct
ALTER TABLE envios_ct 
ADD COLUMN evidencia LONGBLOB NULL COMMENT 'Evidencia en formato binario',
ADD COLUMN tipo_evidencia ENUM('imagen', 'video') NULL COMMENT 'Tipo de evidencia capturada';

-- Verificar que las columnas se agregaron correctamente
DESCRIBE envios_mrb;
DESCRIBE envios_ct; 