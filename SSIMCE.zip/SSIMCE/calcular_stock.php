<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, api_key');

// Manejar preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Verificar API key
$headers = getallheaders();
$api_key = isset($headers['api_key']) ? $headers['api_key'] : '';

if ($api_key !== 'MI_API_KEY_SECRETA') {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'API key inválida'
    ]);
    exit();
}

// Leer configuración de base de datos
$config_path = 'D:/Programas Instalados/XAMMP/htdocs/private/config.ini';
if (!file_exists($config_path)) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Archivo de configuración no encontrado'
    ]);
    exit();
}

$config = parse_ini_file($config_path);
$host = $config['host'] ?? 'localhost';
$dbname = $config['dbname'] ?? 'ssimce_db';
$username = $config['username'] ?? 'root';
$password = $config['password'] ?? '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error de conexión a la base de datos: ' . $e->getMessage()
    ]);
    exit();
}

// Obtener SKU del parámetro
$sku = isset($_GET['sku']) ? trim($_GET['sku']) : '';

if (empty($sku)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'SKU requerido'
    ]);
    exit();
}

try {
    // Consulta simplificada para obtener stock disponible del SKU
    $stmt = $pdo->prepare("
        SELECT 
            ? as sku,
            COALESCE(SUM(CASE WHEN tipo = 'entrada' THEN cantidad ELSE 0 END), 0) as total_entradas,
            COALESCE(SUM(CASE WHEN tipo = 'salida' THEN cantidad ELSE 0 END), 0) as total_salidas,
            (COALESCE(SUM(CASE WHEN tipo = 'entrada' THEN cantidad ELSE 0 END), 0) - 
             COALESCE(SUM(CASE WHEN tipo = 'salida' THEN cantidad ELSE 0 END), 0)) as stock_disponible
        FROM (
            SELECT sku, cantidad, 'entrada' as tipo FROM entradas WHERE sku = ?
            UNION ALL
            SELECT sku, cantidad, 'salida' as tipo FROM salidas WHERE sku = ?
        ) combined_data
    ");
    
    $stmt->execute([$sku, $sku, $sku]);
    $stock_data = $stmt->fetch(PDO::FETCH_ASSOC);

    // Obtener información adicional del producto
    $stmt_producto = $pdo->prepare("
        SELECT descripcion, imagen_url 
        FROM catalogo_productos 
        WHERE sku = ?
    ");
    $stmt_producto->execute([$sku]);
    $producto = $stmt_producto->fetch(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'stock' => [
            'sku' => $sku,
            'descripcion' => $producto['descripcion'] ?? 'Sin descripción',
            'imagen_url' => $producto['imagen_url'] ?? '',
            'total_entradas' => floatval($stock_data['total_entradas']),
            'total_salidas' => floatval($stock_data['total_salidas']),
            'stock_disponible' => floatval($stock_data['stock_disponible'])
        ]
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error en la consulta: ' . $e->getMessage()
    ]);
}
?> 