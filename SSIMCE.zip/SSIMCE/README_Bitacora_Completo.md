# 📋 MÓDULO DE BITÁCORA - SSIMCE

## 🎯 **Descripción General**

El módulo de **Bitácora** permite registrar y gestionar información de transporte y logística, incluyendo detalles de cajas, sellos y líneas de productos asociadas.

## 📁 **Estructura de Archivos**

```
SSIMCE/
├── database/
│   └── scripts/
│       └── crear_tabla_bitacora.sql ✅
├── php_files/
│   └── bitacora/
│       └── insertar_datos_bitacora.php ✅
└── README_Bitacora_Completo.md ✅
```

## 🗄️ **Base de Datos**

### **Tabla Principal: `bitacora`**
```sql
CREATE TABLE bitacora (
    id VARCHAR(50) PRIMARY KEY,
    Bitacora VARCHAR(50) NOT NULL,
    Fecha DATE,
    Caja VARCHAR(50),
    Sello VARCHAR(50),
    Sello_De_Repuesto VARCHAR(50),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### **Tabla de Líneas: `lineas_bitacora`**
```sql
CREATE TABLE lineas_bitacora (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_Bitacora VARCHAR(50) NOT NULL,
    Tipo VARCHAR(50),
    Folio VARCHAR(50),
    Destino VARCHAR(200),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_Bitacora) REFERENCES bitacora(id) ON DELETE CASCADE
);
```

## 🔧 **Instalación y Configuración**

### **Paso 1: Crear Base de Datos**
```bash
# Ejecutar script SQL
mysql -u root -p ssimce_db < database/scripts/crear_tabla_bitacora.sql
```

### **Paso 2: Configurar PHP**
```php
// Ubicación del archivo PHP
D:\Programas Instalados\XAMMP\htdocs\ssimce\php_files\bitacora\insertar_datos_bitacora.php
```

### **Paso 3: Configurar Android**
```kotlin
// En MainActivityFormularioBitacora.kt
private const val SERVER_URL = "http://192.168.1.65/ssimce/php_files/bitacora/insertar_datos_bitacora.php"
private const val API_KEY = "MI_API_KEY_SECRETA"
```

## 📱 **Funcionalidades Android**

### **Actividades Principales:**
1. **`MainActivityEscaneoBitacora.kt`** - Escaneo de códigos QR
2. **`MainActivityFormularioBitacora.kt`** - Formulario de datos
3. **`MainActivityMostrarDatosBitacora.kt`** - Visualización de datos
4. **`CameraActivityBitacora.kt`** - Captura de imágenes

### **Características:**
- ✅ **Escaneo QR** para identificación rápida
- ✅ **Formulario dinámico** con validaciones
- ✅ **Captura de imágenes** con cámara
- ✅ **Sincronización** con servidor
- ✅ **Almacenamiento local** con Room DB

## 🌐 **API PHP**

### **Endpoint: `insertar_datos_bitacora.php`**

#### **Método:** POST
#### **Headers requeridos:**
```http
Content-Type: application/json
api_key: MI_API_KEY_SECRETA
```

#### **Datos de entrada:**
```json
{
    "id": "BIT001",
    "Bitacora": "BIT-2024-001",
    "Fecha": "2024-01-15",
    "Caja": "CAJA001",
    "Sello": "SELLO001",
    "Repuesto_De_Sello": "REP001",
    "lineas_serializadas": "Guía:GUI001:Destino A|Factura:FAC001:Destino B"
}
```

#### **Respuesta exitosa:**
```json
{
    "success": true,
    "message": "Datos insertados correctamente"
}
```

#### **Respuesta de error:**
```json
{
    "success": false,
    "message": "Descripción del error"
}
```

## 🔍 **Consultas SQL Útiles**

### **Obtener todas las bitácoras:**
```sql
SELECT * FROM bitacora ORDER BY fecha_creacion DESC;
```

### **Obtener bitácora con líneas:**
```sql
SELECT b.*, lb.Tipo, lb.Folio, lb.Destino
FROM bitacora b
LEFT JOIN lineas_bitacora lb ON b.id = lb.id_Bitacora
WHERE b.id = 'BIT001';
```

### **Contar líneas por bitácora:**
```sql
SELECT b.id, b.Bitacora, COUNT(lb.id) as total_lineas
FROM bitacora b
LEFT JOIN lineas_bitacora lb ON b.id = lb.id_Bitacora
GROUP BY b.id;
```

## 🛠️ **Procedimientos Almacenados**

### **Insertar Bitácora Completa:**
```sql
CALL InsertarBitacoraCompleta(
    'BIT001',           -- id
    'BIT-2024-001',     -- bitacora
    '2024-01-15',       -- fecha
    'CAJA001',          -- caja
    'SELLO001',         -- sello
    'REP001',           -- sello_repuesto
    'Guía:GUI001:Destino A|Factura:FAC001:Destino B'  -- lineas_serializadas
);
```

### **Obtener Bitácora por ID:**
```sql
CALL ObtenerBitacoraPorId('BIT001');
```

### **Obtener Todas las Bitácoras:**
```sql
CALL ObtenerTodasBitacoras();
```

## 📊 **Vistas de Base de Datos**

### **Vista Completa:**
```sql
SELECT * FROM vista_bitacora_completa;
```

## 🔐 **Seguridad**

### **Validaciones Implementadas:**
- ✅ **API Key** requerida en headers
- ✅ **Validación de datos** JSON
- ✅ **Prepared Statements** para prevenir SQL Injection
- ✅ **Transacciones** para integridad de datos
- ✅ **Manejo de errores** robusto

### **Configuración Segura:**
```ini
# config.ini (fuera del web root)
[database]
host = localhost
username = root
password = 
dbname = ssimce_db
api_key = MI_API_KEY_SECRETA
```

## 🚀 **Flujo de Trabajo**

### **1. Escaneo QR:**
```
Usuario escanea QR → MainActivityEscaneoBitacora
```

### **2. Formulario:**
```
Datos capturados → MainActivityFormularioBitacora
```

### **3. Validación:**
```
Campos validados → Almacenamiento local
```

### **4. Sincronización:**
```
Datos enviados → insertar_datos_bitacora.php
```

### **5. Confirmación:**
```
Respuesta servidor → Actualización UI
```

## 🐛 **Solución de Problemas**

### **Error: "API key inválida"**
```bash
# Verificar config.ini
# Verificar headers en Android
```

### **Error: "No se recibieron datos JSON"**
```bash
# Verificar formato JSON
# Verificar Content-Type header
```

### **Error: "Error de conexión"**
```bash
# Verificar XAMPP (Apache + MySQL)
# Verificar credenciales de BD
```

### **Error: "Campos obligatorios faltantes"**
```bash
# Verificar que id y Bitacora no estén vacíos
# Verificar validaciones en Android
```

## 📈 **Métricas y Monitoreo**

### **Consultas de Monitoreo:**
```sql
-- Total de bitácoras por día
SELECT DATE(fecha_creacion) as fecha, COUNT(*) as total
FROM bitacora
GROUP BY DATE(fecha_creacion)
ORDER BY fecha DESC;

-- Líneas más comunes
SELECT Tipo, COUNT(*) as total
FROM lineas_bitacora
GROUP BY Tipo
ORDER BY total DESC;
```

## 🔄 **Mantenimiento**

### **Backup Automático:**
```sql
-- Crear backup diario
mysqldump -u root -p ssimce_db bitacora lineas_bitacora > backup_bitacora_$(date +%Y%m%d).sql
```

### **Limpieza de Datos:**
```sql
-- Eliminar registros antiguos (más de 1 año)
DELETE FROM bitacora WHERE fecha_creacion < DATE_SUB(NOW(), INTERVAL 1 YEAR);
```

## 📝 **Notas de Desarrollo**

### **Última Actualización:** 2024-01-15
### **Versión:** 1.0.0
### **Estado:** ✅ Funcional

### **Próximas Mejoras:**
- 🔄 **Sincronización offline** mejorada
- 📊 **Reportes automáticos**
- 🔍 **Búsqueda avanzada**
- 📱 **Notificaciones push**

---

**¡El módulo de Bitácora está completamente funcional y listo para producción!** 🎉 