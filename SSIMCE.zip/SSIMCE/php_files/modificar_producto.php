<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, api_key');

// Manejar preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Verificar API key
$headers = getallheaders();
$api_key = isset($headers['api_key']) ? $headers['api_key'] : '';

if ($api_key !== 'MI_API_KEY_SECRETA') {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'API key inválida']);
    exit();
}

try {
    // Cargar configuración
    $config = parse_ini_file('../private/config.ini');
    $host = $config['host'];
    $dbname = $config['dbname'];
    $username = $config['username'];
    $password = $config['password'];
    
    // Conectar a la base de datos
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Obtener datos del POST
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'Datos JSON inválidos']);
        exit();
    }
    
    $sku = isset($input['sku']) ? trim($input['sku']) : '';
    $descripcion = isset($input['descripcion']) ? trim($input['descripcion']) : '';
    $imagen = isset($input['imagen']) ? $input['imagen'] : '';
    
    // Validar datos requeridos
    if (empty($sku) || empty($descripcion)) {
        echo json_encode(['success' => false, 'message' => 'SKU y descripción son obligatorios']);
        exit();
    }
    
    // Verificar si el producto existe
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM catalogo_productos WHERE sku = ?");
    $stmt->execute([$sku]);
    $existe = $stmt->fetchColumn() > 0;
    
    if (!$existe) {
        echo json_encode(['success' => false, 'message' => 'El producto con SKU ' . $sku . ' no existe']);
        exit();
    }
    
    // Actualizar producto
    $stmt = $pdo->prepare("UPDATE catalogo_productos SET descripcion = ?, imagen_url = ?, fecha_actualizacion = NOW() WHERE sku = ?");
    $resultado = $stmt->execute([$descripcion, $imagen, $sku]);
    
    if ($resultado) {
        echo json_encode([
            'success' => true,
            'message' => 'Producto modificado exitosamente',
            'sku' => $sku
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al modificar el producto']);
    }
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error de base de datos: ' . $e->getMessage()]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error del servidor: ' . $e->getMessage()]);
}
?> 