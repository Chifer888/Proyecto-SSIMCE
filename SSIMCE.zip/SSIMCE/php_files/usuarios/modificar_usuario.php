<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, api_key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$api_key = isset($headers['api_key']) ? $headers['api_key'] : '';

if ($api_key !== 'MI_API_KEY_SECRETA') {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'API key inválida']);
    exit();
}

try {
    $config = parse_ini_file('../../private/config.ini');
    $pdo = new PDO("mysql:host={$config['host']};dbname={$config['dbname']};charset=utf8", $config['username'], $config['password']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'Datos JSON inválidos']);
        exit();
    }
    
    $id = $input['id'] ?? 0;
    $nombre = trim($input['nombre'] ?? '');
    $apellido = trim($input['apellido'] ?? '');
    $usuario = trim($input['usuario'] ?? '');
    $password = $input['password'] ?? '';
    $perfil = $input['perfil'] ?? 'operador';
    $email = trim($input['email'] ?? '');
    $telefono = trim($input['telefono'] ?? '');
    $activo = $input['activo'] ?? true;
    
    if (empty($id) || empty($nombre) || empty($apellido) || empty($usuario)) {
        echo json_encode(['success' => false, 'message' => 'Todos los campos obligatorios deben estar completos']);
        exit();
    }
    
    // Verificar si el usuario existe
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Usuario no encontrado']);
        exit();
    }
    
    // Verificar si el nombre de usuario ya existe en otro registro
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE usuario = ? AND id != ?");
    $stmt->execute([$usuario, $id]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'El nombre de usuario ya existe']);
        exit();
    }
    
    if (!empty($password)) {
        // Actualizar con nueva contraseña
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, usuario = ?, password = ?, perfil = ?, email = ?, telefono = ?, activo = ? WHERE id = ?");
        $stmt->execute([$nombre, $apellido, $usuario, $password_hash, $perfil, $email, $telefono, $activo, $id]);
    } else {
        // Actualizar sin cambiar contraseña
        $stmt = $pdo->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, usuario = ?, perfil = ?, email = ?, telefono = ?, activo = ? WHERE id = ?");
        $stmt->execute([$nombre, $apellido, $usuario, $perfil, $email, $telefono, $activo, $id]);
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Usuario actualizado exitosamente'
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error de base de datos: ' . $e->getMessage()]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error del servidor: ' . $e->getMessage()]);
}
?> 