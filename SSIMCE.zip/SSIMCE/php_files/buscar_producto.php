<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, api_key');

// Manejar preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Verificar API key
$headers = getallheaders();
$api_key = isset($headers['api_key']) ? $headers['api_key'] : '';

if ($api_key !== 'MI_API_KEY_SECRETA') {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'API key inválida']);
    exit();
}

try {
    // Cargar configuración
    $config = parse_ini_file('../private/config.ini');
    $host = $config['host'];
    $dbname = $config['dbname'];
    $username = $config['username'];
    $password = $config['password'];
    
    // Conectar a la base de datos
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Obtener SKU del parámetro GET o POST
    $sku = '';
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $sku = isset($_GET['sku']) ? trim($_GET['sku']) : '';
    } else {
        $input = json_decode(file_get_contents('php://input'), true);
        $sku = isset($input['sku']) ? trim($input['sku']) : '';
    }
    
    if (empty($sku)) {
        echo json_encode(['success' => false, 'message' => 'SKU no proporcionado']);
        exit();
    }
    
    // Buscar producto por SKU
    $stmt = $pdo->prepare("SELECT sku, descripcion, imagen_url FROM catalogo_productos WHERE sku = ?");
    $stmt->execute([$sku]);
    $producto = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($producto) {
        echo json_encode([
            'success' => true,
            'producto' => $producto
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Producto no encontrado'
        ]);
    }
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error de base de datos: ' . $e->getMessage()]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error del servidor: ' . $e->getMessage()]);
}
?> 